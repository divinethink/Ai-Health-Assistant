import { t } from "../../shared/i18n.js";
import { renderRichText } from "../../shared/richText.js";
// Structured Trigger Layer UI (roadmap §10.3 স্তর-১) — member select + বয়স-গ্রুপ
// অনুযায়ী red-flag checklist, সরাসরি deterministic triageEngine.js-এ input (free-text
// নয়, skip-অযোগ্য নয়)। HealthTimeline.js/HealthRecordsSection.js-এর member-picker
// pattern reuse (Process ফাইল Rule ২ — Minimal Change)।
//
// এই থ্রেডে যোগ হলো — Health Episode session model (Architecture Plan Part C §9):
// প্রতিটা "চেক করুন" → নতুন HealthEpisode + TriageResult + structured-trigger
// message save হয় (episodesData.js, hasAccess-gated rules ইতিমধ্যে deploy করা)।
// AI-response স্তর-২ (ai-followup) message হিসেবে save হয়, ও নতুন post-guidance
// free-text follow-up box (স্তর-৩) conversation-history maintain করে। Episode-save
// ব্যর্থ হলেও triage/AI-flow bright-line অপ্রভাবিত থাকে (non-fatal try/catch)।
// Rate-Limit (429) Mitigation (§10.2.2) — askAI()-এর retry-callback দিয়ে
// non-alarming "একটু অপেক্ষা করুন" note দেখানো হয়, raw error না।

import { bnNum } from "../../shared/dates.js";
import { ErrorBox, SelectField, TextField, PrimaryButton, SecondaryButton } from "../../shared/ui.js";
import { listMembers } from "../../legacy/familyIdentity.js";
import { deriveAgeGroup, getChecklistForAgeGroup, isPediatricAgeGroup, runTriage, CHIEF_COMPLAINTS, CARDIAC_BYSTANDER_QUESTIONS, getAgeInYears } from "./triageEngine.js";
import { TriageResultView } from "./TriageResultView.js";
import { groupChecklistItems } from "./triageGroups.js";
import { assembleHealthContext } from "../../legacy/healthContextEngine.js";
import { askAI } from "../../ai/aiClient.js";
import { createEpisode, saveTriageResult, addMessage, archiveEpisode } from "../episodes/episodesData.js";
import { RiskBasedTreatmentModes } from "../treatment-modes/RiskBasedTreatmentModes.js";
import { listHealthRecords } from "../records/healthRecordsData.js";
import { pregnancyRecordsOf } from "../tracker/trackerCalc.js";
import { checkAspirinContraindication } from "../emergency/bystanderAspirin.js";
import { BystanderAspirinCard } from "../emergency/BystanderAspirinCard.js";

const { useState, useEffect, useRef } = React;

// Chat-Length Soft-Nudge (§9, §10.3) — heavy tokenizer library আনার দরকার নেই,
// rough char-count heuristic যথেষ্ট (soft-nudge, exact enforcement সংখ্যা না)।
// বাংলা টেক্সটে গড়ে প্রতি token-এ কম character লাগে বলে ২ দিয়ে divide করা হলো
// (conservative — বাস্তব token-count-এর চেয়ে সামান্য বেশি estimate দেখাবে)।
const CHAT_LENGTH_SOFT_LIMIT_TOKENS = 3000;
function estimateTokens(text) {
  return Math.ceil((text || "").length / 2);
}

function checkboxLine(label, checked, onChange) {
  return React.createElement(
    "label", { style: { display: "flex", alignItems: "center", gap: "8px", fontSize: "14px", padding: "6px 0", cursor: "pointer" } },
    React.createElement("input", { type: "checkbox", checked, onChange }),
    label
  );
}

const AGE_GROUP_LABELS = {
  neonate: "নবজাতক (< ২৮ দিন)",
  infant: "শিশু (< ২ বছর)",
  child: "শিশু (২–১৮ বছর)",
  adult: "প্রাপ্তবয়স্ক",
  elderly: "বয়স্ক (৬৫+)",
};

// member-selector unification (owner-request): নিজস্ব dropdown সরিয়ে parent
// (AIChatSection)-এর `selectedMemberId` প্রপ ব্যবহার — কিন্তু safety-critical
// `handleMemberChange()` reset-logic (নিচে) অপরিবর্তিত রাখা হয়েছে (Process
// Rule ৫), শুধু এখন সেটা dropdown-onChange-এর বদলে prop-change useEffect
// থেকে trigger হয়।
export function TriageForm({ familyId, callerMemberId, selectedMemberId }) {
  const [members, setMembers] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [targetMemberId, setTargetMemberId] = useState(null);
  const [checklist, setChecklist] = useState({});
  const [chiefComplaint, setChiefComplaint] = useState("none");
  const [feverDays, setFeverDays] = useState("");
  const [diarrheaDays, setDiarrheaDays] = useState("");
  const [bloodyStool, setBloodyStool] = useState(false);
  const [stridorCalm, setStridorCalm] = useState(false);
  const [chestIndrawing, setChestIndrawing] = useState(false);
  const [fastBreathing, setFastBreathing] = useState(false);
  const [cough14Days, setCough14Days] = useState(false);
  const [earSwellingTender, setEarSwellingTender] = useState(false);
  const [earPainDischarge, setEarPainDischarge] = useState(false);
  const [earDurationDays, setEarDurationDays] = useState("");
  const [measlesSevere, setMeaslesSevere] = useState(false);
  const [measlesEyeMouth, setMeaslesEyeMouth] = useState(false);
  const [measlesCurrent, setMeaslesCurrent] = useState(false);
  const [result, setResult] = useState(null);
  const [cardiacAnswers, setCardiacAnswers] = useState({ cardiacPersistent: false, cardiacAssociated: false });
  const [aspirinCheck, setAspirinCheck] = useState(null);
  const [hasChronicCondition, setHasChronicCondition] = useState(false);
  const [isPregnant, setIsPregnant] = useState(false); // প্রোফাইলের গর্ভাবস্থা/বুকের দুধ (ধাপ ৬)
  const [healthContext, setHealthContext] = useState(null);
  const [memberAgeYears, setMemberAgeYears] = useState(null); // Groq-payload-এ যায় না, শুধু Worker dose-lookup-এর জন্য (§6.6 প্রাইভেসি)
  const [contextErr, setContextErr] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState(null);
  const [aiErr, setAiErr] = useState(null);
  const [aiRetryNote, setAiRetryNote] = useState(null);

  // Health Episode session-state
  const [episodeId, setEpisodeId] = useState(null);
  const [episodeSaveErr, setEpisodeSaveErr] = useState(null);
  const [conversationTurns, setConversationTurns] = useState([]); // askAI-এর conversationHistory ফরম্যাট
  const [discussionLog, setDiscussionLog] = useState([]); // শুধু UI-display-এর জন্য (স্তর-৩)
  const [followUpText, setFollowUpText] = useState("");
  const [followUpLoading, setFollowUpLoading] = useState(false);
  const [followUpErr, setFollowUpErr] = useState(null);
  const [followUpRetryNote, setFollowUpRetryNote] = useState(null);
  const turnCounterRef = useRef(0);

  function nextTurnIndex() {
    turnCounterRef.current += 1;
    return turnCounterRef.current;
  }

  function check(setter) {
    return () => { setter((v) => !v); setResult(null); setHealthContext(null); setMemberAgeYears(null); setAspirinCheck(null); };
  }

  function toggleCardiacAnswer(id) {
    setResult(null); setAspirinCheck(null);
    setCardiacAnswers((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  useEffect(() => {
    listMembers(familyId)
      .then(setMembers)
      .catch((e) => setLoadErr(e.message || String(e)));
  }, [familyId]);

  // পেজ-লেভেল shared picker (AIChatSection)-এ সদস্য বদলালে এখানেও sync হবে —
  // handleMemberChange() নিজেই সব triage/episode state safely reset করে
  // (নিচে সংজ্ঞায়িত, নিরাপত্তা-সংক্রান্ত reset-logic অপরিবর্তিত)।
  useEffect(() => {
    if (selectedMemberId && selectedMemberId !== targetMemberId) handleMemberChange(selectedMemberId);
    // eslint-disable-next-line
  }, [selectedMemberId]);

  const targetMember = members && members.find((m) => m.id === targetMemberId);
  const ageGroup = targetMember ? deriveAgeGroup(targetMember.dob) : null;
  const checklistItems = ageGroup ? getChecklistForAgeGroup(ageGroup) : [];

  function resetEpisodeState() {
    setEpisodeId(null);
    setEpisodeSaveErr(null);
    setConversationTurns([]);
    setDiscussionLog([]);
    setFollowUpText("");
    setFollowUpErr(null);
    setFollowUpRetryNote(null);
    turnCounterRef.current = 0;
  }

  function handleMemberChange(id) {
    setTargetMemberId(id);
    setChecklist({});
    setChiefComplaint("none");
    setResult(null);
    setCardiacAnswers({ cardiacPersistent: false, cardiacAssociated: false });
    setAspirinCheck(null);
    setHasChronicCondition(false);
    setHealthContext(null); setMemberAgeYears(null);
    setAiResponse(null);
    setAiErr(null);
    resetEpisodeState();
  }

  function toggleItem(id) {
    setResult(null);
    setAspirinCheck(null);
    setChecklist((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  async function runCheck() {
    const triageResult = runTriage({
      ageGroup, checklist, chiefComplaint,
      complaintInputs: {
        feverDays, diarrheaDays, bloodyStool,
        stridorCalm, chestIndrawing, fastBreathing, cough14Days,
        earSwellingTender, earPainDischarge, earDurationDays,
        measlesSevere, measlesEyeMouth, measlesCurrent,
      },
      cardiacBystanderAnswers: cardiacAnswers,
    });
    setResult(triageResult);
    setHealthContext(null); setMemberAgeYears(null);
    setContextErr(null);
    setAiResponse(null);
    setAiErr(null);
    resetEpisodeState(); // নতুন "চেক করুন" ক্লিক = নতুন Health Episode (§9)

    // Bystander-Aspirin contraindication auto-verify (Architecture Plan Part B
    // §5.4.1.1) — সম্পূর্ণ deterministic, profile-lookup-ভিত্তিক, কোনো AI-call
    // না। শুধু CARDIAC-BYSTANDER-001 rule trigger হলেই চলে (non-blocking —
    // ব্যর্থ হলেও triage/emergency-contact bright-line অপ্রভাবিত)।
    const cardiacTriggered = triageResult.triggeredRules.some((r) => r.ruleId === "CARDIAC-BYSTANDER-001");
    if (!cardiacTriggered) setAspirinCheck(null);
    // roadmap §12.4 Category B bright-line rule (chronicManagement থাকলে
    // dose-suggestion না) actual Condition data থেকে যাচাই করার জন্য এই
    // unconditional fetch — আগে শুধু cardiac-branch-এই records আনা হতো, এখন
    // সবসময় আনা হয় যাতে chronicManagement flag সঠিকভাবে RiskBasedTreatmentModes-এ
    // পৌঁছায় (আগে hardcode `false` ছিল, checklist §৭ known-gap)।
    listHealthRecords(familyId, targetMemberId, { fresh: true })
      .then((records) => {
        const conditionRecords = records.filter((r) => r.resourceType === "condition");
        setHasChronicCondition(conditionRecords.some((c) => c.chronicManagement === true && c.status !== "resolved"));
        setIsPregnant(pregnancyRecordsOf(records).some((c) => c.status !== "resolved"));
        if (cardiacTriggered) {
          const ageYears = targetMember ? getAgeInYears(targetMember.dob) : null;
          const allergyRecords = records.filter((r) => r.resourceType === "allergy");
          setAspirinCheck(checkAspirinContraindication({ ageYears, allergyRecords, conditionRecords }));
        }
      })
      .catch(() => {
        setHasChronicCondition(false);
        setIsPregnant(false);
        if (cardiacTriggered) setAspirinCheck({ blocked: true, reason: "প্রোফাইল যাচাই করা যায়নি (safe-default: block)" });
      });

    // Health Context Engine — dev-preview assemble, কোনো Firestore write না।
    assembleHealthContext(familyId, targetMemberId, triageResult, { symptoms: chiefComplaint })
      .then(({ context, ageYears }) => { setHealthContext(context); setMemberAgeYears(ageYears); })
      .catch((e) => setContextErr(e.message || String(e)));

    // Episode/TriageResult/structured-trigger-message persist — non-fatal:
    // এটা ব্যর্থ হলেও triage output/health-context bright-line অপ্রভাবিত থাকে।
    try {
      const tag = chiefComplaint !== "none" ? chiefComplaint : "emergency-checklist";
      const epId = await createEpisode(familyId, targetMemberId, callerMemberId, tag);
      await saveTriageResult(familyId, epId, targetMemberId, callerMemberId, triageResult);
      await addMessage(familyId, epId, {
        turnIndex: nextTurnIndex(),
        layer: "structured-trigger",
        role: "user",
        inputMode: "structured-field",
        content: "checklist: " + JSON.stringify(checklist) + ", chiefComplaint: " + chiefComplaint,
      });
      setEpisodeId(epId);
    } catch (e) {
      setEpisodeSaveErr(e.message || String(e));
    }
  }

  async function handleAskAI() {
    if (!healthContext) return;
    setAiLoading(true);
    setAiErr(null);
    setAiRetryNote(null);
    try {
      const data = await askAI(familyId, healthContext, conversationTurns, {
        onRetry: (attempt, max) => setAiRetryNote("একটু অপেক্ষা করুন... (retry " + attempt + "/" + max + ")"),
        ageYears: memberAgeYears,
      });
      const content = data && data.content;
      setAiResponse(content);
      setConversationTurns((prev) => [...prev, { role: "assistant", content }]);
      if (episodeId) {
        addMessage(familyId, episodeId, {
          turnIndex: nextTurnIndex(), layer: "ai-followup", role: "ai", inputMode: null, content,
        }).catch(() => {});
      }
    } catch (e) {
      setAiErr(e.message || String(e));
    } finally {
      setAiLoading(false);
      setAiRetryNote(null);
    }
  }

  async function handleSendFollowUp() {
    const text = followUpText.trim();
    if (!text || !healthContext) return;
    setFollowUpLoading(true);
    setFollowUpErr(null);
    setFollowUpRetryNote(null);
    const newHistory = [...conversationTurns, { role: "user", content: text }];
    if (episodeId) {
      addMessage(familyId, episodeId, {
        turnIndex: nextTurnIndex(), layer: "post-guidance-discussion", role: "user", inputMode: "free-text", content: text,
      }).catch(() => {});
    }
    try {
      const data = await askAI(familyId, healthContext, newHistory, {
        onRetry: (attempt, max) => setFollowUpRetryNote("একটু অপেক্ষা করুন... (retry " + attempt + "/" + max + ")"),
        ageYears: memberAgeYears,
      });
      const content = data && data.content;
      setConversationTurns([...newHistory, { role: "assistant", content }]);
      setDiscussionLog((prev) => [...prev, { role: "user", content: text }, { role: "assistant", content }]);
      setFollowUpText("");
      if (episodeId) {
        addMessage(familyId, episodeId, {
          turnIndex: nextTurnIndex(), layer: "post-guidance-discussion", role: "ai", inputMode: null, content,
        }).catch(() => {});
      }
    } catch (e) {
      setFollowUpErr(e.message || String(e));
    } finally {
      setFollowUpLoading(false);
      setFollowUpRetryNote(null);
    }
  }

  async function handleArchiveAndStartNew() {
    if (episodeId) {
      try { await archiveEpisode(familyId, episodeId, callerMemberId); } catch (e) { /* non-fatal, নতুন episode শুরু করাই primary উদ্দেশ্য */ }
    }
    setChecklist({});
    setChiefComplaint("none");
    setResult(null);
    setCardiacAnswers({ cardiacPersistent: false, cardiacAssociated: false });
    setAspirinCheck(null);
    setHealthContext(null); setMemberAgeYears(null);
    setContextErr(null);
    setAiResponse(null);
    setAiErr(null);
    resetEpisodeState();
  }

  if (loadErr) return ErrorBox(loadErr);
  if (!members || !targetMemberId) {
    return React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "সদস্য-তালিকা লোড হচ্ছে...");
  }

  // Chat-Length Soft-Nudge check (§9) — শুধু conversationTurns + aiResponse-এর
  // cumulative char-length থেকে rough token-estimate।
  const cumulativeText = (aiResponse || "") + conversationTurns.map((t) => t.content || "").join(" ");
  const estimatedTokens = estimateTokens(cumulativeText);
  const showLengthNudge = estimatedTokens > CHAT_LENGTH_SOFT_LIMIT_TOKENS;

  return React.createElement(
    "div", { style: { marginTop: "20px" } },
    React.createElement("h3", { style: { fontSize: "15px", color: "var(--hs-primary, #0E4B43)" } }, t("h.triage")),

    !ageGroup && targetMember && React.createElement(
      "div", { style: { fontSize: "14px", color: "#C0392B", marginTop: "6px" } },
      "এই সদস্যের জন্ম-তারিখ সেট করা নেই — Health Profile-এ জন্ম-তারিখ যোগ করুন, তারপর triage checklist দেখানো যাবে।"
    ),
    ageGroup && React.createElement(
      "div", { style: { fontSize: "14px", color: "#4B5C57", marginTop: "6px" } },
      "বয়স-গ্রুপ: " + (AGE_GROUP_LABELS[ageGroup] || ageGroup)
    ),

    // ধাপ ৩: ২–৩ গ্রুপ, বড় টাচ-সারি (≥৫৬px, পুরো সারি ট্যাপযোগ্য)। আইটেম/id/triage-নিয়ম অপরিবর্তিত — শুধু সাজানো।
    checklistItems.length > 0 && React.createElement(
      "div", { style: { marginTop: "12px" } },
      React.createElement("div", { style: { fontSize: "14px", color: "#5F716C", marginBottom: "4px" } }, "এখন প্রযোজ্য কোনটা? মিলিয়ে দেখুন"),
      groupChecklistItems(checklistItems, isPediatricAgeGroup(ageGroup)).map((g) => React.createElement(
        React.Fragment, { key: g.key },
        React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "8px", margin: "14px 0 6px", fontSize: "16px", fontWeight: 700, color: "var(--hs-primary, #0E4B43)" } },
          React.createElement("span", { "aria-hidden": "true" }, g.icon), g.title),
        g.items.map((it) => {
          const on = !!checklist[it.id];
          return React.createElement(
            "label", { key: it.id, style: { display: "flex", alignItems: "center", gap: "12px", minHeight: "56px", boxSizing: "border-box", padding: "10px 14px", marginBottom: "8px", borderRadius: "14px", cursor: "pointer", fontSize: "15px", lineHeight: 1.4, color: "#1F2D2A", border: "1.5px solid " + (on ? "var(--hs-primary, #0E4B43)" : "#D9E5DE"), background: on ? "#E4F0E9" : "#fff" } },
            React.createElement("input", { type: "checkbox", checked: on, onChange: () => toggleItem(it.id), style: { width: "26px", height: "26px", flexShrink: 0, accentColor: "var(--hs-primary, #0E4B43)", margin: 0 } }),
            it.label
          );
        }),
        // বুকে ব্যথা বাছলে অতিরিক্ত প্রশ্ন ঠিক ওই গ্রুপের নিচে (Arch B §5.4.1.1; আগের মতোই শুধু chestPain বাছলে)
        g.key === "chest" && checklist.chestPain && React.createElement(
          "div", { style: { marginTop: "4px", marginBottom: "8px", padding: "8px 14px", borderRadius: "14px", background: "#FFF7E6", border: "1px solid #E8C46B" } },
          React.createElement("div", { style: { fontSize: "14px", fontWeight: 600, color: "#7A5B00", marginBottom: "4px" } }, "বুকে ব্যথা সংক্রান্ত অতিরিক্ত প্রশ্ন (bystander-aspirin বিবেচনার জন্য):"),
          CARDIAC_BYSTANDER_QUESTIONS.map((q) => checkboxLine(q.label, !!cardiacAnswers[q.id], () => toggleCardiacAnswer(q.id)))
        )
      ))
    ),

    ageGroup && isPediatricAgeGroup(ageGroup) && React.createElement(
      "div", { style: { marginTop: "12px" } },
      SelectField("প্রধান সমস্যা (chief complaint)", chiefComplaint, (v) => { setChiefComplaint(v); setResult(null); }, CHIEF_COMPLAINTS),
      chiefComplaint === "fever" && TextField("জ্বর কতদিন ধরে (দিন সংখ্যা)", feverDays, (v) => { setFeverDays(v); setResult(null); }, "যেমন: 2"),
      chiefComplaint === "diarrhea" && React.createElement(
        React.Fragment, null,
        TextField("ডায়রিয়া কতদিন ধরে (দিন সংখ্যা)", diarrheaDays, (v) => { setDiarrheaDays(v); setResult(null); }, "যেমন: 3"),
        checkboxLine("মলে রক্ত আছে", bloodyStool, check(setBloodyStool))
      ),
      chiefComplaint === "cough" && React.createElement(
        React.Fragment, null,
        checkboxLine("শিশু স্থির/শান্ত থাকা অবস্থায়ও শ্বাসের সাথে শব্দ (stridor)", stridorCalm, check(setStridorCalm)),
        checkboxLine("শ্বাস নেওয়ার সময় বুক দেবে যাচ্ছে (chest indrawing)", chestIndrawing, check(setChestIndrawing)),
        checkboxLine("দ্রুত শ্বাস-প্রশ্বাস (fast breathing)", fastBreathing, check(setFastBreathing)),
        checkboxLine("কাশি ১৪ দিনের বেশি ধরে", cough14Days, check(setCough14Days))
      ),
      chiefComplaint === "ear" && React.createElement(
        React.Fragment, null,
        checkboxLine("কানের পেছনে ফোলা/ব্যথা (tenderness)", earSwellingTender, check(setEarSwellingTender)),
        checkboxLine("কানে ব্যথা/স্রাব হচ্ছে", earPainDischarge, check(setEarPainDischarge)),
        earPainDischarge && TextField("কতদিন ধরে (দিন সংখ্যা)", earDurationDays, (v) => { setEarDurationDays(v); setResult(null); }, "যেমন: 5")
      ),
      chiefComplaint === "measles" && React.createElement(
        React.Fragment, null,
        checkboxLine("গুরুতর জটিলতা (খুব অসুস্থ/গভীর মুখের ঘা/কর্নিয়া মেঘলা)", measlesSevere, check(setMeaslesSevere)),
        checkboxLine("চোখ/মুখে হালকা জটিলতা (পুঁজ/ঘা)", measlesEyeMouth, check(setMeaslesEyeMouth)),
        checkboxLine("বর্তমানে বা গত ৩ মাসে হাম হয়েছে, জটিলতা ছাড়া", measlesCurrent, check(setMeaslesCurrent))
      )
    ),

    // স্থির বার: কয়টা বেছেছেন + "চেক করুন" (স্ক্রল করলেও নিচে থাকে)
    checklistItems.length > 0 && React.createElement(
      "div", { style: { position: "sticky", bottom: "-12px", zIndex: 2, margin: "12px -12px -12px", padding: "8px 12px 12px", background: "linear-gradient(180deg, rgba(241,246,242,0), #F1F6F2 28%)" } },
      React.createElement("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "13px", color: "#5F716C" } },
        React.createElement("b", { style: { color: "var(--hs-primary, #0E4B43)" } }, bnNum(checklistItems.filter((it) => checklist[it.id]).length) + "টি বেছেছেন"),
        React.createElement("span", null, "না বাছলেও চেক করা যায়")),
      PrimaryButton("চেক করুন", runCheck)
    ),

    result && React.createElement(TriageResultView, { result }),
    result && aspirinCheck && React.createElement(BystanderAspirinCard, { check: aspirinCheck }),

    contextErr && React.createElement("div", { style: { fontSize: "14px", color: "#C0392B", marginTop: "8px" } }, "Health Context তৈরি করা যায়নি: " + contextErr),
    healthContext && React.createElement(
      "details", { style: { marginTop: "10px", fontSize: "14px", color: "#4B5C57" } },
      React.createElement("summary", null, "Health Context (dev-preview)"),
      React.createElement("pre", { style: { whiteSpace: "pre-wrap", background: "#EEF5F0", padding: "8px", borderRadius: "10px" } }, JSON.stringify(healthContext, null, 2))
    ),

    episodeSaveErr && React.createElement(
      "div", { style: { fontSize: "14px", color: "#C0392B", marginTop: "6px" } },
      "Episode/conversation history সংরক্ষণ করা যায়নি (triage/AI ফলাফল অপ্রভাবিত): " + episodeSaveErr
    ),

    // Cloud AI Hosting Disclosure (roadmap §13) — AI-call-এর আগে স্পষ্ট, non-intrusive
    // transparency নোটিস (existing details/summary pattern reuse, healthContext dev-
    // preview block-এর মতোই)।
    healthContext && React.createElement(
      "details", { style: { marginTop: "12px", fontSize: "14px", color: "#3E4E49", background: "#F3F6F5", padding: "8px 10px", borderRadius: "10px", border: "1px solid #D3E0D9" } },
      React.createElement("summary", { style: { cursor: "pointer", fontWeight: 600, color: "var(--hs-primary, #0E4B43)" } }, "🔒 AI ব্যবহারের গোপনীয়তা তথ্য"),
      React.createElement(
        "div", { style: { marginTop: "6px", lineHeight: "1.5" } },
        "এই প্রশ্নোত্তরের জন্য ক্লাউড-ভিত্তিক AI (Groq) ব্যবহার করা হচ্ছে। Zero Data Retention (ZDR) মোড সক্রিয় থাকায় Groq এই তথ্য দিয়ে কোনো মডেল ট্রেইন করে না। আপনার নাম, ফোন নম্বর বা সরাসরি পরিচয়সূচক কোনো তথ্য কখনো পাঠানো হয় না — শুধু বয়স-গ্রুপ ও প্রাসঙ্গিক লক্ষণ/স্বাস্থ্য-তথ্য পাঠানো হয়।"
      )
    ),

    healthContext && React.createElement(
      "div", { style: { marginTop: "12px" } },
      PrimaryButton("AI-কে জিজ্ঞাসা করুন", handleAskAI, aiLoading),
      aiRetryNote && React.createElement("div", { style: { fontSize: "14px", color: "#7A5B00", marginTop: "4px" } }, aiRetryNote)
    ),

    aiErr && React.createElement(
      "div", { style: { fontSize: "14px", color: "#C0392B", marginTop: "8px" } },
      "AI response পাওয়া যায়নি: " + aiErr
    ),

    // roadmap §12.0 — output কখনো "Prescription" হিসেবে উপস্থাপন করা যাবে না,
    // স্পষ্ট লেবেল বাধ্যতামূলক। §4.3 Risk-Based Presentation (P6 ধাপ ৬) — riskLevel/
    // ageGroupContext অনুযায়ী Medical Science primary/expanded (high-risk-এ) বা
    // তিন mode পাশাপাশি (low-risk-এ) সাজানো হয়। Herbal/Homeopathy এখানে নিজস্ব
    // AI-content generate করে না — শুধু নিচের RemedySection (verified remedy
    // reference)-এর দিকে পয়েন্ট করে, dose/prescription-জাতীয় কিছু bypass হয় না।
    aiResponse && React.createElement(RiskBasedTreatmentModes, {
      riskLevel: result && result.riskLevel,
      // গর্ভবতী/দুগ্ধদানকারী (প্রোফাইল, ধাপ ৬) হলে high-risk উপস্থাপনা — শুধু Herbal/Homeopathy-কে গৌণ রাখে; triage-ফল/riskLevel অপরিবর্তিত
      ageGroupContext: isPregnant && !(result && isPediatricAgeGroup(result.ageGroupContext)) ? "pregnant" : (result && result.ageGroupContext),
      // এই সদস্যের active/chronic-status Condition-এ chronicManagement:true থাকলে
      // (HealthRecordForm.js checkbox থেকে সেট করা) এখন actual value ব্যবহার হয় —
      // আগে hardcode false ছিল (checklist §৭ known-gap, এখন resolved)।
      chronicManagement: hasChronicCondition,
      medicalScienceNode: React.createElement(
        "div", { style: { background: "#EAF6F0", padding: "12px", borderRadius: "14px", border: "1px solid #A9D8C4" } },
        React.createElement("div", { style: { fontSize: "14px", fontWeight: 700, color: "#7A5B00", marginBottom: "4px", letterSpacing: "0.2px" } }, "AI Health Guidance — Not a Medical Prescription"),
        React.createElement("div", { style: { fontSize: "14px", fontWeight: 600, color: "var(--hs-primary, #0E4B43)", marginBottom: "6px" } }, "AI Guidance" + (episodeId ? "" : " (dev-preview — episode save হয়নি)")),
        React.createElement("div", { style: { fontSize: "14px", whiteSpace: "pre-wrap", color: "#1F2D2A" } }, renderRichText(aiResponse))
      ),
      herbalNode: React.createElement(
        "div", { style: { fontSize: "14px", color: "#3E4E49" } },
        "নিচের \"Herbal / Homeopathy — Evidence-Level Reference\" অংশে যাচাইকৃত ভেষজ প্রতিকার দেখুন।"
      ),
      homeopathyNode: React.createElement(
        "div", { style: { fontSize: "14px", color: "#3E4E49" } },
        "নিচের \"Herbal / Homeopathy — Evidence-Level Reference\" অংশে যাচাইকৃত হোমিওপ্যাথি প্রতিকার দেখুন।"
      ),
    }),

    // Post-Guidance Discussion Layer (স্তর-৩, §10.3) — শুধু প্রথম AI-response আসার পর সক্রিয়।
    aiResponse && React.createElement(
      "div", { style: { marginTop: "14px" } },
      discussionLog.length > 0 && React.createElement(
        "div", { style: { marginBottom: "8px" } },
        discussionLog.map((m, i) => React.createElement(
          "div", {
            key: i,
            style: {
              marginTop: "6px", fontSize: "14px", whiteSpace: "pre-wrap",
              background: m.role === "user" ? "#F0F0EA" : "#EAF6F0",
              padding: "8px", borderRadius: "10px",
            },
          },
          React.createElement("b", null, m.role === "user" ? "আপনি: " : "AI: "), renderRichText(m.content)
        ))
      ),
      // Re-triage nudge (§10.3 স্তর-৩) — নতুন/ভিন্ন উপসর্গে deterministic triage
      // আবার চালানো উচিত; কোনো AI-based auto-detection না (triage bright-line
      // non-bypassable থাকার নীতি, Process Rule ৫)। existing handleArchiveAndStartNew
      // reuse — নতুন logic/state নেই।
      React.createElement(
        "div", { style: { fontSize: "14px", color: "#7A5B00", marginBottom: "8px" } },
        "⚠️ নতুন বা ভিন্ন উপসর্গ দেখা দিলে, দয়া করে আলোচনা চালিয়ে যাওয়ার বদলে নতুন Symptom Check চালান।",
        React.createElement(
          "div", { style: { marginTop: "6px" } },
          SecondaryButton("নতুন Symptom Check শুরু করুন", handleArchiveAndStartNew)
        )
      ),
      TextField("আরও জিজ্ঞাসা করুন (ঐচ্ছিক)", followUpText, setFollowUpText, "যেমন: এটার সাথে কি কিছু খাওয়া নিরাপদ?"),
      PrimaryButton("পাঠান", handleSendFollowUp, followUpLoading),
      followUpRetryNote && React.createElement("div", { style: { fontSize: "14px", color: "#7A5B00", marginTop: "4px" } }, followUpRetryNote),
      followUpErr && React.createElement("div", { style: { fontSize: "14px", color: "#C0392B", marginTop: "6px" } }, "পাঠানো যায়নি: " + followUpErr)
    ),

    showLengthNudge && React.createElement(
      "div", { style: { marginTop: "14px", background: "#FFF7E6", padding: "10px", borderRadius: "14px", border: "1px solid #E8C46B", fontSize: "14px", color: "#7A5B00" } },
      "এই আলোচনা বেশ দীর্ঘ হয়ে গেছে — নতুন সমস্যায় নতুন Health Episode শুরু করা ভালো।",
      React.createElement("div", { style: { marginTop: "8px" } }, PrimaryButton("সংরক্ষণ করে নতুন Episode শুরু করুন", handleArchiveAndStartNew))
    )
  );
}
