import { t } from "../../shared/i18n.js";
// Document/Report vault section। Permission enforcement সবসময় server-side
// rules (firestore.rules + storage.rules) করে (Process Rule ৪)।
//
// member-selector unification (owner-request): নিজস্ব member-fetch/dropdown
// সরিয়ে parent (DocumentsPageSection)-এর `selectedMemberId` প্রপ ব্যবহার।
//
// নথিপত্র-reorg (owner-approved, ২০২৬-১১-০৮): তালিকা এখন সবার আগে; একটাই
// "＋ নতুন যোগ করুন" বোতাম পুরো প্যানেল (আপলোড → ঐচ্ছিক AI/OCR বিশ্লেষণ → হাতে-লেখা)
// খোলে। কোনো schema/rules/permission পরিবর্তন নেই।

import { SheetFrame } from "../../shared/ui.js";
import { DocumentUploadForm } from "./DocumentUploadForm.js";
import { DocumentList } from "./DocumentList.js";
import { fetchDocumentFile } from "./documentsData.js";
import { ReportAnalysisPanel } from "../reports/ReportAnalysisPanel.js";
import { PrescriptionPanel } from "../prescriptions/PrescriptionPanel.js";
import { DoctorCardPanel } from "../doctor-details/DoctorCardPanel.js";
import { useMemberHealth } from "../records/useMemberHealth.js";

const { useState, useCallback, useEffect } = React;
import { takeQuickIntent, takeQuickOrigin, quickReturn } from "../../shared/quickIntent.js";

export function DocumentsSection({ familyId, callerMemberId, selectedMemberId, excludeType, hideAdd, emptyText }) {
  const [refreshTick, setRefreshTick] = useState(0);
  // panel: null | { mode: "add" } | { mode: "analyze", file } | { mode: "manual" }
  const [panel, setPanel] = useState(null);
  const targetMemberId = selectedMemberId;
  // প্রেসক্রিপশন-কার্ডে "এই প্রেসক্রিপশনের ওষুধ: …" লাইনের জন্য (শুধু পড়া; শেয়ার্ড cache)
  const { records: memberRecords } = useMemberHealth(familyId, targetMemberId);
  const medsByDoc = {};
  (memberRecords || []).forEach((r) => { if (r.resourceType === "medicationStatement" && r.prescriptionDocId && r.genericName) (medsByDoc[r.prescriptionDocId] = medsByDoc[r.prescriptionDocId] || []).push(r.genericName); });
  const fromRef = React.useRef(null); // "+" যে ট্যাব থেকে চাপা (✕ দিলে সেখানে ফেরা)
  useEffect(() => { if (takeQuickIntent(["report"])) { fromRef.current = takeQuickOrigin(); setPanel({ mode: "add" }); } }, []); // "+ দ্রুত যোগ" → রিপোর্ট (ধাপ ৯)

  const refresh = useCallback(() => setRefreshTick((n) => n + 1), []);
  const startAnalyze = useCallback((file, preOcr, docId) => setPanel({ mode: "analyze", file, preOcr, docId, key: Date.now() }), []);
  const startPrescription = useCallback((file, preOcr, docId) => setPanel({ mode: "prescription", file, preOcr, docId, key: Date.now() }), []);
  // সংরক্ষিত রিপোর্ট আবার বিশ্লেষণ: ফাইল নামিয়ে একই বিশ্লেষণ-ফ্লোতে (docId সহ, তাই নতুন মান একই রিপোর্টে লিংক হয়)
  const reanalyze = useCallback(async (d) => {
    const file = await fetchDocumentFile(d);
    setPanel({ mode: "analyze", file, preOcr: null, docId: d.id, key: Date.now() });
  }, []);
  const startCard = useCallback((file, preOcr) => setPanel({ mode: "card", file, preOcr, key: Date.now() }), []);
  const startManual = useCallback(() => setPanel({ mode: "manual", key: Date.now() }), []);

  if (!targetMemberId) {
    return React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "সদস্য বেছে নিন।");
  }

  const panelTitle = panel && ({ add: "📎 নতুন নথি যোগ করুন", analyze: "🔬 রিপোর্ট বিশ্লেষণ", manual: "✍️ হাতে-লেখা রিপোর্ট", prescription: "💊 প্রেসক্রিপশন থেকে ওষুধ", card: "📇 ডাক্তারের কার্ড" })[panel.mode];

  return React.createElement(
    "div", { style: { marginTop: "12px" } },
    React.createElement(
      "div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" } },
      React.createElement("h3", { style: { fontSize: "16px", color: "var(--hs-primary, #0E4B43)", margin: 0 } }, t("h.docs")),
      !panel && !hideAdd && React.createElement("button", {
        onClick: () => setPanel({ mode: "add" }),
        style: { minHeight: "42px", padding: "8px 16px", border: "none", borderRadius: "999px", background: "linear-gradient(135deg, var(--hs-primary, #0E4B43), var(--hs-primary-2, #17705F))", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: "pointer", boxShadow: "0 3px 8px rgba(14,75,67,0.25)" },
      }, "＋ নতুন যোগ করুন")
    ),
    // ফুল-পেজ (ওষুধের মতো): যেখান থেকেই যোগ চাপা হোক, উপরে ✕ বন্ধ-বার সহ নিজস্ব পাতায় খোলে
    panel && React.createElement(
      SheetFrame, { accent: "lab", title: panelTitle, onClose: () => { setPanel(null); if (fromRef.current) { fromRef.current = null; quickReturn(); } }, scrollKey: panel.mode + "-" + (panel.key || "") },
      panel.mode === "add" && React.createElement(DocumentUploadForm, {
        key: "upload-" + targetMemberId,
        familyId, targetMemberId, callerMemberId,
        onUploaded: refresh, onAnalyze: startAnalyze, onManual: startManual, onPrescription: startPrescription, onCard: startCard,
      }),
      panel.mode === "analyze" && React.createElement(ReportAnalysisPanel, {
        key: "analyze-" + targetMemberId + "-" + panel.key,
        familyId, targetMemberId, callerMemberId, presetFile: panel.file, preOcr: panel.preOcr, docId: panel.docId,
      }),
      panel.mode === "prescription" && React.createElement(PrescriptionPanel, {
        key: "rx-" + targetMemberId + "-" + panel.key,
        familyId, targetMemberId, callerMemberId, file: panel.file, preOcr: panel.preOcr, docId: panel.docId, onClose: () => setPanel(null),
      }),
      panel.mode === "card" && React.createElement(DoctorCardPanel, {
        key: "card-" + targetMemberId + "-" + panel.key,
        familyId, callerMemberId, file: panel.file, preOcr: panel.preOcr, onClose: () => setPanel(null),
      }),
      panel.mode === "manual" && React.createElement(ReportAnalysisPanel, {
        key: "manual-" + targetMemberId + "-" + panel.key,
        familyId, targetMemberId, callerMemberId, initialManual: true,
      })
    ),
    React.createElement(DocumentList, {
      key: "list-" + targetMemberId, familyId, targetMemberId, callerMemberId, refreshTick,
      onReanalyze: reanalyze, onDeleted: refresh, onAdd: hideAdd ? undefined : () => setPanel({ mode: "add" }), excludeType, emptyText, medsByDoc,
    })
  );
}
