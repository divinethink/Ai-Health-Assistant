// আজ ট্যাব — খাবার-লগ শিট (ধাপ ২)। শুধু UI; হিসাব foodCalc.js (pure), সংরক্ষণ বাবা (TodayTab) করে।
// ধাপ: ১) বেলা বাছাই + খাবার খোঁজা (বিদ্যমান FoodPicker: ✓/!/✕ স্ট্যাটাস, এলার্জি-সতর্কতা) ২) পরিমাণ (মাপ বা গ্রাম) + লাইভ ক্যালরি/ম্যাক্রো → যোগ।
// নতুন যোগে (এডিট নয়) বাস্কেট: খাবারে ট্যাপ = বাছা/বাদ; "পরিমাণ ঠিক করুন" পাতায় সব খাবারের পরিমাণ একসাথে → একটাই লেখায় (onAddMany) সংরক্ষণ। এডিটে আগের একক ধাপ।
// ✕ (এড়ানো/এলার্জি) হলে ব্লক নয় — সতর্কতা দেখিয়ে "তবু যোগ করুন"। ওষুধ-নোট বিদ্যমান medFoodNotes থেকে।

import { bnNum } from "../../shared/dates.js";
import { foodEnglish } from "../../shared/searchAliases.js";
import { FOODS, MEAL_SLOTS, hasFoodOverride, foodK } from "./mealPlanData.js";
import { medFoodNotes } from "./medFoodNotes.js";
import { foodStatus, STATUS_COLORS } from "./foodStatus.js";
import { MAX_QTY, MAX_LIST } from "./planPrefs.js";
import { nutritionOf } from "./foodNutrition.js";
import { per100Of, measuresOf, buildFoodEntry, buildOwnFoodEntry, slotForNow, fmtMacro, entryAmountText, MAX_MEASURE_QTY } from "./foodCalc.js";
import { Sheet, FoodPicker, Msg, BTN, INPUT, primaryBtn } from "./PlanEditSheets.js";
import { ConfirmDialog } from "../../shared/ui.js";

const { useState } = React;

// পরিমাণ-ধাপের শুরুর মান (সাম্প্রতিক/এডিটের আগের এন্ট্রি থেকে; অবৈধ হলে ডিফল্ট)
function initPick(k, pre) {
  const ms = measuresOf(k);
  const unit = !ms.length || hasFoodOverride(k);
  let mId = unit ? null : ms[0].id, q = 1, gt = ms.length ? String(ms[0].g) : "";
  if (pre) {
    const pq = Number(pre.qty);
    if (unit) { if (pq > 0) q = pq; }
    else if (pre.measure && ms.some((m) => m.id === pre.measure) && pq > 0) { mId = pre.measure; q = pq; }
    else if (Number(pre.grams) > 0) { mId = "g"; gt = String(pre.grams); }
  }
  return { mId, q, gt };
}

const bid = (b) => b.key + "|" + b.slot; // বাস্কেট-আইটেমের পরিচয় (খাবার + বেলা)
const unitModeOf = (k) => !nutritionOf(k) || hasFoodOverride(k);
const entryOfItem = (b, slot) => buildFoodEntry(b.key, b.slot || slot, unitModeOf(b.key) ? { qty: b.q } : { measureId: b.mId, qty: b.q, grams: b.gt });

const GREEN = "var(--hs-primary, #0E4B43)";
const MUTED = "#5F716C";
const chip = (on) => ({ ...BTN, fontWeight: 600, padding: "6px 12px", border: "1.5px solid " + (on ? GREEN : "#C3D2CA"), background: on ? GREEN : "#fff", color: on ? "#fff" : "#1F2D2A" });
const MACROS = [["প্রোটিন", "p", "#2FAE6B"], ["কার্ব", "c", "#E88A2D"], ["ফ্যাট", "f", "#7C69C9"], ["ফাইবার", "fib", "#3B8ED8"]];

// বাস্কেটের একটি সারি (কমপ্যাক্ট, ২ লাইন): নাম + ক্যালরি + ✕ / [− সংখ্যা +] + মাপ-ড্রপডাউন (বাটি ▾ | গ্রাম)। onChange(patch) = {q, mId, gt}।
function BasketRow({ b, slot, slotText, allergyTags, avoidCtx, activeMeds, onChange, onRemove }) {
  const h = React.createElement;
  const k = b.key, f = FOODS[k], unit = unitModeOf(k), ms = measuresOf(k), gramMode = b.mId === "g";
  const entry = entryOfItem(b, slot);
  const st = foodStatus(k, f, { allergyTags, ctx: avoidCtx }), sc = STATUS_COLORS[st.level];
  const notes = medFoodNotes(activeMeds, k);
  const maxQty = unit ? MAX_QTY : MAX_MEASURE_QTY;
  const step = (d) => onChange({ q: Math.max(0.5, Math.round((b.q + d) * 2) / 2) });
  const incOk = !gramMode && b.q + 0.5 <= maxQty && (unit || buildFoodEntry(k, b.slot || slot, { measureId: b.mId, qty: b.q + 0.5 }));
  const sm = (label, onClick, disabled, aria) => h("button", { type: "button", onClick, disabled, "aria-label": aria, style: { width: "40px", height: "40px", borderRadius: "50%", border: "none", background: "#E4ECE7", color: GREEN, fontSize: "20px", fontWeight: 700, cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.4 : 1, flexShrink: 0, fontFamily: "inherit", padding: 0 } }, label);
  const onMeasure = (e) => { const v = e.target.value; if (v === "g") onChange({ mId: "g", gt: entry && entry.grams ? String(entry.grams) : b.gt }); else onChange({ mId: v, q: 1 }); };
  return h("div", { style: { border: "1px solid " + (st.level === "green" ? "rgba(127,150,140,0.25)" : sc.border), background: "#fff", borderRadius: "14px", padding: "8px 10px", marginTop: "6px" } },
    h("div", { style: { display: "flex", alignItems: "center", gap: "8px" } },
      h("div", { style: { flex: 1, minWidth: 0, fontSize: "15px", fontWeight: 800, color: "#1F2D2A", overflowWrap: "anywhere", lineHeight: 1.25 } }, f.n, slotText && h("span", { style: { marginLeft: "6px", fontSize: "11px", fontWeight: 700, color: MUTED, background: "#E4ECE7", borderRadius: "8px", padding: "1px 6px", whiteSpace: "nowrap" } }, slotText)),
      h("div", { style: { flexShrink: 0, color: GREEN, fontWeight: 800, fontSize: "16px", whiteSpace: "nowrap" } }, entry ? bnNum(entry.kcal) : "—", h("span", { style: { fontSize: "11px", fontWeight: 500, color: "#8A9B95" } }, " কিলোক্যালরি")),
      h("button", { type: "button", onClick: onRemove, "aria-label": f.n + " বাদ দিন", style: { width: "32px", height: "32px", flexShrink: 0, borderRadius: "50%", border: "none", background: "#EEF3F0", color: "#5F716C", fontSize: "13px", cursor: "pointer", fontFamily: "inherit", padding: 0 } }, "✕")),
    st.level !== "green" && h("div", { style: { fontSize: "12.5px", color: sc.text, marginTop: "3px", lineHeight: 1.4 } }, st.icon + " " + st.label + (st.reasons.length ? " — " + st.reasons.join("; ") : "")),
    h("div", { style: { display: "flex", alignItems: "center", flexWrap: "wrap", gap: "6px 8px", marginTop: "6px" } },
      !gramMode && h("div", { style: { display: "flex", alignItems: "center", gap: "4px" } },
        sm("−", () => step(-0.5), b.q <= 0.5, f.n + " পরিমাণ কমান"),
        h("span", { style: { minWidth: "38px", textAlign: "center", fontSize: "18px", fontWeight: 800, color: "#1F2D2A" } }, bnNum(b.q)),
        sm("+", () => step(0.5), !incOk, f.n + " পরিমাণ বাড়ান")),
      gramMode && h("input", { type: "number", inputMode: "decimal", min: 1, max: 2000, step: "any", value: b.gt, onChange: (e) => onChange({ gt: e.target.value }), "aria-label": f.n + " — গ্রাম", placeholder: "গ্রাম (১–২০০০)", style: { ...INPUT, flex: "1 1 90px", minWidth: 0, minHeight: "40px", padding: "4px 10px", fontSize: "16px", fontWeight: 700, textAlign: "center" } }),
      unit
        ? h("span", { style: { fontSize: "13px", color: MUTED } }, "ইউনিট: " + f.u)
        : h("select", { value: gramMode ? "g" : b.mId, onChange: onMeasure, "aria-label": f.n + " — মাপ", style: { minHeight: "40px", padding: "0 8px", borderRadius: "12px", border: "1.5px solid #C3D2CA", background: "#fff", color: "#1F2D2A", fontSize: "14px", fontWeight: 600, fontFamily: "inherit" } },
          ms.map((m) => h("option", { key: m.id, value: m.id }, m.label)), h("option", { key: "g", value: "g" }, "গ্রাম")),
      !gramMode && !unit && entry && entry.grams ? h("span", { style: { fontSize: "12.5px", color: MUTED } }, "≈ " + bnNum(entry.grams) + " গ্রাম") : null),
    notes.map((n, i) => h("div", { key: "n" + i, style: { marginTop: "6px", padding: "5px 10px", borderRadius: "10px", background: "#FFF6DD", border: "1px solid #E8D08A", color: "#7A5B00", fontSize: "12.5px", lineHeight: 1.5 } }, "💊 " + n.text)));
}

// props: allergyTags, avoidCtx, activeMeds, count (আজ নিজে-যোগ-করা মোট), slotBudgets (ঐচ্ছিক, foodCalc.slotBudgets), recent (ঐচ্ছিক, foodCalc.recentFoodEntries), busy, err, onAdd(entry) → Promise<boolean>, onAddMany(entries) → Promise<boolean> (বাস্কেট; একটাই লেখা), onClose
export function FoodLogSheet({ editEntry, dateText, slots, initialSlot, pickFirst, allergyTags, avoidCtx, activeMeds, count, slotBudgets, recent, busy, err, onAdd, onAddMany, onClose }) {
  // এডিট: লগ করা খাবারে ট্যাপ করলে আগের পরিমাণসহ খোলে; "সংরক্ষণ" পুরনো এন্ট্রি বদলায় (নতুন যোগ নয়)
  const editKey = editEntry && editEntry.key && FOODS[editEntry.key] ? editEntry.key : null;
  const [slot, setSlot] = useState((editEntry && editEntry.slot) || initialSlot || slotForNow());
  const [stage, setStage] = useState(pickFirst && !editEntry ? "pick" : "food"); // "pick" = বেলার তালিকা (Healthify-র মতো), "food" = খাবার খোঁজা
  const pre0 = editKey ? initPick(editKey, editEntry) : null;
  const [key, setKey] = useState(editKey);
  const [measureId, setMeasureId] = useState(pre0 ? pre0.mId : null); // measure id | "g" (গ্রাম)
  const [qty, setQty] = useState(pre0 ? pre0.q : 1);
  const [gramsText, setGramsText] = useState(pre0 ? pre0.gt : "");
  const [notice, setNotice] = useState(null);
  const s0 = (v) => (v === undefined || v === null ? "" : String(v));
  const [own, setOwn] = useState(editEntry && !editKey ? { name: s0(editEntry.name), kcal: s0(editEntry.kcal), grams: s0(editEntry.grams), p: s0(editEntry.p), c: s0(editEntry.c), f: s0(editEntry.f), fib: s0(editEntry.fib) } : null); // null = বন্ধ; অবজেক্ট = "নিজে যোগ করুন" ফর্ম
  const [ownErr, setOwnErr] = useState(null);
  const [showInfo, setShowInfo] = useState(false); // "হিসাবের তথ্য" ভাঁজ
  const multi = !editEntry; // নতুন যোগে বাস্কেট; এডিটে আগের একক ধাপ
  const [basket, setBasket] = useState([]); // [{key, mId, q, gt}]
  const [basketOpen, setBasketOpen] = useState(false);
  const [askClose, setAskClose] = useState(false); // বাছা খাবার থাকা অবস্থায় ✕/Back/বাইরে-চাপ → "বাদ দেবেন?"
  const slotList = slots || MEAL_SLOTS;
  const slotLabel = (slotList.find((s) => s.id === slot) || {}).label;
  const full = count >= MAX_LIST;

  // pre (ঐচ্ছিক) = সাম্প্রতিক এন্ট্রি: আগের বারের মাপ/পরিমাণ/গ্রাম আগে থেকে বসে; অবৈধ হলে ডিফল্ট।
  const pick = (k, pre) => {
    const { mId, q, gt } = initPick(k, pre);
    setKey(k); setNotice(null); setQty(q); setMeasureId(mId); setGramsText(gt);
  };
  const back = () => { setKey(null); };
  const room = Math.max(0, MAX_LIST - count);
  const guardedClose = () => { if (multi && basket.length > 0) setAskClose(true); else onClose(); };
  const closeAsk = askClose && React.createElement(ConfirmDialog, { title: "বাছা খাবার বাদ দেবেন?", message: bnNum(basket.length) + "টি খাবার বাছা আছে, এখনো যোগ হয়নি। বন্ধ করলে বাছাই মুছে যাবে।", confirmLabel: "বাদ দিন", cancelLabel: "বাছাই রাখুন", zIndex: 300, onConfirm: () => { setAskClose(false); onClose(); }, onCancel: () => setAskClose(false) });
  // বাস্কেটে বাছা/বাদ। addOnly = সাম্প্রতিক-চিপ (দ্বিতীয়বার ট্যাপে বাদ নয়)। ✕ খাবারও বাছা যায়; সতর্কতা পরের পাতায়।
  // একই খাবার আলাদা বেলায় আলাদা আইটেম: পরিচয় = খাবার + বেলা
  const sameItem = (x, k, sl) => x.key === k && x.slot === sl;
  const toggleBasket = (k, pre, addOnly) => {
    if (basket.some((x) => sameItem(x, k, slot))) { if (!addOnly) { setBasket((cur) => cur.filter((x) => !sameItem(x, k, slot))); setNotice(null); } return; }
    if (basket.length >= room) { setNotice("আজকের জন্য নিজে-যোগ-করা খাবারের সীমা (" + bnNum(MAX_LIST) + "টি) পূর্ণ।"); return; }
    const { mId, q, gt } = initPick(k, pre);
    setBasket((cur) => (cur.some((x) => sameItem(x, k, slot)) ? cur : [...cur, { key: k, mId, q, gt, slot }])); setNotice(null);
  };
  const patchItem = (id, patch) => setBasket((cur) => cur.map((x) => (bid(x) === id ? { ...x, ...patch } : x)));
  const removeItem = (id) => { setBasket((cur) => cur.filter((x) => bid(x) !== id)); if (basket.length <= 1) setBasketOpen(false); };

  // সাম্প্রতিক খাবার: ✕ (এড়ানো/এলার্জি) স্ট্যাটাসের খাবার এখানে আসে না — খুঁজে সতর্কতাসহ যোগ করতে হবে।
  // তালিকার খাবার ট্যাপে পরিমাণ-ধাপ খোলে (আগের মাপ বসানো, কয়টি/কত গ্রাম দেখে "যোগ করুন"); শুধু নিজে-যোগ-করা (key নেই) খাবার সরাসরি যোগ হয়।
  const quick = (Array.isArray(recent) ? recent : []).filter((e) => {
    const f0 = e.key && FOODS[e.key];
    return !f0 || foodStatus(e.key, f0, { allergyTags, ctx: avoidCtx }).level !== "red";
  });
  const openQuick = (e) => { if (e.key && FOODS[e.key]) { if (multi) toggleBasket(e.key, e, true); else pick(e.key, e); } else quickAdd(e); };
  const quickAdd = async (e) => {
    if (busy || full) return;
    const ok = await onAdd({ ...e, slot });
    if (ok) setNotice("✓ " + e.name + (entryAmountText(e) ? " · " + entryAmountText(e) : "") + " · " + bnNum(e.kcal) + " কিলোক্যালরি — " + slotLabel + "-এ যোগ হয়েছে। ভুল হলে আজকের তালিকা থেকে ✕ দিয়ে মুছুন।");
  };

  // ---------- নিজে যোগ করুন (খাবার ডেটায় না পেলে) ----------
  if (!key && own) {
    const setF = (k) => (e) => setOwn({ ...own, [k]: e.target.value });
    const field = (label, k, ph, mode) => React.createElement("div", { style: { flex: 1, minWidth: "40%" } },
      React.createElement("label", { style: { display: "block", fontSize: "13px", color: MUTED, margin: "8px 0 4px" } }, label),
      React.createElement("input", { type: mode === "text" ? "text" : "number", inputMode: mode === "text" ? "text" : "decimal", min: 0, step: "any", value: own[k], onChange: setF(k), placeholder: ph, "aria-label": label, style: INPUT }));
    const saveOwn = async () => {
      const r = buildOwnFoodEntry(slot, own, count);
      if (r.error) { setOwnErr(r.error); return; }
      setOwnErr(null);
      const ok = await onAdd(r.entry);
      if (ok) { if (editEntry) { onClose(); return; } setNotice("✓ " + r.entry.name + " যোগ হয়েছে (" + slotLabel + ") — পরে ‘সাম্প্রতিক’-এ ১ ট্যাপে পাবেন"); setOwn(null); }
    };
    return React.createElement(Sheet, { title: "নিজে যোগ করুন", subtitle: slotLabel + " · আপনার দেওয়া আনুমানিক মান", onClose, soft: true },
      React.createElement("button", { onClick: () => { setOwn(null); setOwnErr(null); }, style: { ...BTN, border: "none", background: "#EEF3F0", color: GREEN, marginBottom: "6px" } }, "← খাবার খুঁজুন"),
      field("খাবারের নাম (যেমন: মায়ের হাতের খিচুড়ি)", "name", "নাম", "text"),
      React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "8px" } },
        field("কিলোক্যালরি (বাধ্যতামূলক)", "kcal", "০–৩০০০"), field("গ্রাম (ঐচ্ছিক)", "grams", "যেমন ২৫০")),
      React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", marginTop: "12px" } }, "ম্যাক্রো, গ্রামে (ঐচ্ছিক)"),
      React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "8px" } },
        field("প্রোটিন", "p", "০"), field("কার্ব", "c", "০"), field("ফ্যাট", "f", "০"), field("ফাইবার", "fib", "০")),
      React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "8px", lineHeight: 1.5 } }, "ম্যাক্রোর কোনো একটি দিলে ফাঁকা ঘর ০ ধরা হবে। না জানলে খালি রাখুন — শুধু কিলোক্যালরি ধরা হবে।"),
      (ownErr || err) && Msg(ownErr || err, "err"),
      full && Msg("আজকের জন্য নিজে-যোগ-করা খাবারের সীমা (" + bnNum(MAX_LIST) + "টি) পূর্ণ। আগের কোনোটি মুছুন।", "warn"),
      React.createElement("div", { style: { position: "sticky", bottom: 0, display: "flex", gap: "8px", marginTop: "14px", padding: "10px 0 env(safe-area-inset-bottom, 0px)", background: "#fff" } },
        primaryBtn((editEntry ? "সংরক্ষণ করুন (" : "যোগ করুন (") + slotLabel + ")", saveOwn, busy, full)));
  }

  // ---------- বেলা বাছাই: "খাওয়া / বরাদ্দ" সহ তালিকা ----------
  if (stage === "pick" && !key) {
    return React.createElement(Sheet, { title: "কোন বেলার খাবার যোগ করবেন?", subtitle: (dateText ? dateText + " · " : "") + "বরাদ্দ = আজকের টার্গেটের ভাগ (বেশি হলেও বাধা নেই)", onClose, soft: true },
      slotList.map((s) => {
        const b = slotBudgets && slotBudgets[s.id];
        const over = b && b.eaten > b.planned;
        return React.createElement("button", { key: s.id, type: "button", onClick: () => { setSlot(s.id); setStage("food"); }, "aria-label": s.label + "-এ খাবার যোগ করুন",
          style: { display: "flex", alignItems: "center", gap: "8px", width: "100%", minHeight: "56px", padding: "0 4px", border: "none", borderBottom: "1px solid #E3E0D2", background: "none", fontFamily: "inherit", cursor: "pointer", textAlign: "left" } },
          React.createElement("span", { style: { flex: 1, fontSize: "16px", fontWeight: 700, color: GREEN } }, s.label),
          b && React.createElement("span", { style: { fontSize: "14px", color: over ? "#B26A00" : MUTED, fontWeight: over ? 700 : 500 } }, bnNum(b.eaten) + " / " + bnNum(b.planned) + " কিলোক্যালরি"),
          React.createElement("span", { "aria-hidden": "true", style: { width: "30px", height: "30px", borderRadius: "50%", background: "#E3EFEA", color: GREEN, fontSize: "20px", fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" } }, "＋"));
      }));
  }

  // সাম্প্রতিক: এক লাইনের অনুভূমিক স্ক্রল-সারি (সর্বোচ্চ ৬) — তালিকাকে ঠেলে নামায় না। চিপে আগের পরিমাণ+ক্যালরি; ট্যাপে পরিমাণ-ধাপ।
  // শুধু নাম, ৩ কলাম × ২ সারি (সর্বোচ্চ ৬) — স্ক্রিনে আঁটে; ট্যাপে পরিমাণ-ধাপ। আয়তাকার + বাঁয়ে সবুজ ধার (বেলা-বার/ধরন-ট্যাগ থেকে আলাদা)
  const recentRow = quick.length > 0 && React.createElement("div", { style: { margin: "0 0 16px" } },
    React.createElement("div", { style: { fontSize: "12px", fontWeight: 700, color: MUTED, margin: "2px 2px 6px", letterSpacing: "0.3px" } }, "সাম্প্রতিক খাবার"),
    React.createElement("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "6px" } },
      quick.slice(0, 6).map((e) => React.createElement("button", { key: e.name, type: "button", onClick: () => openQuick(e), disabled: busy || (full && !(e.key && FOODS[e.key])), title: e.name, "aria-label": e.name + " " + (entryAmountText(e) || "") + " — পরিমাণ বেছে " + slotLabel + "-এ যোগ করুন",
        style: { minHeight: "36px", padding: "2px 6px", borderRadius: "12px", cursor: "pointer", fontFamily: "inherit", fontSize: "13.5px", fontWeight: 700, color: "#1F2D2A", lineHeight: 1.2, textAlign: "center", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0,
          border: "1px solid rgba(127,150,140,0.22)", borderLeft: "3px solid #17705F", background: "linear-gradient(180deg, #fff, #F7FAF8)", boxShadow: "0 2px 6px rgba(14,75,67,0.08)", opacity: busy ? 0.5 : 1 } }, e.name))));

  // ---------- বাস্কেট: সব বাছা খাবারের পরিমাণ একসাথে ----------
  if (!key && multi && basketOpen && basket.length > 0) {
    const items = basket.map((b) => ({ b, entry: entryOfItem(b, slot) }));
    const labelOf = (id) => (slotList.find((s) => s.id === id) || {}).label || slotLabel;
    const usedSlots = [...new Set(basket.map((b) => b.slot || slot))];
    const basketLabel = usedSlots.length > 1 ? "একাধিক বেলা" : labelOf(usedSlots[0]);
    const total = items.reduce((t, x) => t + (x.entry ? x.entry.kcal : 0), 0);
    const allOk = items.every((x) => x.entry);
    const anyRed = basket.some((b) => foodStatus(b.key, FOODS[b.key], { allergyTags, ctx: avoidCtx }).level === "red");
    const tooMany = basket.length > room;
    const submitAll = async () => {
      if (busy || !allOk || tooMany || !onAddMany) return;
      const ok = await onAddMany(items.map((x) => x.entry));
      if (ok) { setNotice("✓ " + bnNum(items.length) + "টি খাবার যোগ হয়েছে (" + basketLabel + ")"); setBasket([]); setBasketOpen(false); }
    };
    return React.createElement(Sheet, { title: "পরিমাণ ঠিক করুন", subtitle: basketLabel + " · " + bnNum(items.length) + "টি খাবার", onClose: guardedClose, soft: true },
      closeAsk,
      React.createElement("button", { onClick: () => setBasketOpen(false), style: { ...BTN, border: "none", background: "transparent", color: GREEN, padding: "0 4px", justifyContent: "flex-start", flex: "0 0 auto", minHeight: "44px" } }, "← আরও খাবার বাছুন"),
      items.map((x) => React.createElement(BasketRow, { key: bid(x.b), b: x.b, slot, slotText: usedSlots.length > 1 ? labelOf(x.b.slot || slot) : null, allergyTags, avoidCtx, activeMeds, onChange: (patch) => patchItem(bid(x.b), patch), onRemove: () => removeItem(bid(x.b)) })),
      !allOk && Msg("কোনো খাবারের পরিমাণ সঠিক নয় — গ্রাম ১–২০০০-এর মধ্যে দিন।", "err"),
      anyRed && Msg("⚠ কিছু খাবার আপনার জন্য এড়ানোর কথা। ডাক্তারের পরামর্শ প্রাধান্য পায়; তবু খেলে যোগ করতে পারেন।", "warn"),
      tooMany && Msg("আজকের জন্য নিজে-যোগ-করা খাবারের সীমা (" + bnNum(MAX_LIST) + "টি); আরও " + bnNum(room) + "টি যোগ করা যাবে। কিছু বাদ দিন।", "warn"),
      err && Msg(err, "err"),
      React.createElement("div", { style: { position: "sticky", bottom: 0, marginTop: "10px", padding: "8px 0 env(safe-area-inset-bottom, 0px)", background: "#F3F7F4", boxShadow: "0 -8px 10px -2px #F3F7F4", borderTop: "1px solid #DCE6E0", display: "flex", alignItems: "center", gap: "10px" } },
        React.createElement("div", { style: { flex: "0 0 auto", lineHeight: 1.2 } }, React.createElement("div", { style: { fontSize: "11.5px", color: MUTED } }, "মোট"), React.createElement("div", { style: { fontSize: "15px", fontWeight: 800, color: GREEN, whiteSpace: "nowrap" } }, bnNum(total) + " কিলোক্যালরি")),
        primaryBtn((anyRed ? "তবু " : "") + "সবগুলো যোগ করুন (" + basketLabel + ")", submitAll, busy, !allOk || tooMany)));
  }

  // ---------- ধাপ ১: খোঁজা ----------
  if (!key) {
    return React.createElement(Sheet, { title: "খাবার যোগ করুন", subtitle: dateText || undefined, onClose: guardedClose, soft: true },
      closeAsk,
      // বেলা-চিপ: ছোট, স্ক্রিনে আঁটে (সোয়াইপ/স্ক্রলবার নেই); বেশি হলে নিচের লাইনে নামে
      // বেলা-ট্যাব: একটাই সেগমেন্টেড বার (গোল পিল নয়) — নিচের খাবার-ধরন চিপ থেকে আকারে আলাদা
      React.createElement("div", { style: { fontSize: "12px", fontWeight: 700, color: MUTED, margin: "-6px 2px 6px", letterSpacing: "0.3px" } }, "কোন বেলা?"),
      React.createElement("div", { role: "tablist", "aria-label": "বেলা", style: { display: "flex", gap: "2px", padding: "4px", borderRadius: "16px", background: "#E3ECE6", boxShadow: "inset 0 1px 3px rgba(14,75,67,0.12)", marginBottom: "8px" } },
        slotList.map((s) => { const on = s.id === slot; return React.createElement("button", { key: s.id, type: "button", role: "tab", onClick: () => setSlot(s.id), "aria-selected": on, "aria-pressed": on,
          style: { flex: "1 1 0", minWidth: 0, minHeight: "44px", padding: "4px 2px", borderRadius: "12px", fontSize: "13.5px", fontWeight: on ? 800 : 600, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap", border: "none",
            boxShadow: on ? "0 4px 10px rgba(14,75,67,0.32), inset 0 -3px 0 rgba(255,255,255,0.35)" : "none",
            background: on ? "linear-gradient(135deg, var(--hs-primary, #0E4B43), var(--hs-primary-2, #17705F))" : "transparent", color: on ? "#fff" : "#3E524C" } }, s.label); })),
      // খোঁজা-বার "কোন বেলা?"-র ঠিক নিচে; তার নিচে নোটিশ ও সাম্প্রতিক খাবার (owner-request ২০২৬-১১-১৪)
      React.createElement(FoodPicker, { allergyTags, avoidCtx, onPick: multi ? (k) => toggleBasket(k) : pick, selected: multi ? basket.filter((x) => x.slot === slot).map((x) => x.key) : undefined, layout: "list",
        between: React.createElement(React.Fragment, null,
        notice && React.createElement("div", { role: "status", style: { padding: "8px 12px", borderRadius: "12px", background: "#E4F0E9", border: "1px solid #9CC5B4", color: GREEN, fontSize: "13px", fontWeight: 600, marginBottom: "8px" } }, notice),
        full && Msg("আজকের জন্য নিজে-যোগ-করা খাবারের সীমা (" + bnNum(MAX_LIST) + "টি) পূর্ণ। নতুন যোগ করতে আগের কোনোটি মুছুন।", "warn"),
        recentRow || null) }),
      React.createElement("button", { onClick: () => { setNotice(null); setOwn({ name: "", kcal: "", grams: "", p: "", c: "", f: "", fib: "" }); }, disabled: full,
        style: { ...BTN, width: "100%", marginTop: "10px", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 14px", border: "none", background: "#E4F0E9", color: GREEN, opacity: full ? 0.5 : 1 } },
        React.createElement("span", { style: { fontWeight: 500, color: MUTED } }, "খুঁজে পাচ্ছেন না?"), React.createElement("span", null, "নিজে যোগ করুন →")),
      multi && basket.length > 0 && React.createElement("div", { style: { position: "sticky", bottom: 0, marginTop: "12px", padding: "8px 0 env(safe-area-inset-bottom, 0px)", background: "#F3F7F4", boxShadow: "0 -8px 10px -2px #F3F7F4", borderTop: "1px solid #DCE6E0", display: "flex" } },
        primaryBtn("পরিমাণ ঠিক করুন (" + bnNum(basket.length) + "টি) →", () => setBasketOpen(true), busy, false)),
      React.createElement("div", { style: { display: "flex", gap: "8px", marginTop: "14px" } },
        React.createElement("button", { onClick: guardedClose, style: { ...BTN, flex: 1, border: "1.5px solid " + GREEN, background: "#fff", color: GREEN } }, "শেষ করুন")));
  }

  // ---------- ধাপ ২: পরিমাণ ----------
  const f = FOODS[key];
  const nut = nutritionOf(key);
  const unitMode = !nut || hasFoodOverride(key);
  const ms = measuresOf(key);
  const entry = buildFoodEntry(key, slot, unitMode ? { qty } : { measureId, qty, grams: gramsText });
  const st = foodStatus(key, f, { allergyTags, ctx: avoidCtx });
  const sc = STATUS_COLORS[st.level];
  const notes = medFoodNotes(activeMeds, key);
  const p100 = per100Of(key);
  const gramMode = measureId === "g";
  const maxQty = unitMode ? MAX_QTY : MAX_MEASURE_QTY;
  const step = (d) => setQty((q) => Math.max(0.5, Math.round((q + d) * 2) / 2));
  const incOk = !gramMode && qty + 0.5 <= maxQty && (unitMode || buildFoodEntry(key, slot, { measureId, qty: qty + 0.5 }));

  const submit = async () => {
    if (!entry || busy || full) return;
    const ok = await onAdd(entry);
    if (ok) { if (editEntry) { onClose(); return; } setNotice("✓ " + f.n + " যোগ হয়েছে (" + slotLabel + ")"); setKey(null); }
  };

  // ---- পরিমাণ-ধাপের নতুন বিন্যাস: ফল (ক্যালরি+ম্যাক্রো) আগে → কতটুকু (মাপ-চিপ + বড় ± স্টেপার) → তথ্য ভাঁজে → স্থির বাটন ----
  const h = React.createElement;
  const circleBtn = (label, onClick, disabled, aria) => h("button", { type: "button", onClick, disabled, "aria-label": aria, style: { width: "52px", height: "52px", borderRadius: "50%", border: "none", background: "#E4ECE7", color: GREEN, fontSize: "26px", fontWeight: 700, cursor: disabled ? "default" : "pointer", opacity: disabled ? 0.4 : 1, flexShrink: 0 } }, label);
  const hasMacro = !!entry && entry.p !== undefined;

  return h(Sheet, { title: f.n, subtitle: foodEnglish(key, f) + " · " + slotLabel, onClose, soft: true },
    h("button", { onClick: back, style: { ...BTN, border: "none", background: "transparent", color: GREEN, padding: "0 4px", justifyContent: "flex-start", flex: "0 0 auto", minHeight: "44px" } }, "← অন্য খাবার"),
    h("div", { style: { textAlign: "center", fontSize: "20px", fontWeight: 800, color: "#1F2D2A", margin: "2px 0 10px" } }, "কতটুকু খাবেন/খেয়েছেন?"),
    // স্ট্যাটাস: সবুজ হলে কিছু দেখানো হয় না (শব্দ কমে); হলুদ/লাল হলে কারণসহ
    st.level !== "green" && h("div", { style: { padding: "8px 12px", borderRadius: "12px", border: "1px solid " + sc.border, background: sc.bg, color: sc.text, fontSize: "13px", marginBottom: "8px" } },
      h("b", null, st.icon + " " + st.label), st.reasons.length > 0 && " — " + st.reasons.join("; ")),
    notes.map((n, i) => h("div", { key: "n" + i, style: { padding: "8px 12px", borderRadius: "12px", background: "#FFF6DD", border: "1px solid #E8D08A", color: "#7A5B00", fontSize: "13px", lineHeight: 1.5, marginBottom: "8px" } }, "💊 " + n.text)),

    // ১) কতটুকু খাবেন — শিরোনাম "অন্য খাবার"-এর নিচের লাইনে
    !unitMode && h("div", { style: { display: "flex", gap: "8px", flexWrap: "wrap", justifyContent: "center", marginBottom: "12px" } },
      ms.map((m) => h("button", { key: m.id, type: "button", onClick: () => { setMeasureId(m.id); setQty(1); }, "aria-pressed": measureId === m.id, style: { ...chip(measureId === m.id), flex: "0 0 auto", minHeight: "48px", lineHeight: 1.25, textAlign: "center" } },
        h("span", { style: { display: "block", fontSize: "15px" } }, m.label),
        h("span", { style: { display: "block", fontSize: "12px", fontWeight: 500, opacity: 0.85 } }, "≈ " + bnNum(m.g) + " গ্রাম"))),
      h("button", { type: "button", onClick: () => { setMeasureId("g"); if (entry && entry.grams) setGramsText(String(entry.grams)); }, "aria-pressed": gramMode, style: { ...chip(gramMode), flex: "0 0 auto", minHeight: "48px", fontSize: "15px" } }, "গ্রাম")),
    gramMode
      ? h("div", null,
        h("label", { style: { display: "block", fontSize: "13px", color: MUTED, margin: "2px 0 4px" } }, "গ্রাম (১–২০০০)"),
        h("input", { type: "number", inputMode: "decimal", min: 1, max: 2000, step: "any", value: gramsText, onChange: (e) => setGramsText(e.target.value), "aria-label": "গ্রাম", style: { ...INPUT, fontSize: "20px", fontWeight: 700, textAlign: "center" } }))
      : h("div", null,
        h("div", { style: { display: "flex", alignItems: "center", justifyContent: "center", gap: "20px" } },
          circleBtn("−", () => step(-0.5), qty <= 0.5, "পরিমাণ কমান"),
          h("span", { style: { minWidth: "64px", textAlign: "center", fontSize: "28px", fontWeight: 800, color: "#1F2D2A" } }, bnNum(qty)),
          circleBtn("+", () => step(0.5), !incOk, "পরিমাণ বাড়ান")),
        h("div", { style: { textAlign: "center", fontSize: "14px", color: MUTED, marginTop: "6px" } },
          unitMode ? "ইউনিট: " + f.u : (entry && entry.grams ? "মোট ≈ " + bnNum(entry.grams) + " গ্রাম" : ""))),

    // ২) ফল — "কতটুকু"-র ঠিক নিচে; পরিমাণ ঠিক করলে সাথে সাথে ক্যালরি/ম্যাক্রো বদলায়
    h("div", { role: "status", "aria-live": "polite", style: { marginTop: "16px", padding: "12px 14px", borderRadius: "16px", background: "#F2F7F4", border: "1px solid #D5E0DA" } },
      entry
        ? h("div", null,
          h("div", { style: { display: "flex", alignItems: "baseline", gap: "6px" } },
            h("span", { style: { fontSize: "30px", fontWeight: 800, color: GREEN, lineHeight: 1.1 } }, bnNum(entry.kcal)),
            h("span", { style: { fontSize: "14px", color: GREEN, fontWeight: 600 } }, "কিলোক্যালরি · আনুমানিক")),
          hasMacro && h("div", { style: { display: "flex", gap: "10px", marginTop: "10px" } },
            MACROS.map(([label, k, color]) => h("div", { key: k, style: { flex: 1, minWidth: 0 } },
              h("div", { style: { fontSize: "12px", color: MUTED } }, label),
              h("div", { style: { fontSize: "16px", fontWeight: 800, color: "#1F2D2A", whiteSpace: "nowrap" } }, fmtMacro(entry[k])),
              h("div", { "aria-hidden": "true", style: { height: "4px", borderRadius: "4px", background: color, marginTop: "2px" } }))),
            ),
          hasMacro && h("div", { style: { fontSize: "12px", color: MUTED, marginTop: "4px" } }, "গ্রামে"),
          !hasMacro && unitMode && h("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "এই খাবারের ম্যাক্রো দেখানো হচ্ছে না।"))
        : h("div", { style: { fontSize: "14px", color: "#7A1F14" } }, "পরিমাণ সঠিক নয় — গ্রাম ১–২০০০-এর মধ্যে দিন।")),

    // ৩) বাড়তি তথ্য ভাঁজে — ডিফল্টে বন্ধ
    showInfo && h("div", { style: { marginTop: "10px", fontSize: "12px", color: MUTED, lineHeight: 1.6 } },
        !unitMode && h("div", null, "বাটি/কাপের আকার ঘরে ঘরে আলাদা। গ্রামে সরাসরি লিখলে আরও নিখুঁত হবে।"),
        p100 && h("div", null, "প্রতি ১০০ গ্রামে: " + bnNum(p100.kcal) + " কিলোক্যালরি · প্রোটিন " + fmtMacro(p100.p) + " · কার্ব " + fmtMacro(p100.c) + " · ফ্যাট " + fmtMacro(p100.f) + " · ফাইবার " + fmtMacro(p100.fib) + " গ্রাম"),
        p100 && h("div", null, nut && nut.src === "recipe" ? "গড় রেসিপি অনুযায়ী (±১০–১৫% বা বেশি তফাত হতে পারে)" : "প্রকাশিত খাদ্য-তালিকার সাধারণ মান (আনুমানিক)"),
        unitMode && h("div", null, "১ " + f.u + " = " + bnNum(foodK(key)) + " কিলোক্যালরি" + (hasFoodOverride(key) ? " (আপনার নিজের দেওয়া মান)" : ""))),

    st.level === "red" && Msg("⚠ এই খাবার আপনার জন্য এড়ানোর কথা। ডাক্তারের পরামর্শ প্রাধান্য পায়; তবু খেলে যোগ করতে পারেন।", "warn"),
    full && Msg("আজকের জন্য নিজে-যোগ-করা খাবারের সীমা (" + bnNum(MAX_LIST) + "টি) পূর্ণ। আগের কোনোটি মুছুন।", "warn"),
    err && Msg(err, "err"),
    // যোগ-বাটন স্থির (sticky) — উপরে পাতলা রেখা, লেখা তার নিচে ঢুকে যায় না
    // "হিসাবের তথ্য" বামে, "যোগ করুন" একই লাইনে সর্ব ডানে
    h("div", { style: { position: "sticky", bottom: 0, marginTop: "14px", padding: "10px 0 env(safe-area-inset-bottom, 0px)", background: "#fff", borderTop: "1px solid #E3E0D2", display: "flex", alignItems: "center", gap: "10px" } },
      h("button", { type: "button", onClick: () => setShowInfo((v) => !v), "aria-expanded": showInfo, style: { minHeight: "48px", padding: "0 4px", border: "none", background: "transparent", color: GREEN, fontSize: "14px", fontWeight: 600, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap", flex: "0 0 auto" } }, "ℹ️ হিসাবের তথ্য"),
      primaryBtn((st.level === "red" ? "তবু " : "") + (editEntry ? "সংরক্ষণ করুন" : "যোগ করুন") + " (" + slotLabel + ")", submit, busy, !entry || full)));
}
