// Vaccination Scheduler (owner-request, ২০২৬-০৯-১২, item ৪) — HealthTimeline/
// MedicationReminders-এর pattern reuse। static EPI_SCHEDULE (epiSchedule.js) +
// shared healthCalendarEvents collection (eventType: "vaccination")।
//
// আপডেট (owner-request, ২০২৬-০৯-১৬):
// (ক) member-selector unification — নিজস্ব dropdown সরিয়ে parent
//     (HealthRecordsPageSection)-এর `selectedMemberId` প্রপ ব্যবহার।
// (খ) শুধু শিশুদের (৬ বছরের নিচে — EPI schedule সর্বশেষ dose ~১৫ মাসে শেষ হয়,
//     বাড়তি বাফার সহ) জন্য দেখানো হবে — প্রাপ্তবয়স্ক সদস্যের জন্য প্রাসঙ্গিক না।
// (গ) CollapsibleSection-এ মোড়ানো (owner-request, ডিফল্ট বন্ধ)।

import { ErrorBox, CollapsibleSection } from "../../shared/ui.js";
import { listMembers } from "../../legacy/familyIdentity.js";
import { computeVaccinationDueDates, CHILD_AGE_CUTOFF_YEARS } from "./epiSchedule.js";
import { listCalendarEvents, createCalendarEvent } from "./calendarData.js";
import { getAgeInYears } from "../triage/triageEngine.js";
import { bnDate } from "../../shared/dates.js";

const { useState, useEffect } = React;

// `inline` (নতুন): টাইমলাইন-ট্যাবের "টিকা" পিল-এ CollapsibleSection ছাড়া সরাসরি দেখায়, আর
// প্রাপ্তবয়স্কের ক্ষেত্রে ফাঁকা না রেখে ব্যাখ্যা-বার্তা দেখায়।
export function VaccinationScheduler({ familyId, callerMemberId, selectedMemberId, inline }) {
  const [members, setMembers] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [doneDoseIds, setDoneDoseIds] = useState([]);
  const [busy, setBusy] = useState(null);
  const targetMemberId = selectedMemberId;

  useEffect(() => {
    listMembers(familyId)
      .then(setMembers)
      .catch((e) => setLoadErr(e.message || String(e)));
  }, [familyId]);

  useEffect(() => {
    if (!familyId) return;
    listCalendarEvents(familyId)
      .then((events) => setDoneDoseIds(events.filter((e) => e.eventType === "vaccination" && e.status === "done").map((e) => e.memberId + "_" + e.doseId)))
      .catch((e) => setLoadErr(e.message || String(e)));
  }, [familyId, targetMemberId]);

  async function markDone(doseId, name) {
    setBusy(doseId);
    try {
      await createCalendarEvent(familyId, callerMemberId, {
        memberId: targetMemberId, title: name, eventType: "vaccination",
        date: new Date().toISOString().slice(0, 10), status: "done", doseId,
      });
      setDoneDoseIds((prev) => [...prev, targetMemberId + "_" + doseId]);
    } catch (e) {
      setLoadErr(e.message || String(e));
    } finally {
      setBusy(null);
    }
  }

  if (loadErr) return React.createElement("div", { style: { marginTop: "14px" } }, ErrorBox(loadErr));
  if (!members || !targetMemberId) return null;

  const targetMember = members.find((m) => m.id === targetMemberId);
  const ageYears = targetMember ? getAgeInYears(targetMember.dob) : null;

  // প্রাপ্তবয়স্ক সদস্য নির্বাচিত থাকলে এই widget-ই দেখানো হবে না (owner-request)।
  if (ageYears !== null && ageYears >= CHILD_AGE_CUTOFF_YEARS) {
    return inline ? React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "EPI টিকার শিডিউল শুধু ৬ বছরের নিচের শিশুদের জন্য — এই সদস্যের জন্য প্রযোজ্য নয়।") : null;
  }

  const schedule = targetMember ? computeVaccinationDueDates(targetMember.dob) : [];
  const today = new Date().toISOString().slice(0, 10);

  const Wrap = inline
    ? (props, ...kids) => React.createElement("div", { style: { background: "var(--hs-surface, #fff)", padding: "14px", borderRadius: "20px", border: "1px solid var(--hs-border, #D9E5DE)", boxShadow: "0 2px 10px rgba(14,75,67,0.08)" } }, React.createElement("h4", { style: { fontSize: "14px", color: "var(--hs-primary, #0E4B43)", margin: "0 0 8px" } }, props.title), ...kids)
    : (props, ...kids) => React.createElement(CollapsibleSection, props, ...kids);
  return Wrap({ title: "💉 টিকা শিডিউল (EPI)" },
    React.createElement("div", { style: { fontSize: "14px", color: "#4B5C57", marginBottom: "8px" } },
      "বাংলাদেশ সরকারের EPI স্ট্যান্ডার্ড শিডিউল অনুযায়ী — জন্ম-তারিখ থেকে হিসাব করা প্রত্যাশিত তারিখ, প্রকৃত টিকাদান-তথ্যের জন্য টিকা-কার্ড/স্বাস্থ্যকর্মীর সাথে মিলিয়ে নিন।"
    ),

    !targetMember || !targetMember.dob
      ? React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "এই সদস্যের জন্ম-তারিখ profile-এ নেই — vaccination-schedule হিসাব করা সম্ভব না।")
      : schedule.map((d) => {
          const doneKey = targetMemberId + "_" + d.doseId;
          const isDone = doneDoseIds.includes(doneKey);
          const isOverdue = !isDone && d.dueDate < today;
          return React.createElement(
            "div", {
              key: d.doseId,
              style: { marginTop: "8px", padding: "10px", borderRadius: "14px", display: "flex", justifyContent: "space-between", alignItems: "center",
                background: isDone ? "#EAF6F0" : isOverdue ? "#FDECEA" : "#F7FAF9",
                border: "1px solid " + (isDone ? "#A9D8C4" : isOverdue ? "#F5C6C0" : "#D3E0D9") },
            },
            React.createElement(
              "div", null,
              React.createElement("div", { style: { fontSize: "14px", fontWeight: 600, color: "#1F2D2A" } }, d.name),
              React.createElement("div", { style: { fontSize: "14px", color: "#4B5C57" } }, "প্রত্যাশিত তারিখ: " + bnDate(d.dueDate) + (isDone ? " — ✓ সম্পন্ন" : isOverdue ? " — ⚠️ মেয়াদ পার" : ""))
            ),
            !isDone && React.createElement(
              "button", {
                onClick: () => markDone(d.doseId, d.name), disabled: busy === d.doseId,
                style: { padding: "6px 10px", border: "1px solid var(--hs-primary, #0E4B43)", borderRadius: "10px", background: "var(--hs-primary, #0E4B43)", color: "#fff", fontSize: "14px", cursor: "pointer" },
              }, busy === d.doseId ? "..." : "সম্পন্ন করুন"
            )
          );
        })
  );
}
