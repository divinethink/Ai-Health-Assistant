// Health Assistant — Firestore Rules Unit Tests (Mocha)
// চালানো: npm run test:rules  (Firebase Emulator সহ)
//
// বর্তমান rules-এর (Google Sign-in মডেল: member.googleUid + uidMemberIndex) বিপরীতে লেখা।
// প্রতিটি টেস্টের আগে ডাটাবেস খালি করে ছোট বেস-ডেটা বসানো হয়, তাই টেস্টগুলো স্বাধীন।
// Mocha ব্যবহারের কারণ: Firebase SDK-র সাথে node:test-এ "Promise resolution is still pending" সমস্যা।

import { readFileSync } from 'node:fs';
import {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} from '@firebase/rules-unit-testing';
import { doc, setDoc, updateDoc, getDoc, getDocs, deleteDoc, deleteField, collection, query, where } from 'firebase/firestore';

const FAMILY_ID = 'fam1';
const ADMIN_UID = 'admin-uid-1';
const OLD = new Date('2020-01-01T00:00:00Z');

let testEnv;

async function seed(fn) {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await fn(ctx.firestore());
  });
}

function dbAs(uid, token) {
  return testEnv.authenticatedContext(uid, token).firestore();
}

const famDoc = (db, ...path) => doc(db, 'families', FAMILY_ID, ...path);
const famCol = (db, ...path) => collection(db, 'families', FAMILY_ID, ...path);

async function seedFamily(familyId, adminUids, extra = {}) {
  await seed(async (db) => {
    await setDoc(doc(db, 'families', familyId), {
      familyId,
      familyCodeDisplay: 'TEST',
      createdBy: adminUids[0] || 'nobody',
      createdAt: OLD,
      adminUids,
      firstAdminUid: adminUids[0] || null,
      ...extra,
    });
  });
}

async function seedMember(memberId, data = {}) {
  await seed(async (db) => {
    await setDoc(famDoc(db, 'members', memberId), {
      id: memberId,
      familyId: FAMILY_ID,
      name: 'Test',
      dob: '1990-01-01',
      sex: 'male',
      role: 'self-managing',
      relationshipLabel: null,
      guardianMemberIds: [],
      googleUid: null,
      updatedAt: OLD,
      ...data,
    });
  });
}

async function seedUidIndex(uid, memberId) {
  await seed(async (db) => {
    await setDoc(famDoc(db, 'uidMemberIndex', uid), { memberId });
  });
}

// Google-লগইন করা সদস্য: member.googleUid + uidMemberIndex দুটোই
async function seedOwned(memberId, uid, data = {}) {
  await seedMember(memberId, { googleUid: uid, ...data });
  await seedUidIndex(uid, memberId);
}

async function seedGrant(targetMemberId, granteeMemberId, opts = {}) {
  await seed(async (db) => {
    await setDoc(famDoc(db, 'accessGrants', `${targetMemberId}_${granteeMemberId}`), {
      granterId: targetMemberId,
      granteeId: granteeMemberId,
      scope: 'read+write',
      relationshipType: 'other',
      status: 'approved',
      revocable: true,
      grantedAt: OLD,
      createdAt: OLD,
      ...opts,
    });
  });
}

async function seedShare(ownerId, granteeId, flags) {
  await seed(async (db) => {
    await setDoc(famDoc(db, 'profileShares', `${ownerId}_${granteeId}`), {
      ownerId,
      granteeId,
      read: false,
      write: false,
      updatedAt: OLD,
      ...flags,
    });
  });
}

async function seedRecord(id, memberId) {
  await seed(async (db) => {
    await setDoc(famDoc(db, 'healthRecords', id), {
      id,
      memberId,
      resourceType: 'condition',
      name: 'Test condition',
      lastEditedByMemberId: memberId,
      createdAt: OLD,
      updatedAt: OLD,
    });
  });
}

const newRecord = (memberId, editedBy, extra = {}) => ({
  memberId,
  resourceType: 'condition',
  name: 'New condition',
  lastEditedByMemberId: editedBy,
  createdAt: new Date(),
  updatedAt: new Date(),
  ...extra,
});

describe('Health Assistant — Firestore Rules', function () {
  this.timeout(20000);

  before(async () => {
    testEnv = await initializeTestEnvironment({
      projectId: 'demo-health-assistant',
      firestore: {
        rules: readFileSync('firestore.rules', 'utf8'),
        host: '127.0.0.1',
        port: 8080,
      },
    });
  });

  beforeEach(async () => {
    await testEnv.clearFirestore();
    await seedFamily(FAMILY_ID, [ADMIN_UID]);
    await seedOwned('memberAdmin', ADMIN_UID, { role: 'admin' });
  });

  after(async () => {
    await testEnv.cleanup();
  });

  // ============================================================
  describe('1. Member profile edit', () => {
    it('1. owner (googleUid) নিজের প্রোফাইল edit করতে পারেন', async () => {
      await seedOwned('mA', 'uidA');
      await assertSucceeds(updateDoc(famDoc(dbAs('uidA'), 'members', 'mA'), { name: 'নতুন নাম' }));
    });

    it('1b. non-owner, non-admin অন্যের প্রোফাইল edit করতে পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
      await assertFails(updateDoc(famDoc(dbAs('uidB'), 'members', 'mA'), { name: 'হ্যাক' }));
    });

    it('1c. owner নিজের role বদলাতে পারেন না (Admin-only)', async () => {
      await seedOwned('mA', 'uidA');
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'members', 'mA'), { role: 'admin' }));
    });

    it('1d. Admin অন্যের guardianMemberIds/relationshipLabel বদলাতে পারেন', async () => {
      await seedOwned('mA', 'uidA');
      await assertSucceeds(
        updateDoc(famDoc(dbAs(ADMIN_UID), 'members', 'mA'), {
          guardianMemberIds: ['memberAdmin'],
          relationshipLabel: 'son',
        })
      );
    });

    it('1e. owner নিজে guardianMemberIds বদলাতে পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      await assertFails(
        updateDoc(famDoc(dbAs('uidA'), 'members', 'mA'), { guardianMemberIds: ['mA'] })
      );
    });

    it('1f. Admin-ও claim-করা সদস্যের googleUid বদলাতে পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      await assertFails(updateDoc(famDoc(dbAs(ADMIN_UID), 'members', 'mA'), { googleUid: 'uidX' }));
    });

    it('1g. Admin নতুন সদস্য তৈরি করতে পারেন; non-admin পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      const data = { name: 'Child', dob: '2018-01-01', sex: 'male', role: 'guardian-managed' };
      await assertSucceeds(setDoc(famDoc(dbAs(ADMIN_UID), 'members', 'mNew'), data));
      await assertFails(setDoc(famDoc(dbAs('uidA'), 'members', 'mNew2'), data));
    });
  });

  // ============================================================
  describe('2. Email-match auto-claim', () => {
    it('2. email মিললে unclaimed সদস্য claim করা যায় (email মুছে যায়)', async () => {
      await seedMember('mC', { email: 'a@x.com', googleUid: null });
      await assertSucceeds(
        updateDoc(famDoc(dbAs('uidC', { email: 'a@x.com' }), 'members', 'mC'), {
          googleUid: 'uidC',
          email: deleteField(),
          updatedAt: new Date(),
        })
      );
    });

    it('2b. ভুল email হলে claim reject', async () => {
      await seedMember('mC', { email: 'a@x.com', googleUid: null });
      await assertFails(
        updateDoc(famDoc(dbAs('uidC', { email: 'other@x.com' }), 'members', 'mC'), {
          googleUid: 'uidC',
          email: deleteField(),
          updatedAt: new Date(),
        })
      );
    });

    it('2c. ইতিমধ্যে claim-করা সদস্য অন্য কেউ আবার claim করতে পারে না', async () => {
      await seedMember('mC', { email: 'a@x.com', googleUid: 'uidOwner' });
      await assertFails(
        updateDoc(famDoc(dbAs('uidEvil', { email: 'a@x.com' }), 'members', 'mC'), {
          googleUid: 'uidEvil',
          email: deleteField(),
          updatedAt: new Date(),
        })
      );
    });
  });

  // ============================================================
  describe('3. পুরনো families.activeInviteToken দিয়ে join বন্ধ (ধাপ ৩)', () => {
    it('3. পুরনো ফিল্ডে token থাকলেও self-join reject', async () => {
      await seed(async (db) => {
        await setDoc(
          doc(db, 'families', FAMILY_ID),
          { activeInviteToken: { token: 'tok123tok123tok123tok123tok', revoked: false } },
          { merge: true }
        );
      });
      await assertFails(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), {
          name: 'New',
          dob: '1995-05-05',
          sex: 'female',
          role: 'self-managing',
          googleUid: 'uidNew',
          inviteTokenAttempt: 'tok123tok123tok123tok123tok',
          createdAt: new Date(),
          updatedAt: new Date(),
        })
      );
    });
  });

  // ============================================================
  describe('3n. নতুন invites/{token} (ধাপ ১)', () => {
    const TOK = 'N3wTokenAbcdefghjkmnpqrst2'; // ২৬ অক্ষর
    const joinNew = (uid, token, extra = {}) => ({
      name: 'New',
      dob: '2000-01-01',
      sex: 'female',
      role: 'self-managing',
      googleUid: uid,
      inviteTokenAttempt: token,
      createdAt: new Date(),
      updatedAt: new Date(),
      ...extra,
    });
    async function seedInvite(revoked = false, token = TOK) {
      await seed(async (db) => {
        await setDoc(doc(db, 'families', FAMILY_ID, 'invites', token), {
          revoked,
          createdAt: Date.now(),
        });
      });
    }

    it('3n-1. সঠিক invites token-এ self-join হয়', async () => {
      await seedInvite(false);
      await assertSucceeds(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), joinNew('uidNew', TOK))
      );
    });

    it('3n-2. revoked token-এ join হয় না', async () => {
      await seedInvite(true);
      await assertFails(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), joinNew('uidNew', TOK))
      );
    });

    it('3n-3. ভুল/ছোট token-এ join হয় না', async () => {
      await seedInvite(false);
      await assertFails(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), joinNew('uidNew', 'wrong'))
      );
      await assertFails(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), joinNew('uidNew', TOK + 'x'))
      );
    });

    it('3n-4. token থাকলেও role admin দিয়ে join হয় না', async () => {
      await seedInvite(false);
      await assertFails(
        setDoc(
          famDoc(dbAs('uidNew'), 'members', 'mNew'),
          joinNew('uidNew', TOK, { role: 'admin' })
        )
      );
    });

    it('3n-5. অন্যের uid দিয়ে join হয় না', async () => {
      await seedInvite(false);
      await assertFails(
        setDoc(famDoc(dbAs('uidNew'), 'members', 'mNew'), joinNew('uidOther', TOK))
      );
    });

    it('3n-6. অ-সদস্য invites list করতে পারে না; token জানলে get পারে', async () => {
      await seedInvite(false);
      await assertFails(getDocs(collection(dbAs('uidNew'), 'families', FAMILY_ID, 'invites')));
      await assertSucceeds(getDoc(doc(dbAs('uidNew'), 'families', FAMILY_ID, 'invites', TOK)));
    });

    it('3n-7. Admin invites তৈরি/list/revoke/মোছা পারেন; non-admin পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      const ref = (d) => doc(d, 'families', FAMILY_ID, 'invites', TOK);
      await assertSucceeds(setDoc(ref(dbAs(ADMIN_UID)), { revoked: false, createdAt: Date.now() }));
      await assertSucceeds(
        getDocs(collection(dbAs(ADMIN_UID), 'families', FAMILY_ID, 'invites'))
      );
      await assertSucceeds(updateDoc(ref(dbAs(ADMIN_UID)), { revoked: true }));
      await assertFails(setDoc(ref(dbAs('uidA')), { revoked: false, createdAt: Date.now() }));
      await assertFails(
        getDocs(collection(dbAs('uidA'), 'families', FAMILY_ID, 'invites'))
      );
      await assertFails(deleteDoc(ref(dbAs('uidA'))));
      await assertSucceeds(deleteDoc(ref(dbAs(ADMIN_UID))));
    });

    it('3n-8. invites-এ অতিরিক্ত ফিল্ড/ছোট token reject', async () => {
      await assertFails(
        setDoc(doc(dbAs(ADMIN_UID), 'families', FAMILY_ID, 'invites', TOK), {
          revoked: false,
          extra: 1,
        })
      );
      await assertFails(
        setDoc(doc(dbAs(ADMIN_UID), 'families', FAMILY_ID, 'invites', 'short'), {
          revoked: false,
        })
      );
    });
  });

  describe('4. uidMemberIndex ও users', () => {
    it('4. নিজের (googleUid-মেলা) সদস্যের জন্য index বানানো যায়', async () => {
      await seedMember('mA', { googleUid: 'uidA' });
      await assertSucceeds(setDoc(famDoc(dbAs('uidA'), 'uidMemberIndex', 'uidA'), { memberId: 'mA' }));
    });

    it('4b. অন্যের সদস্যের দিকে index spoof reject', async () => {
      await seedMember('mA', { googleUid: 'uidA' });
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'uidMemberIndex', 'uidB'), { memberId: 'mA' }));
    });

    it('4c. অন্য uid-র নামে index বানানো reject', async () => {
      await seedMember('mA', { googleUid: 'uidA' });
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'uidMemberIndex', 'uidA'), { memberId: 'mA' }));
    });

    it('4d. users/{uid} শুধু নিজের সদস্যের দিকে বানানো যায়', async () => {
      await seedMember('mA', { googleUid: 'uidA' });
      await assertSucceeds(
        setDoc(doc(dbAs('uidA'), 'users', 'uidA'), { familyId: FAMILY_ID, memberId: 'mA' })
      );
      await assertFails(
        setDoc(doc(dbAs('uidB'), 'users', 'uidB'), { familyId: FAMILY_ID, memberId: 'mA' })
      );
    });
  });

  // ============================================================
  describe('5. familyCodes', () => {
    const codeData = (uid, familyId) => ({ familyId, createdBy: uid, createdAt: new Date() });

    it('5. established family-তে non-admin code বানাতে পারেন না', async () => {
      await assertFails(
        setDoc(doc(dbAs('stranger'), 'familyCodes', 'ABC123'), codeData('stranger', FAMILY_ID))
      );
    });

    it('5b. নতুন family (adminUids খালি) বা অস্তিত্বহীন family-র code বানানো যায়', async () => {
      await seedFamily('famNew', []);
      await assertSucceeds(
        setDoc(doc(dbAs('founder'), 'familyCodes', 'NEWFAM1'), codeData('founder', 'famNew'))
      );
      await assertSucceeds(
        setDoc(doc(dbAs('founder'), 'familyCodes', 'GHOST12'), codeData('founder', 'famGhost'))
      );
    });

    it('5c. নিজের family-র জন্য Admin code বানাতে পারেন', async () => {
      await assertSucceeds(
        setDoc(doc(dbAs(ADMIN_UID), 'familyCodes', 'ADMIN12'), codeData(ADMIN_UID, FAMILY_ID))
      );
    });

    it('5d. createdBy অন্যের uid হলে reject', async () => {
      await assertFails(
        setDoc(doc(dbAs('founder'), 'familyCodes', 'SPOOF12'), codeData('someoneElse', 'famGhost'))
      );
    });
  });

  // ============================================================
  describe('6. Family doc / adminUids', () => {
    it('6. নতুন family তৈরি + প্রথম admin হওয়া', async () => {
      const db = dbAs('founder');
      await assertSucceeds(
        setDoc(doc(db, 'families', 'famF'), {
          familyId: 'famF',
          familyCodeDisplay: 'FF',
          createdBy: 'founder',
          createdAt: new Date(),
          adminUids: [],
        })
      );
      await assertSucceeds(
        updateDoc(doc(db, 'families', 'famF'), {
          adminUids: ['founder'],
          firstAdminUid: 'founder',
          updatedAt: new Date(),
        })
      );
    });

    it('6b. non-admin established family-তে নিজেকে admin বানাতে পারেন না', async () => {
      await assertFails(
        updateDoc(doc(dbAs('intruder'), 'families', FAMILY_ID), {
          adminUids: [ADMIN_UID, 'intruder'],
          updatedAt: new Date(),
        })
      );
    });

    it('6c. Admin আরেকজন admin যোগ করতে পারেন', async () => {
      await assertSucceeds(
        updateDoc(doc(dbAs(ADMIN_UID), 'families', FAMILY_ID), {
          adminUids: [ADMIN_UID, 'admin2'],
          updatedAt: new Date(),
        })
      );
    });

    it('6d. firstAdmin অন্য admin-কে সরাতে পারেন; অন্য admin firstAdmin-কে সরাতে পারেন না', async () => {
      await seedFamily('famAdm', ['adminA', 'adminB']);
      await assertFails(
        updateDoc(doc(dbAs('adminB'), 'families', 'famAdm'), {
          adminUids: ['adminB'],
          updatedAt: new Date(),
        })
      );
      await assertSucceeds(
        updateDoc(doc(dbAs('adminA'), 'families', 'famAdm'), {
          adminUids: ['adminA'],
          updatedAt: new Date(),
        })
      );
    });

    it('6e. শেষ admin-কে সরানো যায় না (অন্তত ১জন থাকতে হবে)', async () => {
      await assertFails(
        updateDoc(doc(dbAs(ADMIN_UID), 'families', FAMILY_ID), {
          adminUids: [],
          updatedAt: new Date(),
        })
      );
    });

    it('6f. families ডকে activeInviteToken কেউ (Admin-ও) লিখতে পারেন না', async () => {
      await seedOwned('mA', 'uidA');
      const tok = { activeInviteToken: { token: 't1', revoked: false }, updatedAt: new Date() };
      await assertFails(updateDoc(doc(dbAs(ADMIN_UID), 'families', FAMILY_ID), tok));
      await assertFails(updateDoc(doc(dbAs('uidA'), 'families', FAMILY_ID), tok));
    });
  });

  // ============================================================
  describe('7. Health records — hasAccess', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });

    it('7. owner নিজের record তৈরি, পড়া, edit ও delete করতে পারেন', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthRecords', 'r1'), newRecord('mA', 'mA')));
      await assertSucceeds(getDoc(famDoc(db, 'healthRecords', 'r1')));
      await assertSucceeds(
        updateDoc(famDoc(db, 'healthRecords', 'r1'), { name: 'Edited', lastEditedByMemberId: 'mA' })
      );
      await assertSucceeds(deleteDoc(famDoc(db, 'healthRecords', 'r1')));
    });

    it('7b. grant/share ছাড়া অন্য সদস্য পড়তে বা লিখতে পারেন না', async () => {
      await seedRecord('r1', 'mA');
      const db = dbAs('uidB');
      await assertFails(getDoc(famDoc(db, 'healthRecords', 'r1')));
      await assertFails(setDoc(famDoc(db, 'healthRecords', 'r2'), newRecord('mA', 'mB')));
    });

    it('7c. approved AccessGrant থাকলে read+write allow', async () => {
      await seedRecord('r1', 'mA');
      await seedGrant('mA', 'mB');
      const db = dbAs('uidB');
      await assertSucceeds(getDoc(famDoc(db, 'healthRecords', 'r1')));
      await assertSucceeds(setDoc(famDoc(db, 'healthRecords', 'r2'), newRecord('mA', 'mB')));
    });

    it('7d. pending/cancelled grant কোনো access দেয় না', async () => {
      await seedRecord('r1', 'mA');
      await seedGrant('mA', 'mB', { status: 'pending' });
      await assertFails(getDoc(famDoc(dbAs('uidB'), 'healthRecords', 'r1')));
    });

    it('7e. lastEditedByMemberId spoof করে অন্যের নামে লেখা reject', async () => {
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'healthRecords', 'r1'), newRecord('mA', 'mA')));
    });

    it('7f. অবৈধ resourceType reject', async () => {
      await assertFails(
        setDoc(famDoc(dbAs('uidA'), 'healthRecords', 'r1'), newRecord('mA', 'mA', { resourceType: 'bogus' }))
      );
    });

    it('7f-2. নিজের commonCare রেকর্ড (সাধারণ চিকিৎসা) তৈরি করা যায়', async () => {
      await assertSucceeds(
        setDoc(famDoc(dbAs('uidA'), 'healthRecords', 'cc1'), newRecord('mA', 'mA', { resourceType: 'commonCare', disease: 'জ্বর', brand: 'Napa' }))
      );
    });

    it('7f-3. অন্যের commonCare রেকর্ডে অনুমতি ছাড়া লেখা reject', async () => {
      await assertFails(
        setDoc(famDoc(dbAs('uidB'), 'healthRecords', 'cc2'), newRecord('mA', 'mB', { resourceType: 'commonCare', disease: 'জ্বর' }))
      );
    });

    it('7g. update-এ memberId বদলে অন্যের নামে সরানো reject', async () => {
      await seedRecord('r1', 'mA');
      await assertFails(
        updateDoc(famDoc(dbAs('uidA'), 'healthRecords', 'r1'), { memberId: 'mB', lastEditedByMemberId: 'mA' })
      );
    });

    it('7h. Admin যেকোনো সদস্যের record পড়তে, লিখতে ও delete করতে পারেন', async () => {
      await seedRecord('r1', 'mA');
      const db = dbAs(ADMIN_UID);
      await assertSucceeds(getDoc(famDoc(db, 'healthRecords', 'r1')));
      await assertSucceeds(
        setDoc(famDoc(db, 'healthRecords', 'r2'), newRecord('mA', 'memberAdmin'))
      );
      await assertSucceeds(deleteDoc(famDoc(db, 'healthRecords', 'r1')));
    });

    it('7i. non-owner অন্যের record delete করতে পারেন না', async () => {
      await seedRecord('r1', 'mA');
      await assertFails(deleteDoc(famDoc(dbAs('uidB'), 'healthRecords', 'r1')));
    });

    it('7j. অপরিচিত (সদস্য নয়) ব্যবহারকারী কিছুই পড়তে পারে না', async () => {
      await seedRecord('r1', 'mA');
      await assertFails(getDoc(famDoc(dbAs('stranger'), 'healthRecords', 'r1')));
    });
  });

  // ============================================================
  describe('8. ProfileShare (owner-controlled)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
      await seedRecord('r1', 'mA');
    });

    it('8. owner নিজের প্রোফাইলের share বানাতে পারেন', async () => {
      await assertSucceeds(
        setDoc(famDoc(dbAs('uidA'), 'profileShares', 'mA_mB'), {
          ownerId: 'mA',
          granteeId: 'mB',
          read: true,
          write: false,
          updatedAt: new Date(),
        })
      );
    });

    it('8b. অন্যের প্রোফাইলের owner সেজে share বানানো reject', async () => {
      await assertFails(
        setDoc(famDoc(dbAs('uidB'), 'profileShares', 'mA_mB'), {
          ownerId: 'mA',
          granteeId: 'mB',
          read: true,
          write: true,
          updatedAt: new Date(),
        })
      );
    });

    it('8c. read share থাকলে পড়া যায়, কিন্তু লেখা যায় না', async () => {
      await seedShare('mA', 'mB', { read: true, write: false });
      const db = dbAs('uidB');
      await assertSucceeds(getDoc(famDoc(db, 'healthRecords', 'r1')));
      await assertFails(setDoc(famDoc(db, 'healthRecords', 'r2'), newRecord('mA', 'mB')));
    });

    it('8d. write share থাকলে লেখা যায়', async () => {
      await seedShare('mA', 'mB', { read: true, write: true });
      await assertSucceeds(setDoc(famDoc(dbAs('uidB'), 'healthRecords', 'r2'), newRecord('mA', 'mB')));
    });

    it('8e. grantee নিজে share বদলাতে পারেন না', async () => {
      await seedShare('mA', 'mB', { read: true, write: false });
      await assertFails(
        updateDoc(famDoc(dbAs('uidB'), 'profileShares', 'mA_mB'), { write: true, updatedAt: new Date() })
      );
    });

    it('8f. owner share বাতিল (delete) করতে পারেন', async () => {
      await seedShare('mA', 'mB', { read: true });
      await assertSucceeds(deleteDoc(famDoc(dbAs('uidA'), 'profileShares', 'mA_mB')));
    });
  });

  // ============================================================
  describe('9. AccessGrants (structural + legacy)', () => {
    beforeEach(async () => {
      await seedOwned('mChild', 'uidChild');
      await seedOwned('mParent', 'uidParent');
    });

    const structural = () => ({
      granterId: 'mChild',
      granteeId: 'mParent',
      scope: 'read+write',
      relationshipType: 'parent-child',
      status: 'approved',
      revocable: false,
      grantedAt: new Date(),
      createdAt: new Date(),
    });

    it('9. Admin structural parent-child grant বানাতে পারেন', async () => {
      await assertSucceeds(
        setDoc(famDoc(dbAs(ADMIN_UID), 'accessGrants', 'mChild_mParent'), structural())
      );
    });

    it('9b. non-admin (guardian নিজেও) structural grant বানাতে পারেন না', async () => {
      await assertFails(
        setDoc(famDoc(dbAs('uidParent'), 'accessGrants', 'mChild_mParent'), structural())
      );
    });

    it('9c. পুরনো pending peer-request এখন আর তৈরি করা যায় না', async () => {
      await assertFails(
        setDoc(famDoc(dbAs('uidParent'), 'accessGrants', 'mChild_mParent'), {
          granterId: 'mChild',
          granteeId: 'mParent',
          scope: 'read+write',
          relationshipType: 'other',
          status: 'pending',
          revocable: true,
          createdAt: new Date(),
        })
      );
    });

    it('9d. Admin non-revocable grant cancel করতে পারেন', async () => {
      await seedGrant('mChild', 'mParent', { relationshipType: 'parent-child', revocable: false });
      await assertSucceeds(
        updateDoc(famDoc(dbAs(ADMIN_UID), 'accessGrants', 'mChild_mParent'), {
          status: 'cancelled',
          cancelledAt: new Date(),
          cancelledBy: 'memberAdmin',
        })
      );
    });

    it('9e. non-admin non-revocable grant cancel করতে পারেন না', async () => {
      await seedGrant('mChild', 'mParent', { relationshipType: 'parent-child', revocable: false });
      await assertFails(
        updateDoc(famDoc(dbAs('uidParent'), 'accessGrants', 'mChild_mParent'), {
          status: 'cancelled',
          cancelledAt: new Date(),
          cancelledBy: 'mParent',
        })
      );
    });

    it('9f. Admin cancelled structural grant আবার approve করতে পারেন', async () => {
      await seedGrant('mChild', 'mParent', {
        relationshipType: 'parent-child',
        revocable: false,
        status: 'cancelled',
      });
      await assertSucceeds(
        updateDoc(famDoc(dbAs(ADMIN_UID), 'accessGrants', 'mChild_mParent'), {
          status: 'approved',
          grantedAt: new Date(),
        })
      );
    });

    it('9g. ১৮+ transition: Admin revocable false→true করতে পারেন', async () => {
      await seedGrant('mChild', 'mParent', { relationshipType: 'parent-child', revocable: false });
      await assertSucceeds(
        updateDoc(famDoc(dbAs(ADMIN_UID), 'accessGrants', 'mChild_mParent'), { revocable: true })
      );
    });

    it('9h. approved revocable peer-grant granter নিজে cancel করতে পারেন', async () => {
      await seedGrant('mChild', 'mParent', { revocable: true });
      await assertSucceeds(
        updateDoc(famDoc(dbAs('uidChild'), 'accessGrants', 'mChild_mParent'), {
          status: 'cancelled',
          cancelledAt: new Date(),
          cancelledBy: 'mChild',
        })
      );
    });

    it('9i. grant কখনো delete করা যায় না', async () => {
      await seedGrant('mChild', 'mParent', {});
      await assertFails(deleteDoc(famDoc(dbAs(ADMIN_UID), 'accessGrants', 'mChild_mParent')));
    });
  });

  // ============================================================
  describe('10. Notifications', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });

    const notif = (target) => ({
      targetUid: target,
      type: 'info',
      message: 'test',
      read: false,
      createdAt: new Date(),
    });

    it('10. পরিবারের সদস্য বৈধ targetUid-কে notification পাঠাতে পারেন', async () => {
      await assertSucceeds(setDoc(famDoc(dbAs('uidA'), 'notifications', 'n1'), notif('uidB')));
    });

    it('10b. uidMemberIndex-এ নেই এমন targetUid-তে পাঠানো reject', async () => {
      await assertFails(setDoc(famDoc(dbAs('uidA'), 'notifications', 'n1'), notif('ghostUid')));
    });

    it('10c. পরিবারের বাইরের কেউ notification পাঠাতে পারে না', async () => {
      await assertFails(setDoc(famDoc(dbAs('stranger'), 'notifications', 'n1'), notif('uidB')));
    });

    it('10d. শুধু targetUid নিজে পড়তে ও read-mark করতে পারেন', async () => {
      await seed(async (db) => {
        await setDoc(famDoc(db, 'notifications', 'n1'), { ...notif('uidB'), createdAt: OLD });
      });
      await assertFails(getDoc(famDoc(dbAs('uidA'), 'notifications', 'n1')));
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'notifications', 'n1'), { read: true }));
      await assertSucceeds(getDoc(famDoc(dbAs('uidB'), 'notifications', 'n1')));
      await assertSucceeds(updateDoc(famDoc(dbAs('uidB'), 'notifications', 'n1'), { read: true }));
    });
  });

  // ============================================================
  describe('12. Health tracker (healthTracker)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const tr = (memberId, editor, extra = {}) => ({
      type: 'daily', memberId, date: '2026-11-08', waterGlasses: 5, sources: { waterGlasses: 'manual' },
      lastEditedByMemberId: editor, createdAt: OLD, updatedAt: OLD, ...extra,
    });

    it('12. owner নিজের tracker doc তৈরি, পড়া (query), update ও delete করতে পারেন', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'daily_mA_2026-11-08'), tr('mA', 'mA')));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'daily_mA_2026-11-08'), { steps: 100, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(getDocs(query(famCol(db, 'healthTracker'), where('memberId', '==', 'mA'), where('date', '==', '2026-11-08'))));
      await assertSucceeds(deleteDoc(famDoc(db, 'healthTracker', 'daily_mA_2026-11-08')));
    });

    it('12b. grant ছাড়া অন্য সদস্য পড়তে/লিখতে পারেন না; approved grant থাকলে পারেন', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'healthTracker', 't1'), tr('mA', 'mA')); });
      await assertFails(getDocs(query(famCol(dbAs('uidB'), 'healthTracker'), where('memberId', '==', 'mA'))));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'healthTracker', 't2'), tr('mA', 'mB')));
      await seedGrant('mA', 'mB');
      await assertSucceeds(getDocs(query(famCol(dbAs('uidB'), 'healthTracker'), where('memberId', '==', 'mA'))));
      await assertSucceeds(setDoc(famDoc(dbAs('uidB'), 'healthTracker', 't3'), tr('mA', 'mB')));
    });

    it('12c. অবৈধ type, অজানা field ও lastEditedBy spoof reject', async () => {
      const db = dbAs('uidA');
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'x1'), tr('mA', 'mA', { type: 'bogus' })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'x2'), tr('mA', 'mA', { surprise: 1 })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'x3'), tr('mA', 'mB')));
    });

    it('12d. update-এ memberId বদলানো reject; non-owner delete reject', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'healthTracker', 't1'), tr('mA', 'mA')); });
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 't1'), { memberId: 'mB', lastEditedByMemberId: 'mA' }));
      await assertFails(deleteDoc(famDoc(dbAs('uidB'), 'healthTracker', 't1')));
    });

    // ধাপ B: নতুন ঐচ্ছিক ফিল্ড (planPrefs → goal; extraFoods/exerciseLog → daily)
    const goalDoc = (extra = {}) => tr('mA', 'mA', { type: 'goal', ...extra });
    const prefs = { v: 1, meal: { lunch: [{ food: 'rice', qty: 1 }] }, exercise: { 0: [{ type: 'walk', min: 30 }] } };

    it('12e. owner বৈধ planPrefs (goal), extraFoods ও exerciseLog (daily) লিখতে পারেন; খালি prefs-ও চলে', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goalDoc({ planPrefs: prefs })));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { planPrefs: { v: 1, meal: {}, exercise: {} }, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'daily_mA_2026-11-08'),
        tr('mA', 'mA', { extraFoods: [{ name: 'সমুচা', kcal: 200, slot: 'snack2' }], exerciseLog: [{ type: 'walk', min: 20 }] })));
    });

    // ধাপ B: ব্যায়াম-টার্গেট (focusAreas → শুধু goal-ডক; ≤৩; অনুমোদিত আইডি)
    it('12g. focusAreas: goal-এ বৈধ তালিকা (খালি-সহ) চলে; ৪টি, অজানা আইডি, ভুল ধরন, daily-তে reject', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goalDoc({ focusAreas: ['belly', 'chest', 'glute'] })));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { focusAreas: [], lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'f1'), goalDoc({ focusAreas: ['muscle', 'belly', 'chest', 'arms'] })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'f2'), goalDoc({ focusAreas: ['surprise'] })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'f3'), goalDoc({ focusAreas: 'belly' })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'f4'), tr('mA', 'mA', { focusAreas: ['belly'] })));
    });

    it('12f. planPrefs daily-তে, extraFoods/exerciseLog goal-এ, অজানা planPrefs-key, ভুল ধরন ও বড় আকার reject', async () => {
      const db = dbAs('uidA');
      const big = Array.from({ length: 21 }, () => ({ name: 'a', kcal: 1, slot: 'lunch' }));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y1'), tr('mA', 'mA', { planPrefs: prefs })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y2'), goalDoc({ extraFoods: [] })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y3'), goalDoc({ exerciseLog: [] })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y4'), goalDoc({ planPrefs: { v: 1, surprise: {} } })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y5'), goalDoc({ planPrefs: 'x' })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y6'), goalDoc({ planPrefs: { v: 1, meal: [] } })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y7'), tr('mA', 'mA', { extraFoods: big })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y8'), tr('mA', 'mA', { extraFoods: 'x' })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'y9'), tr('mA', 'mA', { exerciseLog: big })));
    });

    it('12f2. planPrefs.foods (খাবার-ওভাররাইড): ≤৪০ map চলে; ৪১টি বা map নয় reject', async () => {
      const db = dbAs('uidA');
      const mk = (n) => Object.fromEntries(Array.from({ length: n }, (_, i) => ['f' + i, { k: 100, note: 'x' }]));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goalDoc({ planPrefs: { ...prefs, foods: mk(40) } })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'z1'), goalDoc({ planPrefs: { ...prefs, foods: mk(41) } })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'z2'), goalDoc({ planPrefs: { ...prefs, foods: [] } })));
    });

    it('12g. অন্য সদস্য (grant ছাড়া) planPrefs/extraFoods লিখতে পারে না; update-পথেও একই নিয়ম', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goalDoc()); });
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'healthTracker', 'goal_mA'), { planPrefs: prefs, lastEditedByMemberId: 'mB' }, { merge: true }));
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { extraFoods: [], lastEditedByMemberId: 'mA' }));
      await assertSucceeds(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { planPrefs: prefs, lastEditedByMemberId: 'mA' }));
    });
  });

  // ============================================================
  // পার্ট ১০: goal-এর নতুন ঐচ্ছিক ফিল্ড fastDays / waterTarget
  describe('12h. Tracker goal: fastDays ও waterTarget', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const goal = (extra = {}) => ({
      type: 'goal', memberId: 'mA', sources: {}, lastEditedByMemberId: 'mA', createdAt: OLD, updatedAt: OLD, ...extra,
    });

    it('12h-1. owner বৈধ fastDays/waterTarget লিখতে পারেন (তৈরি, merge, খালি/null সহ)', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goal({ fastDays: [0, 3], waterTarget: 12 })));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { fastDays: [6], waterTarget: 1, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { fastDays: [], waterTarget: null, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { waterTarget: 20, lastEditedByMemberId: 'mA' }, { merge: true }));
    });

    it('12h-2. অবৈধ ধরন/সীমা/অতিরিক্ত ফিল্ড reject; daily-ডকে এই ফিল্ড চলে না', async () => {
      const db = dbAs('uidA');
      const f = (id, d) => assertFails(setDoc(famDoc(db, 'healthTracker', id), d));
      await f('z1', goal({ fastDays: [0, 1, 2] }));          // ২টির বেশি
      await f('z2', goal({ fastDays: [7] }));                // সীমার বাইরে
      await f('z3', goal({ fastDays: [-1] }));
      await f('z4', goal({ fastDays: [1, 1] }));             // ডুপ্লিকেট
      await f('z5', goal({ fastDays: ['1'] }));              // ভুল ধরন
      await f('z6', goal({ fastDays: 'sat' }));
      await f('z7', goal({ waterTarget: 0 }));
      await f('z8', goal({ waterTarget: 21 }));
      await f('z9', goal({ waterTarget: 8.5 }));
      await f('z10', goal({ waterTarget: '8' }));
      await f('z11', { ...goal({ fastDays: [1] }), type: 'daily', date: '2026-11-08' });
      await f('z12', { ...goal({ waterTarget: 8 }), type: 'daily', date: '2026-11-08' });
    });

    it('12h-3. অন্যের ডকে (grant ছাড়া) লেখা যায় না; update-পথেও একই নিয়ম', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goal()); });
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'healthTracker', 'goal_mA'), { fastDays: [1], lastEditedByMemberId: 'mB' }, { merge: true }));
      await assertFails(updateDoc(famDoc(dbAs('uidB'), 'healthTracker', 'goal_mA'), { waterTarget: 10, lastEditedByMemberId: 'mB' }));
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { fastDays: [9], lastEditedByMemberId: 'mA' }));
      await assertSucceeds(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { fastDays: [2, 5], waterTarget: 9, lastEditedByMemberId: 'mA' }));
    });
  });

  // দৈনিক হাঁটার লক্ষ্য: goal-এর ঐচ্ছিক `stepsTarget` (পূর্ণসংখ্যা ১,০০০–৩০,০০০ বা null)
  describe('12h-S. Tracker goal: stepsTarget', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const goal = (extra = {}) => ({
      type: 'goal', memberId: 'mA', sources: {}, lastEditedByMemberId: 'mA', createdAt: OLD, updatedAt: OLD, ...extra,
    });

    it('12h-S1. owner বৈধ stepsTarget লিখতে পারেন (সীমা ও null সহ); অন্যের ডকে পারেন না', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goal({ stepsTarget: 8000 })));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { stepsTarget: 1000, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { stepsTarget: 30000, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { stepsTarget: null, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertFails(updateDoc(famDoc(dbAs('uidB'), 'healthTracker', 'goal_mA'), { stepsTarget: 7000, lastEditedByMemberId: 'mB' }));
    });

    it('12h-S2. অবৈধ ধরন/সীমা reject; daily-ডকে চলে না', async () => {
      const db = dbAs('uidA');
      const f = (id, d) => assertFails(setDoc(famDoc(db, 'healthTracker', id), d));
      await f('s1', goal({ stepsTarget: 999 }));
      await f('s2', goal({ stepsTarget: 30001 }));
      await f('s3', goal({ stepsTarget: 7000.5 }));
      await f('s4', goal({ stepsTarget: '7000' }));
      await f('s5', { ...goal({ stepsTarget: 7000 }), type: 'daily', date: '2026-11-08' });
    });
  });

  // সাপ্তাহিক ওজনের দিন: goal-এর ঐচ্ছিক `weighDay` (পূর্ণসংখ্যা ০–৬)
  describe('12i. Tracker goal: weighDay', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const goal = (extra = {}) => ({
      type: 'goal', memberId: 'mA', sources: {}, lastEditedByMemberId: 'mA', createdAt: OLD, updatedAt: OLD, ...extra,
    });

    it('12i-1. owner বৈধ weighDay (০–৬) লিখতে পারেন — তৈরি ও merge; fastDays/waterTarget-এর সাথেও', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goal({ weighDay: 6 })));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { weighDay: 0, lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), { fastDays: [1], waterTarget: 9, weighDay: 3, lastEditedByMemberId: 'mA' }, { merge: true }));
    });

    it('12i-2. অবৈধ weighDay (সীমা/ধরন/null) reject; daily-ডকে চলে না', async () => {
      const db = dbAs('uidA');
      const f = (id, d) => assertFails(setDoc(famDoc(db, 'healthTracker', id), d));
      await f('w1', goal({ weighDay: 7 }));
      await f('w2', goal({ weighDay: -1 }));
      await f('w3', goal({ weighDay: 2.5 }));
      await f('w4', goal({ weighDay: '6' }));
      await f('w5', goal({ weighDay: null }));
      await f('w6', { ...goal({ weighDay: 6 }), type: 'daily', date: '2026-11-13' });
    });

    it('12i-3. অন্যের ডকে (grant ছাড়া) weighDay লেখা যায় না; update-পথেও একই নিয়ম', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'healthTracker', 'goal_mA'), goal()); });
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'healthTracker', 'goal_mA'), { weighDay: 1, lastEditedByMemberId: 'mB' }, { merge: true }));
      await assertFails(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { weighDay: 8, lastEditedByMemberId: 'mA' }));
      await assertSucceeds(updateDoc(famDoc(dbAs('uidA'), 'healthTracker', 'goal_mA'), { weighDay: 5, lastEditedByMemberId: 'mA' }));
    });
  });

  // ধাপ ২: daily-ডকের ঐচ্ছিক `medTaken` ("ওষুধ খেয়েছি" লগ)
  describe('12i. Tracker daily: medTaken (ওষুধ খেয়েছি)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const dly = (extra = {}) => ({
      type: 'daily', memberId: 'mA', date: '2026-11-08', caloriesIn: 0, sources: {},
      lastEditedByMemberId: 'mA', createdAt: OLD, updatedAt: OLD, ...extra,
    });
    const ref = (db) => famDoc(db, 'healthTracker', 'daily_mA_2026-11-08');

    it('12i-1. owner নতুন daily ডক medTaken-সহ তৈরি ও একটা key সেট/মোছা (dotted update) করতে পারেন', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(ref(db), dly({ medTaken: { Rec1_0800: true } })));
      await assertSucceeds(updateDoc(ref(db), { 'medTaken.Rec2_1400': true, lastEditedByMemberId: 'mA' }));
      await assertSucceeds(updateDoc(ref(db), { 'medTaken.Rec1_0800': deleteField(), lastEditedByMemberId: 'mA' }));
    });

    it('12i-2. medTaken map না হলে, ৬০-এর বেশি key হলে, বা goal-ডকে হলে reject', async () => {
      const db = dbAs('uidA');
      await assertFails(setDoc(ref(db), dly({ medTaken: 'yes' })));
      const big = {};
      for (let i = 0; i < 61; i++) big['R' + i + '_0800'] = true;
      await assertFails(setDoc(ref(db), dly({ medTaken: big })));
      await assertFails(setDoc(famDoc(db, 'healthTracker', 'goal_mA'), dly({ type: 'goal', medTaken: { Rec1_0800: true } })));
      const ok = {};
      for (let i = 0; i < 60; i++) ok['R' + i + '_0800'] = true;
      await assertSucceeds(setDoc(ref(db), dly({ medTaken: ok })));
    });

    it('12i-3. grant ছাড়া অন্য সদস্য লিখতে পারেন না; approved read+write grant থাকলে পারেন', async () => {
      await seed(async (db) => { await setDoc(ref(db), dly()); });
      await assertFails(updateDoc(ref(dbAs('uidB')), { 'medTaken.Rec1_0800': true, lastEditedByMemberId: 'mB' }));
      await seedGrant('mA', 'mB');
      await assertSucceeds(updateDoc(ref(dbAs('uidB')), { 'medTaken.Rec1_0800': true, lastEditedByMemberId: 'mB' }));
    });
  });

  // ============================================================
  describe('13. appDesign (পেজ-কার্ড ডিজাইন — শুধু App Creator লেখে)', () => {
    const CREATOR = 'bZrGqbY0dFVTkIXKvEAwfHbMhRk1';
    const ref = (db, id = 'layout') => doc(db, 'appDesign', id);
    const card = (id) => ({ id, visible: true, fold: 'fixed' });
    const good = { pages: { home: { main: [card('hero'), card('week')] }, trend: { top: [card('heatmap')], week: [card('weight')] } }, updatedAt: new Date(), updatedBy: CREATOR };

    it('13a. সাইন-ইন করা যে কেউ পড়তে পারে; অনাম নয়', async () => {
      await seed(async (db) => { await setDoc(ref(db), good); });
      await assertSucceeds(getDoc(ref(dbAs('uidA'))));
      await assertFails(getDoc(ref(testEnv.unauthenticatedContext().firestore())));
    });
    it('13b. Creator বৈধ ডিজাইন লিখতে পারে (merge-সহ)', async () => {
      const db = dbAs(CREATOR);
      await assertSucceeds(setDoc(ref(db), good));
      await assertSucceeds(setDoc(ref(db), { pages: { home: { main: [card('week')] } }, updatedAt: new Date(), updatedBy: CREATOR }, { merge: true }));
    });
    it('13c. Family Admin বা অন্য সদস্য লিখতে পারে না', async () => {
      await assertFails(setDoc(ref(dbAs(ADMIN_UID)), good));
      await assertFails(setDoc(ref(dbAs('uidA')), good));
    });
    it('13d. অচেনা doc-id / অতিরিক্ত ফিল্ড / অচেনা পেজ / ২০+ কার্ড / মোছা — সব বন্ধ', async () => {
      const db = dbAs(CREATOR);
      await assertFails(setDoc(ref(db, 'other'), good));
      await assertFails(setDoc(ref(db), { ...good, extra: 1 }));
      await assertFails(setDoc(ref(db), { pages: { blog: { main: [] } }, updatedAt: new Date(), updatedBy: CREATOR }));
      await assertFails(setDoc(ref(db), { pages: { home: { main: Array.from({ length: 21 }, (_, i) => card('c' + i)) } }, updatedAt: new Date(), updatedBy: CREATOR }));
      await assertFails(setDoc(ref(db), { pages: { home: { main: [], zzz: [] } }, updatedAt: new Date(), updatedBy: CREATOR }));
      await seed(async (sdb) => { await setDoc(ref(sdb), good); });
      await assertFails(deleteDoc(ref(db)));
    });
  });

  describe('14. appDesign/aiConfig (AI provider+model — শুধু App Creator লেখে)', () => {
    const CREATOR = 'bZrGqbY0dFVTkIXKvEAwfHbMhRk1';
    const ref = (db, id = 'aiConfig') => doc(db, 'appDesign', id);
    const good = { provider: 'openrouter', model: 'meta-llama/llama-4-maverick', updatedAt: new Date(), updatedBy: CREATOR };

    it('14a. Creator বৈধ provider+model লিখতে পারে; সাইন-ইন সদস্য পড়তে পারে', async () => {
      await assertSucceeds(setDoc(ref(dbAs(CREATOR)), good));
      await assertSucceeds(setDoc(ref(dbAs(CREATOR)), { ...good, provider: 'groq', model: 'qwen/qwen3.8-27b' }));
      await assertSucceeds(getDoc(ref(dbAs('uidA'))));
      await assertFails(getDoc(ref(testEnv.unauthenticatedContext().firestore())));
    });
    it('14b. Family Admin / অন্য সদস্য / অনাম লিখতে পারে না', async () => {
      await assertFails(setDoc(ref(dbAs(ADMIN_UID)), good));
      await assertFails(setDoc(ref(dbAs('uidA')), good));
      await assertFails(setDoc(ref(testEnv.unauthenticatedContext().firestore()), good));
    });
    it('14c. অচেনা provider / অতিরিক্ত ফিল্ড (key সহ) / খারাপ model নাম / ভুল updatedBy / মোছা — সব বন্ধ', async () => {
      const db = dbAs(CREATOR);
      await assertFails(setDoc(ref(db), { ...good, provider: 'evil' }));
      await assertFails(setDoc(ref(db), { ...good, apiKey: 'sk-secret' }));
      await assertFails(setDoc(ref(db), { ...good, model: 'a b' }));
      await assertFails(setDoc(ref(db), { ...good, model: 'ab' }));
      await assertFails(setDoc(ref(db), { ...good, model: 'x'.repeat(81) }));
      await assertFails(setDoc(ref(db), { ...good, model: 123 }));
      await assertFails(setDoc(ref(db), { ...good, updatedBy: 'someoneElse' }));
      await seed(async (sdb) => { await setDoc(ref(sdb), good); });
      await assertFails(deleteDoc(ref(db)));
    });
  });

  describe('11. Global reference DB', () => {
    it('11. medicineDatabase: শুধু verified পড়া যায়; client write সবসময় বন্ধ', async () => {
      await seed(async (db) => {
        await setDoc(doc(db, 'medicineDatabase', 'good'), { genericName: 'A', status: 'verified' });
        await setDoc(doc(db, 'medicineDatabase', 'draft'), { genericName: 'B', status: 'draft' });
      });
      const db = dbAs('uidA');
      await assertSucceeds(getDoc(doc(db, 'medicineDatabase', 'good')));
      await assertFails(getDoc(doc(db, 'medicineDatabase', 'draft')));
      await assertFails(setDoc(doc(db, 'medicineDatabase', 'x'), { genericName: 'X', status: 'verified' }));
      await assertFails(
        setDoc(doc(dbAs(ADMIN_UID), 'medicineDatabase', 'y'), { genericName: 'Y', status: 'verified' })
      );
    });

    it('11a. dietGuidanceRules: draft-ও লগইন-করা সবাই পড়ে (শুধু সতর্কবার্তা); write সবসময় বন্ধ', async () => {
      await seed(async (db) => {
        await setDoc(doc(db, 'dietGuidanceRules', 'd1'), { linkedTag: { type: 'condition', value: 'x' }, status: 'draft' });
      });
      await assertSucceeds(getDoc(doc(dbAs('uidA'), 'dietGuidanceRules', 'd1')));
      await assertSucceeds(getDocs(collection(dbAs('uidA'), 'dietGuidanceRules')));
      await assertFails(getDoc(doc(testEnv.unauthenticatedContext().firestore(), 'dietGuidanceRules', 'd1')));
      await assertFails(setDoc(doc(dbAs('uidA'), 'dietGuidanceRules', 'z'), { status: 'verified' }));
      await assertFails(setDoc(doc(dbAs(ADMIN_UID), 'dietGuidanceRules', 'z'), { status: 'verified' }));
    });

    it('11b. conditionGuides: লগইন-করা সবাই পড়ে; লেখা/মোছা শুধু অ্যাপ-ক্রিয়েটর', async () => {
      const CREATOR = 'bZrGqbY0dFVTkIXKvEAwfHbMhRk1';
      const good = { what: 'পরিচয়', causes: ['ক'], habits: ['খ'], food: ['গ'], caution: ['ঘ'], status: 'draft' };
      await assertSucceeds(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'ibs'), good));
      await assertSucceeds(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'ibs'), { ...good, status: 'verified', verifiedAt: new Date() }));
      await assertSucceeds(getDoc(doc(dbAs('uidA'), 'conditionGuides', 'ibs')));
      await assertSucceeds(getDocs(collection(dbAs('uidA'), 'conditionGuides')));
      await assertFails(getDoc(doc(testEnv.unauthenticatedContext().firestore(), 'conditionGuides', 'ibs')));
      await assertFails(setDoc(doc(dbAs('uidA'), 'conditionGuides', 'ibs'), good));
      await assertFails(setDoc(doc(dbAs(ADMIN_UID), 'conditionGuides', 'ibs'), good));
      await assertFails(deleteDoc(doc(dbAs(ADMIN_UID), 'conditionGuides', 'ibs')));
      // আকার/ধরন-সীমা ও অচেনা ফিল্ড
      await assertFails(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'x'), { ...good, status: 'weird' }));
      await assertFails(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'x'), { ...good, extra: 1 }));
      await assertFails(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'x'), { ...good, causes: 'not-a-list' }));
      await assertFails(setDoc(doc(dbAs(CREATOR), 'conditionGuides', 'x'), { ...good, what: 'ক'.repeat(1501) }));
      await assertSucceeds(deleteDoc(doc(dbAs(CREATOR), 'conditionGuides', 'ibs')));
    });
  });

  describe('MyCare carePrefs (ধাপ ৩)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const cp = (memberId, editor, extra = {}) => ({
      v: 1, memberId, skinType: 'dry', skinConcerns: ['acne'], hairType: 'normal', preferences: ['herbal'],
      avoidIngredients: ['lanolin'], region: 'BD', lastEditedByMemberId: editor, createdAt: OLD, updatedAt: OLD, ...extra,
    });

    it('C1. owner নিজের carePrefs তৈরি, পড়া, merge-update ও delete করতে পারেন', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA')));
      await assertSucceeds(getDoc(famDoc(db, 'carePrefs', 'mA')));
      await assertSucceeds(setDoc(famDoc(db, 'carePrefs', 'mA'), { memberId: 'mA', hairType: 'curly', lastEditedByMemberId: 'mA' }, { merge: true }));
      await assertSucceeds(deleteDoc(famDoc(db, 'carePrefs', 'mA')));
    });

    it('C2. অন্য সদস্য শেয়ার ছাড়া পড়তে/লিখতে পারেন না; read-শেয়ারে শুধু পড়া; write-শেয়ারে লেখাও', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA')); });
      await assertFails(getDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA'), cp('mA', 'mB')));
      await seedShare('mA', 'mB', { read: true, write: false });
      await assertSucceeds(getDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA'), cp('mA', 'mB')));
      await seedShare('mA', 'mB', { read: true, write: true });
      await assertSucceeds(setDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA'), cp('mA', 'mB')));
    });

    it('C3. অজানা ফিল্ড, ভুল memberId ও lastEditedBy spoof reject', async () => {
      const db = dbAs('uidA');
      await assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', { allergies: ['x'] })));
      await assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mB', 'mA')));
      await assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mB')));
    });

    it('C4. enum ও তালিকা-সীমা reject (skinType, concerns, preferences, avoidIngredients, region)', async () => {
      const db = dbAs('uidA');
      const bad = (x) => assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', x)));
      await bad({ skinType: 'purple' });
      await bad({ hairType: 'wavy' });
      await bad({ skinConcerns: ['acne', 'bogus'] });
      await bad({ skinConcerns: ['acne', 'scars', 'dryness', 'irritation', 'itching', 'acne'] });
      await bad({ preferences: ['general', 'herbal', 'ayurvedic', 'budget', 'general'] });
      await bad({ preferences: ['steroid'] });
      await bad({ avoidIngredients: new Array(21).fill('x') });
      await bad({ avoidIngredients: 'lanolin' });
      await bad({ region: 'x'.repeat(31) });
      await bad({ v: 2 });
      await assertSucceeds(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', { skinType: null, breastfeeding: false })));
    });

    it('C5. non-owner delete reject; carePrefs অন্য family/সদস্যের নামে তৈরি করা যায় না', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA')); });
      await assertFails(deleteDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'carePrefs', 'mA'), cp('mB', 'mB')));
    });

    it('C6. savedIds: তালিকা ≤২০, তালিকা-ধরন; merge-এ প্রোফাইল-ফিল্ড অক্ষত', async () => {
      const db = dbAs('uidA');
      const ids = (n) => new Array(n).fill(0).map((_, i) => 'item-' + i);
      await assertSucceeds(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', { savedIds: ids(20) })));
      await assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', { savedIds: ids(21) })));
      await assertFails(setDoc(famDoc(db, 'carePrefs', 'mA'), cp('mA', 'mA', { savedIds: 'skin-moisturizer' })));
      await assertSucceeds(setDoc(famDoc(db, 'carePrefs', 'mA'), { v: 1, memberId: 'mA', savedIds: ['skin-moisturizer'], lastEditedByMemberId: 'mA' }, { merge: true }));
      const snap = await getDoc(famDoc(db, 'carePrefs', 'mA'));
      if (snap.data().skinType !== 'dry') throw new Error('merge প্রোফাইল-ফিল্ড মুছে ফেলেছে');
    });
  });

  describe('MyCare careLog (ধাপ E)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const cl = (memberId, editor, extra = {}) => ({
      v: 1, memberId, days: { '2026-11-19': ['skin-gentle-cleanser/morning', 'all'] },
      lastEditedByMemberId: editor, createdAt: OLD, updatedAt: OLD, ...extra,
    });
    const manyDays = (n) => Object.fromEntries(new Array(n).fill(0).map((_, i) => ['2026-01-' + String(i + 1).padStart(2, '0') + 'x' + i, ['a/morning']]));

    it('L1. owner নিজের careLog তৈরি, পড়া, merge-update ও delete করতে পারেন; merge-এ অন্য দিন অক্ষত', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA')));
      await assertSucceeds(getDoc(famDoc(db, 'careLog', 'mA')));
      await assertSucceeds(setDoc(famDoc(db, 'careLog', 'mA'), { v: 1, memberId: 'mA', days: { '2026-11-20': ['oral-fluoride-brushing/night'] }, lastEditedByMemberId: 'mA' }, { merge: true }));
      const snap = await getDoc(famDoc(db, 'careLog', 'mA'));
      if (!snap.data().days['2026-11-19'] || !snap.data().days['2026-11-20']) throw new Error('merge আগের দিন মুছে ফেলেছে');
      await assertSucceeds(deleteDoc(famDoc(db, 'careLog', 'mA')));
    });

    it('L2. অন্য সদস্য শেয়ার ছাড়া পড়তে/লিখতে পারেন না; read-শেয়ারে শুধু পড়া; write-শেয়ারে লেখাও', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA')); });
      await assertFails(getDoc(famDoc(dbAs('uidB'), 'careLog', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'careLog', 'mA'), cl('mA', 'mB')));
      await seedShare('mA', 'mB', { read: true, write: false });
      await assertSucceeds(getDoc(famDoc(dbAs('uidB'), 'careLog', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'careLog', 'mA'), cl('mA', 'mB')));
      await seedShare('mA', 'mB', { read: true, write: true });
      await assertSucceeds(setDoc(famDoc(dbAs('uidB'), 'careLog', 'mA'), cl('mA', 'mB')));
    });

    it('L3. অজানা ফিল্ড, ভুল memberId, lastEditedBy spoof ও v:2 reject', async () => {
      const db = dbAs('uidA');
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { allergies: ['x'] })));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mB', 'mA')));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mB')));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { v: 2 })));
    });

    it('L4. days: map ও ≤৬০ দিন; ৬১ দিন বা ভুল ধরন reject', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { days: manyDays(60) })));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { days: manyDays(61) })));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { days: ['a/morning'] })));
      await assertFails(setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA', { days: 'x' })));
    });

    it('L5. non-owner delete reject; অন্যের নামে careLog তৈরি করা যায় না', async () => {
      await seed(async (db) => { await setDoc(famDoc(db, 'careLog', 'mA'), cl('mA', 'mA')); });
      await assertFails(deleteDoc(famDoc(dbAs('uidB'), 'careLog', 'mA')));
      await assertFails(setDoc(famDoc(dbAs('uidB'), 'careLog', 'mA'), cl('mB', 'mB')));
    });
  });

  // ============================================================
  // অডিট M৫ (২১ নভেম্বর ২০২৬): আগে test-বিহীন ৪টি collection — wellnessGuides, wellnessGuideMarks, doctors, healthCalendarEvents
  describe('15. wellnessGuides (ব্লগ — শুধু App Creator লেখে)', () => {
    const CREATOR = 'bZrGqbY0dFVTkIXKvEAwfHbMhRk1';
    beforeEach(async () => {
      await seedOwned('mC', CREATOR);
      await seedOwned('mA', 'uidA');
    });
    const guide = (extra = {}) => ({
      familyId: FAMILY_ID, authorId: 'mC', category: 'general', title: 'শিরোনাম', body: 'লেখা',
      createdAt: OLD, updatedAt: OLD, ...extra,
    });
    const gRef = (db, id = 'g1') => doc(db, 'wellnessGuides', id);

    it('W1. লগইনকারী সবাই পড়তে পারেন; লগআউট অবস্থায় নয়', async () => {
      await seed(async (db) => { await setDoc(gRef(db), guide()); });
      await assertSucceeds(getDoc(gRef(dbAs('uidA'))));
      await assertFails(getDoc(gRef(testEnv.unauthenticatedContext().firestore())));
    });

    it('W2. শুধু Creator তৈরি করতে পারেন; সাধারণ সদস্য, ভুল authorId বা ভুল category reject', async () => {
      await assertSucceeds(setDoc(gRef(dbAs(CREATOR)), guide()));
      await assertFails(setDoc(gRef(dbAs('uidA'), 'g2'), guide({ authorId: 'mA' })));
      await assertFails(setDoc(gRef(dbAs(CREATOR), 'g3'), guide({ authorId: 'mA' })));
      await assertFails(setDoc(gRef(dbAs(CREATOR), 'g4'), guide({ category: 'nonsense' })));
    });

    it('W3. Creator শুধু লেখার ফিল্ড বদলাতে পারেন; familyId/authorId নয়; অন্য কেউ নয়', async () => {
      await seed(async (db) => { await setDoc(gRef(db), guide()); });
      await assertSucceeds(updateDoc(gRef(dbAs(CREATOR)), { title: 'নতুন', updatedAt: new Date() }));
      await assertFails(updateDoc(gRef(dbAs(CREATOR)), { authorId: 'mA' }));
      await assertFails(updateDoc(gRef(dbAs(CREATOR)), { familyId: 'other' }));
      await assertFails(updateDoc(gRef(dbAs('uidA')), { title: 'হ্যাক' }));
    });

    it('W4. স্থায়ী মোছা শুধু ট্র্যাশে-থাকা (deletedAt আছে) পোস্ট, শুধু Creator', async () => {
      await seed(async (db) => {
        await setDoc(gRef(db, 'live'), guide());
        await setDoc(gRef(db, 'trashed'), guide({ deletedAt: OLD, deletedBy: 'mC' }));
      });
      await assertFails(deleteDoc(gRef(dbAs(CREATOR), 'live')));
      await assertFails(deleteDoc(gRef(dbAs('uidA'), 'trashed')));
      await assertSucceeds(deleteDoc(gRef(dbAs(CREATOR), 'trashed')));
    });
  });

  // ============================================================
  describe('16. wellnessGuideMarks (ব্যক্তিগত পাঠক-মার্ক)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const mark = (uid, extra = {}) => ({ uid, marks: [], updatedAt: OLD, ...extra });
    const mRef = (db, id) => doc(db, 'wellnessGuideMarks', id);

    it('K1. মালিক নিজের মার্ক তৈরি, পড়া, বদল ও মোছা করতে পারেন', async () => {
      const db = dbAs('uidA');
      await assertSucceeds(setDoc(mRef(db, 'uidA_post1'), mark('uidA')));
      await assertSucceeds(getDoc(mRef(db, 'uidA_post1')));
      await assertSucceeds(updateDoc(mRef(db, 'uidA_post1'), { marks: [{ t: 'x' }] }));
      await assertSucceeds(deleteDoc(mRef(db, 'uidA_post1')));
    });

    it('K2. অন্যের মার্ক পড়া/লেখা/মোছা যায় না; লগআউটেও নয়', async () => {
      await seed(async (db) => { await setDoc(mRef(db, 'uidA_post1'), mark('uidA')); });
      const b = dbAs('uidB');
      await assertFails(getDoc(mRef(b, 'uidA_post1')));
      await assertFails(setDoc(mRef(b, 'uidA_post1'), mark('uidB')));
      await assertFails(deleteDoc(mRef(b, 'uidA_post1')));
      await assertFails(getDoc(mRef(testEnv.unauthenticatedContext().firestore(), 'uidA_post1')));
    });

    it('K3. ভুল uid-ফিল্ড, ৩০১টি মার্ক ও list-নয় এমন মান reject', async () => {
      const db = dbAs('uidA');
      await assertFails(setDoc(mRef(db, 'uidA_post2'), mark('uidB')));
      await assertFails(setDoc(mRef(db, 'uidA_post2'), mark('uidA', { marks: new Array(301).fill(1) })));
      await assertSucceeds(setDoc(mRef(db, 'uidA_post2'), mark('uidA', { marks: new Array(300).fill(1) })));
      await assertFails(setDoc(mRef(db, 'uidA_post3'), mark('uidA', { marks: 'x' })));
    });
  });

  // ============================================================
  describe('17. doctors (পারিবারিক ডাক্তার-তালিকা)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const dr = (editor, extra = {}) => ({ name: 'ডা. টেস্ট', specialtyCategory: 'general', status: 'no-image', lastEditedByMemberId: editor, createdAt: OLD, updatedAt: OLD, ...extra });
    const dRef = (db, id = 'd1') => famDoc(db, 'doctors', id);

    it('D1. পরিবারের সদস্য পড়তে পারেন; বাইরের লোক ও লগআউট নয়', async () => {
      await seed(async (db) => { await setDoc(dRef(db), dr('mA')); });
      await assertSucceeds(getDoc(dRef(dbAs('uidB'))));
      await assertFails(getDoc(dRef(dbAs('outsider-uid'))));
      await assertFails(getDoc(dRef(testEnv.unauthenticatedContext().firestore())));
    });

    it('D2. সদস্য নিজের নামে তৈরি করতে পারেন; অন্যের lastEditedBy বসালে বা বাইরের লোকের তৈরি reject', async () => {
      await assertSucceeds(setDoc(dRef(dbAs('uidA')), dr('mA')));
      await assertFails(setDoc(dRef(dbAs('uidA'), 'd2'), dr('mB')));
      await assertFails(setDoc(dRef(dbAs('outsider-uid'), 'd3'), dr('mA')));
    });

    it('D3. edit শুধু creator; অন্য সদস্য ও Admin নয়; lastEditedBy spoof নয়', async () => {
      await seed(async (db) => { await setDoc(dRef(db), dr('mA')); });
      await assertSucceeds(updateDoc(dRef(dbAs('uidA')), { phone: '01700000000', lastEditedByMemberId: 'mA' }));
      await assertFails(updateDoc(dRef(dbAs('uidB')), { phone: '1', lastEditedByMemberId: 'mB' }));
      await assertFails(updateDoc(dRef(dbAs(ADMIN_UID)), { phone: '1', lastEditedByMemberId: 'memberAdmin' }));
      await assertFails(updateDoc(dRef(dbAs('uidA')), { phone: '2', lastEditedByMemberId: 'mB' }));
    });

    it('D4. মোছা creator বা Admin পারেন; অন্য সদস্য নয়', async () => {
      await seed(async (db) => {
        await setDoc(dRef(db, 'x1'), dr('mA'));
        await setDoc(dRef(db, 'x2'), dr('mA'));
      });
      await assertFails(deleteDoc(dRef(dbAs('uidB'), 'x1')));
      await assertSucceeds(deleteDoc(dRef(dbAs('uidA'), 'x1')));
      await assertSucceeds(deleteDoc(dRef(dbAs(ADMIN_UID), 'x2')));
    });
  });

  // ============================================================
  describe('18. healthCalendarEvents (পারিবারিক ক্যালেন্ডার)', () => {
    beforeEach(async () => {
      await seedOwned('mA', 'uidA');
      await seedOwned('mB', 'uidB');
    });
    const ev = (editor, extra = {}) => ({ title: 'টিকা', date: '2026-12-01', lastEditedByMemberId: editor, createdAt: OLD, updatedAt: OLD, ...extra });
    const eRef = (db, id = 'e1') => famDoc(db, 'healthCalendarEvents', id);

    it('E1. সদস্য পড়তে ও নিজের নামে তৈরি করতে পারেন; বাইরের লোক বা spoof নয়', async () => {
      await assertSucceeds(setDoc(eRef(dbAs('uidA')), ev('mA')));
      await assertSucceeds(getDoc(eRef(dbAs('uidB'))));
      await assertFails(getDoc(eRef(dbAs('outsider-uid'))));
      await assertFails(setDoc(eRef(dbAs('uidA'), 'e2'), ev('mB')));
      await assertFails(setDoc(eRef(dbAs('outsider-uid'), 'e3'), ev('mA')));
    });

    it('E2. edit creator বা Admin পারেন; অন্য সদস্য নয়; lastEditedBy সবসময় caller-এর', async () => {
      await seed(async (db) => { await setDoc(eRef(db), ev('mA')); });
      await assertSucceeds(updateDoc(eRef(dbAs('uidA')), { title: 'নতুন', lastEditedByMemberId: 'mA' }));
      await assertFails(updateDoc(eRef(dbAs('uidB')), { title: 'হ্যাক', lastEditedByMemberId: 'mB' }));
      await assertSucceeds(updateDoc(eRef(dbAs(ADMIN_UID)), { title: 'অ্যাডমিন', lastEditedByMemberId: 'memberAdmin' }));
      await assertFails(updateDoc(eRef(dbAs('uidA')), { title: 'spoof', lastEditedByMemberId: 'mB' }));
    });

    it('E3. মোছা creator বা Admin পারেন; অন্য সদস্য নয়', async () => {
      await seed(async (db) => {
        await setDoc(eRef(db, 'y1'), ev('mA'));
        await setDoc(eRef(db, 'y2'), ev('mA'));
      });
      await assertFails(deleteDoc(eRef(dbAs('uidB'), 'y1')));
      await assertSucceeds(deleteDoc(eRef(dbAs('uidA'), 'y1')));
      await assertSucceeds(deleteDoc(eRef(dbAs(ADMIN_UID), 'y2')));
    });
  });
});
