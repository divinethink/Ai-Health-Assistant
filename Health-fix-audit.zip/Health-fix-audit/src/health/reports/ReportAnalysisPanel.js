// src/health/reports/ReportAnalysisPanel.js
//
// P5 — Report Intelligence — end-to-end entry point (Roadmap §8 পাইপলাইনের
// প্রথম কয়েকটা ধাপ একত্রে wire করা): file বেছে নেওয়া → text-layer detect →
// (দরকার হলে) client-side OCR → rule-based parse+validate →
// ReportVerificationForm (মাধ্যমিক, বাধ্যতামূলক user-verification)।
//
// **স্বতন্ত্র entry-point (existing Document Upload থেকে ইচ্ছাকৃতভাবে আলাদা):**
// এই panel document-vault-এ কিছু upload করে না (Cloudinary/DocumentUploadForm
// সম্পূর্ণ অপরিবর্তিত, zero-risk) — শুধু in-memory file বিশ্লেষণ করে ও
// ব্যবহারকারী-verified value HealthRecord (Observation) হিসেবে save করে।
// ব্যবহারকারী চাইলে একই ফাইল আলাদাভাবে উপরের Document Upload ফর্মেও (raw-file
// সংরক্ষণের জন্য) আপলোড করতে পারবেন — দুই স্বতন্ত্র উদ্দেশ্য (raw-vault vs
// analyzed-values), তাই আপাতত দুটো আলাদা file-picker (future simplification
// হিসেবে একত্রীকরণ সম্ভব, এই মুহূর্তে minimal-risk অগ্রাধিকার)।
//
// হাতে-লেখা report roadmap §8 অনুযায়ী OCR-এ যাওয়ার কথা না। ধাপ ৪: কম আত্মবিশ্বাস +
// কম নাম-মিল হলে "হাতের লেখা হতে পারে" নরম পরামর্শ ও ম্যানুয়াল ফর্মের বাটন দেখানো হয়;
// ঝাপসা/অন্ধকার ছবিতে "আরেকবার তুলুন"; ডোজ-প্যাটার্নের O/0-গোলমাল শুধু হাইলাইট
// (চুপচাপ ঠিক করা হয় না)। চূড়ান্ত যাচাই আগের মতোই mandatory user-verification-এ।

import { ErrorBox, SuccessBox, SecondaryButton } from "../../shared/ui.js";
import { assessOcr, findDoseConfusions, QUALITY_MESSAGES } from "./ocrQuality.js";
import { fetchTestNameDictionary } from "./testDictionaryData.js";
import { parseAndValidateReportText } from "./reportParsing.js";
import { ReportVerificationForm } from "./ReportVerificationForm.js";
import { ManualReportEntryForm } from "./ManualReportEntryForm.js";
import { LabResultSummary } from "./LabResultSummary.js";
import { ReportNextSteps } from "../nextstep/NextStepCard.js";
import { AiAssistBar } from "../doc-ai/AiAssistBar.js";
import { shouldTryAi, mergeLabCandidates } from "../doc-ai/aiAdapters.js";

const { useState, useCallback, useRef, useEffect } = React;

// নথিপত্র-ট্যাবের একীভূত ফ্লো: `presetFile` দিলে নিজস্ব file-picker লুকানো থাকে ও
// mount-এ স্বয়ংক্রিয় বিশ্লেষণ শুরু হয় (ফাইল আগেই vault-এ সংরক্ষিত)। `initialManual`
// হলে সরাসরি হাতে-লেখা ফর্মে খোলে। দুটোই ঐচ্ছিক — না দিলে আগের আচরণই বহাল।
// OCR-নোট: নরম সতর্কতা (থামায় না) — ছবির মান, হাতের লেখার সন্দেহ, ডোজ-প্যাটার্নের O/0-সন্দেহ
function ocrNotesView(n, openManual) {
  const note = (bg, color, children) => React.createElement("div", { style: { marginTop: "10px", padding: "10px 12px", borderRadius: "12px", background: bg, color, fontSize: "14px", lineHeight: 1.5 } }, children);
  const items = [];
  if (n.qualityReasons.length > 0) {
    items.push(note("#FFF6E5", "#8A5A00", "📷 " + n.qualityReasons.map((r) => QUALITY_MESSAGES[r]).join(", ") + " — আলোতে, সোজা করে আরেকবার তুললে ভালো পড়া যাবে।"));
  }
  if (n.suspectHandwriting) {
    items.push(note("#FFF6E5", "#8A5A00", React.createElement(React.Fragment, null,
      "✍️ এটা হাতে-লেখা হতে পারে — মেশিন ঠিকভাবে পড়তে পারে না। হাতে লিখে এন্ট্রি দেওয়াই নিরাপদ।",
      React.createElement("button", { onClick: openManual, style: { display: "block", width: "100%", minHeight: "44px", marginTop: "8px", borderRadius: "12px", border: "1px solid #8A5A00", background: "#fff", color: "#8A5A00", fontSize: "14px", fontWeight: 600, cursor: "pointer" } }, "✍️ সরাসরি লিখুন"))));
  }
  if (n.confusions.length > 0) {
    items.push(note("#FDF0EE", "#7A1F14", React.createElement(React.Fragment, null,
      "⚠️ ডোজে অক্ষর-ডিজিট গোলমাল হতে পারে — নিজে মিলিয়ে নিন (অ্যাপ নিজে বদলায়নি):",
      n.confusions.map((c, i) => React.createElement("div", { key: i, style: { marginTop: "4px" } }, React.createElement("mark", { style: { background: "#FFE08A", padding: "0 4px", borderRadius: "4px" } }, c.raw), " → \"" + c.suggestion + "\" হতে পারে")))));
  }
  return items.length > 0 ? React.createElement(React.Fragment, null, items.map((x, i) => React.cloneElement(x, { key: i }))) : null;
}

export function ReportAnalysisPanel({ familyId, targetMemberId, callerMemberId, presetFile, preOcr, initialManual, docId }) {
  const [handwrittenMode, setHandwrittenMode] = useState(!!initialManual);
  const [file, setFile] = useState(presetFile || null);
  const [savedCount, setSavedCount] = useState(0);
  const [savedAlerts, setSavedAlerts] = useState([]); // ধাপ ৫: যাচাই-শেষে লাল লাইন
  const [savedSummary, setSavedSummary] = useState(null); // ধাপ ৬: ট্র্যাফিক-লাইট ফল
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState(""); // "" | "extracting" | "ocr" | "parsing" | "done"
  const [err, setErr] = useState(null);
  const [candidates, setCandidates] = useState(null);
  const [extractionMethod, setExtractionMethod] = useState(null);
  const [aiJob, setAiJob] = useState(null); // ধাপ ৪-ঘ: { text, parsed, dict } — AI-র ফলের অপেক্ষায়
  const [aiNote, setAiNote] = useState(null); // AI-র ফলাফল/ব্যর্থতার নরম বার্তা
  const [ocrNotes, setOcrNotes] = useState(null); // { qualityReasons, suspectHandwriting, confusions } — শুধু OCR হলে
  const fileInputRef = useRef(null);

  const onFileChange = useCallback((e) => {
    const f = e.target.files && e.target.files[0];
    setErr(null);
    setCandidates(null);
    setSavedAlerts([]); setSavedSummary(null);
    setFile(f || null);
  }, []);

  const analyze = useCallback(async () => {
    if (!file) { setErr("একটা ছবি বা PDF ফাইল বেছে নিন।"); return; }
    setErr(null);
    setCandidates(null);
    setSavedAlerts([]); setSavedSummary(null);
    setOcrNotes(null); setAiJob(null); setAiNote(null);
    setBusy(true);
    setProgress(0);
    try {
      let rawText = "";
      let method = "ocr";
      let ocrResult = null;
      // dictionary আগে আনা হয় — OCR-এর দ্বিতীয়-চেষ্টায় "কয়টা টেস্ট-নাম মিলল" গোনার জন্য
      const dict = await fetchTestNameDictionary();
      const scoreText = (txt) => parseAndValidateReportText(txt, dict).length;

      if (preOcr && file === presetFile) { // ধাপ ৪-ঙ: আপলোডে আগেই পড়া — দুবার OCR নয়
        rawText = preOcr.text; ocrResult = preOcr.ocr; method = preOcr.method;
      } else if (file.type === "application/pdf") {
        setStage("extracting");
        const { extractPdfText } = await import("./pdfTextExtraction.js");
        const { hasTextLayer, text } = await extractPdfText(file);
        if (hasTextLayer) {
          rawText = text;
          method = "direct-text";
        } else {
          setStage("ocr");
          const { ocrPdfPages } = await import("./ocrExtraction.js");
          ocrResult = await ocrPdfPages(file, setProgress, { scoreText });
          rawText = ocrResult.text;
          method = "ocr";
        }
      } else if (file.type && file.type.startsWith("image/")) {
        setStage("ocr");
        const { ocrImageFile } = await import("./ocrExtraction.js");
        ocrResult = await ocrImageFile(file, setProgress, { scoreText });
        rawText = ocrResult.text;
        method = "ocr";
      } else {
        setErr("শুধু ছবি (jpg/png) বা PDF সমর্থিত।");
        setBusy(false);
        setStage("");
        return;
      }

      setStage("parsing");
      const parsed = parseAndValidateReportText(rawText, dict);
      let suspect = false;
      if (ocrResult) {
        const a = assessOcr({ confidence: ocrResult.confidence, matchedCount: parsed.length, textLength: rawText.length });
        suspect = a.suspectHandwriting;
        setOcrNotes({ qualityReasons: ocrResult.quality.reasons, suspectHandwriting: a.suspectHandwriting, confusions: findDoseConfusions(rawText) });
      }
      // ধাপ ৪-ঘ: চেনা মান কম হলে AI-সহায়তা (সম্মতি/নীরব fallback AiAssistBar-এর ভেতরে); নইলে আগের পথ অক্ষত
      if (shouldTryAi("lab-report", { text: rawText, knownCount: parsed.length, suspectHandwriting: suspect })) { setAiJob({ text: rawText, parsed, dict }); setCandidates(null); }
      else setCandidates(parsed);
      setExtractionMethod(method);
      setStage("done");
    } catch (e) {
      setErr(e.message || String(e));
      setStage("");
    } finally {
      setBusy(false);
    }
  }, [file, preOcr, presetFile]);

  useEffect(() => {
    if (presetFile) analyze();
    // শুধু mount-এ একবার
  }, []);

  const aiJobRef = useRef(null);
  aiJobRef.current = aiJob;
  const onAiSettled = useCallback(({ result, message }) => {
    const job = aiJobRef.current;
    if (!job) return;
    let merged = job.parsed, note = message ? "ℹ️ " + message : null;
    if (result && !result.empty) {
      const m = mergeLabCandidates(job.parsed, result.items, job.dict);
      merged = m.candidates;
      note = m.added ? "🤖 AI " + m.added + "টি মান যোগ করেছে — হলুদ চিহ্নিত মানগুলো নিজে মিলিয়ে টিক দিন।" : "🤖 AI-ও নতুন কোনো পরিচিত টেস্ট-মান পায়নি।";
    }
    setAiJob(null); setCandidates(merged); setAiNote(note);
  }, []);

  const stageLabels = {
    extracting: "PDF থেকে লেখা পড়া হচ্ছে...",
    ocr: "OCR চলছে... (" + Math.round(progress * 100) + "%)",
    parsing: "টেস্ট-মান শনাক্ত করা হচ্ছে...",
  };
  const busyLabel = stageLabels[stage] || "চলছে...";

  if (handwrittenMode) {
    return React.createElement(
      "div", { style: { marginTop: "14px", padding: "12px", border: "1px solid #D3E0D9", borderRadius: "14px", boxShadow: "0 2px 8px rgba(14,75,67,0.06)" } },
      React.createElement("h4", { style: { fontSize: "14px", color: "var(--hs-primary, #0E4B43)", margin: 0 } }, "হাতে-লেখা রিপোর্ট — সরাসরি লিখুন"),
      SecondaryButton("← OCR/AI বিশ্লেষণে ফিরে যান", () => setHandwrittenMode(false), false),
      React.createElement(ManualReportEntryForm, { familyId, targetMemberId, callerMemberId, onSaved: () => {} })
    );
  }

  const linkBtn = { background: "none", border: "none", color: "var(--hs-primary, #0E4B43)", fontSize: "14px", fontWeight: 700, cursor: "pointer", minHeight: "44px", padding: "0 6px", fontFamily: "inherit", textDecoration: "underline", textUnderlineOffset: "3px" };
  return React.createElement(
    "div", { style: { marginTop: "4px" } },
    // ফাইল-কার্ড: কোন ফাইল বিশ্লেষণ হচ্ছে + দ্রুত ক্রিয়া
    React.createElement("div", { style: { background: "#fff", border: "1px solid #DCE6E0", borderRadius: "16px", padding: "12px 14px", boxShadow: "0 1px 3px rgba(14,75,67,0.06)" } },
      presetFile
        ? React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "10px" } },
            React.createElement("span", { "aria-hidden": true, style: { fontSize: "26px" } }, "📄"),
            React.createElement("div", { style: { minWidth: 0 } },
              React.createElement("div", { style: { fontSize: "16px", fontWeight: 700, color: "#1F2D2A", overflowWrap: "anywhere" } }, presetFile.name),
              React.createElement("div", { style: { fontSize: "13px", color: "#5F716C" } }, busy ? busyLabel : (candidates ? "বিশ্লেষণ শেষ" : "ল্যাব রিপোর্ট"))))
        : React.createElement(React.Fragment, null,
            React.createElement("div", { style: { fontSize: "14px", color: "#4B5C57", marginBottom: "8px", lineHeight: 1.5 } }, "ল্যাব রিপোর্টের ছবি বা PDF দিন। টেস্টের মান শনাক্ত হলে আপনি নিজে যাচাই করে নেবেন।"),
            React.createElement("input", { ref: fileInputRef, type: "file", accept: "image/*,application/pdf", onChange: onFileChange, style: { fontSize: "14px", maxWidth: "100%" } })),
      React.createElement("div", { style: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 10px", marginTop: "10px" } },
        React.createElement("button", { type: "button", onClick: analyze, disabled: busy, style: { minHeight: "44px", padding: "0 16px", borderRadius: "12px", border: "1.5px solid var(--hs-primary, #0E4B43)", background: "#fff", color: "var(--hs-primary, #0E4B43)", fontSize: "14px", fontWeight: 700, cursor: busy ? "default" : "pointer", fontFamily: "inherit" } }, busy ? busyLabel : (presetFile ? "↻ আবার বিশ্লেষণ" : "বিশ্লেষণ করুন")),
        React.createElement("button", { type: "button", onClick: () => setHandwrittenMode(true), style: linkBtn }, "✍️ হাতে-লেখা? সরাসরি লিখুন"))),
    err ? ErrorBox(err) : null,
    ocrNotes && ocrNotesView(ocrNotes, () => setHandwrittenMode(true)),
    aiJob ? React.createElement(AiAssistBar, { familyId, docType: "lab-report", ocrText: aiJob.text, onSettled: onAiSettled, label: "টেস্টের মান ঠিকমতো পড়া যায়নি — AI-র সাহায্য নেবেন?" }) : null,
    aiNote ? React.createElement("div", { role: "status", style: { marginTop: "10px", padding: "10px 12px", borderRadius: "12px", background: aiNote.startsWith("🤖") ? "#FFF8E1" : "#F7F6F1", color: aiNote.startsWith("🤖") ? "#8A5A00" : "#4B5C57", fontSize: "14px", lineHeight: 1.5 } }, aiNote) : null,
    candidates
      ? React.createElement(ReportVerificationForm, {
          familyId, targetMemberId, callerMemberId, candidates, extractionMethod,
          sourceDoc: docId ? { id: docId, name: presetFile ? presetFile.name : "" } : null,
          onSaved: (n, alerts, summary) => { setCandidates(null); setSavedCount(n || 0); setSavedAlerts(alerts || []); setSavedSummary(summary || null); },
        })
      : null,
    savedCount > 0 ? (savedSummary ? React.createElement(LabResultSummary, { summary: savedSummary, savedCount }) : SuccessBox(savedCount + "টা মান সংরক্ষণ করা হয়েছে।")) : null,
    savedAlerts.length > 0 ? React.createElement(ReportNextSteps, { familyId, targetMemberId, callerMemberId, alerts: savedAlerts }) : null
  );
}
