import { t } from "../../shared/i18n.js";
// Health Timeline UI। Checklist P2-এর শেষ আইটেম।
//
// member-selector unification (owner-request): নিজস্ব member-fetch/dropdown
// সরিয়ে parent (HealthRecordsPageSection)-এর `selectedMemberId` প্রপ ব্যবহার।

import { ErrorBox } from "../../shared/ui.js";
import { buildTimeline } from "./timelineData.js";

const { useState, useEffect } = React;

export function HealthTimeline({ familyId, selectedMemberId }) {
  const [entries, setEntries] = useState(null);
  const [entriesErr, setEntriesErr] = useState(null);
  const targetMemberId = selectedMemberId;

  useEffect(() => {
    if (!targetMemberId) return;
    setEntries(null);
    setEntriesErr(null);
    buildTimeline(familyId, targetMemberId)
      .then(setEntries)
      .catch((e) => setEntriesErr(e.code === "permission-denied"
        ? "এই সদস্যের timeline দেখার অনুমতি আপনার নেই (Take-Access grant ছাড়া অন্য সদস্যের data দেখা যায় না)।"
        : (e.message || String(e))));
  }, [familyId, targetMemberId]);

  if (!targetMemberId) {
    return React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "সদস্য নির্বাচন করুন।");
  }

  return React.createElement(
    "div", { style: { marginTop: "20px" } },
    React.createElement("h3", { style: { fontSize: "15px", color: "#0E4B43" } }, t("h.timeline")),

    entriesErr && ErrorBox(entriesErr),
    !entriesErr && !entries && React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "লোড হচ্ছে..."),
    !entriesErr && entries && entries.length === 0 &&
      React.createElement("p", { style: { color: "#5F716C", fontSize: "14px" } }, "এখনো কোনো রেকর্ড/ডকুমেন্ট নেই।"),

    !entriesErr && entries && entries.length > 0 && React.createElement(
      "div", { style: { marginTop: "12px", borderLeft: "2px solid #D3E0D9", paddingLeft: "14px" } },
      entries.map((e) =>
        React.createElement(
          "div", { key: e.id, style: { marginBottom: "16px", position: "relative" } },
          React.createElement("div", {
            style: {
              position: "absolute", left: "-19px", top: "3px", width: "10px", height: "10px",
              borderRadius: "50%", background: "#0E4B43", border: "2px solid #F5F7F5",
            },
          }),
          React.createElement("div", { style: { fontSize: "14px", color: "#5F716C" } }, e.displayDate || "তারিখ অজানা"),
          React.createElement("div", { style: { fontSize: "14px", marginTop: "2px" } },
            e.icon + " ", React.createElement("b", null, e.label)),
          React.createElement("div", { style: { fontSize: "14px", color: "#1F2D2A", marginTop: "1px" } }, e.description),
          e.url && React.createElement("a", {
            href: e.url, target: "_blank", rel: "noopener noreferrer",
            style: { fontSize: "14px", color: "#0E4B43" },
          }, "👁 দেখুন")
        )
      )
    )
  );
}
