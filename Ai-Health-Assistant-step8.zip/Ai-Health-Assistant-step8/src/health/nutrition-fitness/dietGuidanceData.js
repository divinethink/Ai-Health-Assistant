// Diet/Food Guidance — data-layer (amendment item ১,
// 1_1_1_1_Health_Assistant_Amendment_Plan_DRAFT.md)।
//
// `dietGuidanceRules` global collection medicineDatabase/careEscalationDirectory-এর
// একই read-only pattern অনুসরণ করে (§3.4.2 প্যাটার্ন reuse) — শুধু owner-run
// script populate করে (scripts/populateDietGuidanceRules.js)। ছোট (২০-৩০
// entry) collection বলে vector/full-text search লাগে না — পুরো verified-list
// একবারে fetch করে client-side tag-match করা হয় (§6.2 "structured query,
// vector-DB না" নীতির সাথে সংগতিপূর্ণ, নতুন composite-index এড়াতে)।

import { db } from "../../legacy/firebaseConfig.js";
import { staticFoodGroups, mergeFoodGuidance } from "./foodGuidance.js";

// পুরো তালিকা (draft সহ — মালিকের সিদ্ধান্ত ২০২৬-১১-১০: শুধু সতর্কবার্তা, verify-গেট নেই) — ছোট collection বলে ১ read।
export async function listDietGuidanceRules() {
  const snap = await db.collection("dietGuidanceRules").get();
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// একটাই খাদ্য-নিয়ম: Firestore-নিয়ম + বয়স/অবস্থা-নিয়ম মিলিয়ে (foodGuidance.js)। সব স্ক্রিন/AI এটাই ব্যবহার করে।
// ctx: { records, age, goal } — না দিলে শুধু Firestore-নিয়ম (আগের মতো)।
export function matchFoodGuidance(allRules, tagValues, ctx) {
  const base = matchDietGuidanceForTags(allRules, tagValues);
  return ctx ? mergeFoodGuidance(base, staticFoodGroups(ctx)) : base;
}

// Member-এর relevantConditions/relevantAllergies (healthContextEngine.js-এর
// buildHealthContext()-এ ইতিমধ্যে derive হওয়া tag-list, নতুন কিছু না) দিয়ে
// প্রাসঙ্গিক avoid/include food একত্রিত করে — case-insensitive substring-match
// (তালিকা ছোট বলে fuzzy-matching-এর জটিলতা এখনই দরকার নেই)।
export function matchDietGuidanceForTags(allRules, tagValues) {
  const normalizedTags = (tagValues || []).map((t) => String(t).toLowerCase().trim()).filter(Boolean);
  const tokensOf = (t) => t.split(/[^a-z0-9\u0980-\u09FF]+/).filter(Boolean);
  const matched = allRules.filter((rule) => {
    const main = String(rule?.linkedTag?.value || "").toLowerCase().trim();
    // optional `linkedTag.aliases` (সংক্ষিপ্ত/বাংলা/বিকল্প নাম: IBS, ডায়াবেটিস ইত্যাদি) — না থাকলে
    // আগের আচরণই। ≤৩ অক্ষরের alias (ibs/uti/flu…) শুধু পূর্ণ শব্দ হিসেবে মেলে, যাতে
    // "beauty"-র ভেতরের "uti"-র মতো accidental substring-match না হয়।
    const aliases = (Array.isArray(rule?.linkedTag?.aliases) ? rule.linkedTag.aliases : [])
      .map((v) => String(v || "").toLowerCase().trim()).filter(Boolean);
    return normalizedTags.some((t) => {
      if (main && (t.includes(main) || main.includes(t))) return true;
      return aliases.some((a) => (a.length <= 3 ? tokensOf(t).includes(a) : t.includes(a)));
    });
  });

  const clean = (arr) => (arr || []).map((x) => String(x).trim()).filter(Boolean);
  const avoidFoods = [...new Set(matched.flatMap((r) => clean(r.avoidFoods)))];
  const avoidSet = new Set(avoidFoods);
  // নিরাপত্তা: কোনো খাবার এক অসুখে "এড়িয়ে চলুন" হলে অন্য অসুখের "খাবেন" তালিকা থেকে বাদ — avoid সবসময় জেতে।
  const includeFoods = [...new Set(matched.flatMap((r) => clean(r.includeFoods)))].filter((f) => !avoidSet.has(f));
  const habitTips = [...new Set(matched.flatMap((r) => clean(r.habitTips)))];
  const avoidSources = {};
  matched.forEach((r) => clean(r.avoidFoods).forEach((f) => { (avoidSources[f] = avoidSources[f] || []).push(r.linkedTag?.value); }));
  const byTag = matched.map((r) => ({ tag: r.linkedTag?.value, avoid: clean(r.avoidFoods), include: clean(r.includeFoods), tips: clean(r.habitTips) }));
  return { avoidFoods, includeFoods, habitTips, avoidSources, byTag, matchedTags: matched.map((r) => r.linkedTag?.value) };
}
