// ভাষা-নির্বাচন (বাংলা / English) — কেন্দ্রীয় টেক্সট-ফাইল।
// শুধু client-side পছন্দ (localStorage "hs-lang"); Firestore/schema-তে কিছু লেখা হয় না।
// ব্যবহার: t("nav.home"); ভাষা বদলালে app.js Dashboard-কে key দিয়ে নতুন করে render করে।
// নতুন টেক্সট যোগ করতে নিচে bn ও en দুই জায়গাতেই একই key বসান; en না থাকলে bn দেখায়।

const STORAGE_KEY = "hs-lang";
const LANGS = ["bn", "en"];

function readStored() {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    return LANGS.includes(v) ? v : "bn";
  } catch (e) { return "bn"; }
}

let current = readStored();
const listeners = new Set();

export function getLang() { return current; }

export function setLang(lang) {
  if (!LANGS.includes(lang) || lang === current) return;
  current = lang;
  try { localStorage.setItem(STORAGE_KEY, lang); } catch (e) { /* noop */ }
  document.documentElement.setAttribute("lang", lang);
  listeners.forEach((fn) => fn(lang));
}

export function useLang() {
  const [lang, setL] = React.useState(current);
  React.useEffect(() => {
    listeners.add(setL);
    return () => listeners.delete(setL);
  }, []);
  return lang;
}

const DICT = {
  bn: {
    "nav.home": "হোম", "nav.aichat": "এআই চ্যাট", "nav.blog": "ব্লগ", "nav.tracker": "ট্র্যাকার", "nav.docs": "নথি", "nav.health": "Health", "nav.menu": "মেনু",

    "title.home": "🏠 স্বাস্থ্য রেকর্ড", "title.aichat": "🩺 এআই চ্যাট", "title.blog": "🌿 স্বাস্থ্য ব্লগ", "title.tracker": "📈 হেলথ ট্র্যাকার",
    "title.docs": "📁 নথি", "title.menu": "☰ মেনু",

    "tab.today": "আজ", "tab.profile": "প্রোফাইল", "tab.healthProfile": "Health Profile", "tab.records": "স্বাস্থ্য তথ্য", "tab.diet": "খাদ্য নির্দেশিকা",
    "tab.medication": "ওষুধ ও রিমাইন্ডার", "tab.timeline": "টাইমলাইন", "tab.commonCare": "সাধারণ চিকিৎসা", "tab.food": "🍽️ Food Habit",
    "tab.symptom": "🩺 লক্ষণ যাচাই", "tab.medsci": "⚕️ আধুনিক চিকিৎসা", "tab.herbal": "🌿 ভেষজ", "tab.homeo": "💧 হোমিওপ্যাথি",
    "tab.nutrition": "🥗 পুষ্টি", "tab.fitness": "🏃 ব্যায়াম", "tab.upload": "📁 জমা নথি", "tab.export": "🩺 ডাক্তার",

    "top.role": "ভূমিকা", "top.familyCode": "পরিবারের কোড",
    "top.logout": "🚪 লগআউট", "top.member": "সদস্য",
    "top.changeGmail": "জিমেইল বদলান", "top.changeGmailSure": "নিশ্চিত? আপনার প্রোফাইল, ভূমিকা ও সব ডেটা অক্ষুণ্ণ থাকবে। জেনে রাখুন:",
    "top.changeGmailN1": "গুগল ড্রাইভ ব্যাকআপ এরপর নতুন জিমেইলের ড্রাইভে যাবে; আগের ব্যাকআপ আগের জিমেইলেই থাকবে।",
    "top.changeGmailN2": "নতুন জিমেইল আগে এই অ্যাপে ব্যবহৃত হয়ে থাকলে যুক্ত করা যাবে না।",
    "top.changeGmailN3": "পরের স্ক্রিনে নতুন অ্যাকাউন্ট বেছে না নেওয়া পর্যন্ত লগআউট করবেন না।",
    "top.changeGmailYes": "হ্যাঁ, বদলাব", "top.cancel": "বাতিল", "top.wait": "অপেক্ষা করুন…",
    "relink.title": "নতুন জিমেইল অ্যাকাউন্ট যুক্ত করুন",
    "relink.lead": "আপনার প্রোফাইল, ভূমিকা ও সব তথ্য অক্ষুণ্ণ আছে। এখন নতুন জিমেইল অ্যাকাউন্টটি বেছে নিলেই বদল সম্পূর্ণ হবে।",
    "relink.warn": "এটি শেষ না হওয়া পর্যন্ত লগআউট করবেন না এবং ব্রাউজারের ডেটা মুছবেন না। নইলে এই পরিচয়ে আর প্রবেশ করা যাবে না।",
    "relink.oldMail": "আগের জিমেইল:", "relink.pickNew": "নতুন জিমেইল অ্যাকাউন্ট বেছে নিন",
    "relink.restore": "আগের জিমেইল ফিরিয়ে আনুন", "relink.busy": "অপেক্ষা করুন…",

    "menu.prefs": "⚙️ পছন্দ — থিম", "menu.settings": "⚙️ সেটিংস (ভাষা ও থিম)", "menu.back": "← মেনু", "menu.aichatSub": "লক্ষণ যাচাই ও স্বাস্থ্য-পরামর্শ", "menu.familyTitle": "পরিবার", "menu.familySub": "সদস্য ও অ্যাক্সেস", "menu.dataTitle": "ডেটা ব্যাকআপ", "menu.dataSub": "ব্যাকআপ রাখুন ও ফিরিয়ে আনুন", "menu.settingsTitle": "সেটিংস", "menu.settingsSub": "ভাষা", "menu.themeShort": "থিম", "menu.lockTitle": "অ্যাপ লক", "menu.lockSub": "PIN ও ফিঙ্গারপ্রিন্ট", "menu.notifShort": "নোটিফিকেশন", "menu.copy": "কপি", "menu.copied": "কপি হয়েছে ✓", "menu.adminTools": "🛠 Admin টুলস (আমন্ত্রণ ও নতুন সদস্য)", "menu.emergencyShort": "📞 জরুরি সেবা", "menu.doctorShort": "ডাক্তারের তথ্য", "menu.language": "🌐 ভাষা", "menu.family": "👨‍👩‍👧‍👦 পরিবার",
    "menu.nav": "🧭 নেভিগেশন", "menu.doctor": "🩺 ডাক্তারের তথ্য ও ভিজিটিং কার্ড",
    "menu.care": "📞 জরুরি সেবা — যাচাই করা তালিকা", "menu.data": "💾 ডেটা — ব্যাকআপ/রিস্টোর",
    "theme.light": "☀️ হালকা", "theme.sepia": "📜 সেপিয়া", "theme.dark": "🌙 গাঢ়", "theme.herbal": "🌿 হার্বাল সবুজ", "theme.nightPulse": "🌃 নাইট পালস", "theme.calmPaper": "📄 শান্ত কাগজ", "theme.warmClay": "🧱 উষ্ণ মাটি", "theme.oceanCalm": "🌊 সাগর-শান্ত",
    "lang.bn": "বাংলা", "lang.en": "English",

    "h.records": "স্বাস্থ্য রেকর্ড", "h.timeline": "স্বাস্থ্য টাইমলাইন", "h.calendar": "📅 পরিবারের স্বাস্থ্য ক্যালেন্ডার",
    "h.docs": "নথি / রিপোর্ট", "h.triage": "লক্ষণ যাচাই",

    "f.new": "নতুন স্বাস্থ্য রেকর্ড যোগ করুন", "f.edit": "স্বাস্থ্য রেকর্ড সম্পাদনা করুন",
    "f.type": "ধরন", "f.typeFixed": "(সম্পাদনায় বদলানো যায় না)",
    "type.condition": "অসুস্থতা", "type.observation": "পরিমাপ (সুগার, ওজন ইত্যাদি)",
    "type.medicationStatement": "ওষুধ", "type.allergy": "অ্যালার্জি",
    "f.name": "নাম", "f.category": "বিভাগ", "f.status": "অবস্থা", "f.onset": "শুরুর তারিখ (ঐচ্ছিক)",
    "f.date": "তারিখ (ঐচ্ছিক)", "f.startDate": "শুরুর তারিখ (ঐচ্ছিক)",
    "f.notes": "সংক্ষিপ্ত বিবরণ (ঐচ্ছিক, ১-২ লাইন)", "f.chronic": "এটা কি দীর্ঘমেয়াদি সমস্যা? (যেমন: ডায়াবেটিস, উচ্চ রক্তচাপ, থাইরয়েড, কিডনি রোগ)",
    "f.physician": "চিকিৎসক যোগাযোগ (ঐচ্ছিক)",
    "f.obsType": "কীসের পরিমাপ", "f.value": "মান", "f.unit": "একক",
    "f.medName": "ওষুধের নাম", "f.freq": "কয় বেলা / কীভাবে খাবেন", "f.days": "কতদিন খেতে হবে (দিন)",
    "f.tier": "ওষুধের ধরন", "f.substance": "যে জিনিসে অ্যালার্জি", "f.reaction": "কী সমস্যা হয়", "f.severity": "কতটা গুরুতর",
    "st.active": "চলছে", "st.resolved": "সেরে গেছে", "st.chronic": "দীর্ঘমেয়াদি", "st.stopped": "বন্ধ",
    "tier.otc-self-care": "সাধারণ (নিজে খাওয়া যায়)", "tier.requires-consult": "ডাক্তারের পরামর্শ লাগবে",
    "sev.mild": "হালকা", "sev.moderate": "মাঝারি", "sev.severe": "গুরুতর",
    "btn.save": "সংরক্ষণ করুন", "btn.update": "হালনাগাদ করুন", "btn.cancel": "বাতিল",
    "err.condition": "অসুস্থতার নাম লিখুন।", "err.observation": "কীসের পরিমাপ ও মান লিখুন।",
    "err.medicine": "ওষুধের নাম লিখুন।", "err.allergy": "কীসে অ্যালার্জি তা লিখুন।",
    "err.denied": "এই সদস্যের স্বাস্থ্য রেকর্ডে পরিবর্তন করার অনুমতি আপনার নেই।",
  },
  en: {
    "nav.home": "Home", "nav.aichat": "AI Chat", "nav.blog": "Blog", "nav.tracker": "Tracker", "nav.docs": "Documents", "nav.health": "Health", "nav.menu": "Menu",

    "title.home": "🏠 Health Records", "title.aichat": "🩺 AI Chat", "title.blog": "🌿 Health Blog", "title.tracker": "📈 Health Tracker",
    "title.docs": "📁 Documents", "title.menu": "☰ Menu",

    "tab.today": "Today", "tab.profile": "Profile", "tab.records": "Health Info", "tab.diet": "Diet Guide",
    "tab.medication": "Medicines & Reminders", "tab.timeline": "টাইমলাইন", "tab.commonCare": "General care", "tab.food": "🍽️ Food Habit",
    "tab.symptom": "🩺 Symptom Check", "tab.medsci": "⚕️ Medical Science", "tab.herbal": "🌿 Herbal", "tab.homeo": "💧 Homeopathy",
    "tab.nutrition": "🥗 Nutrition", "tab.fitness": "🏃 Fitness", "tab.upload": "📁 My Documents", "tab.export": "🩺 Doctor",

    "top.role": "Role", "top.familyCode": "Family code",
    "top.logout": "🚪 Log out", "top.member": "Member",
    "top.changeGmail": "Change Gmail", "top.changeGmailSure": "Sure? Your profile, role and all data stay intact. Please note:",
    "top.changeGmailN1": "Google Drive backups will go to the new Gmail's Drive; older backups stay in the old Gmail.",
    "top.changeGmailN2": "A Gmail already used in this app cannot be linked.",
    "top.changeGmailN3": "Do not log out until you pick the new account on the next screen.",
    "top.changeGmailYes": "Yes, change", "top.cancel": "Cancel", "top.wait": "Please wait…",
    "relink.title": "Link your new Gmail account",
    "relink.lead": "Your profile, role and all data are safe. Pick the new Gmail account now to finish the change.",
    "relink.warn": "Do not log out or clear browser data until this is done, or you will not be able to enter this identity again.",
    "relink.oldMail": "Previous Gmail:", "relink.pickNew": "Choose the new Gmail account",
    "relink.restore": "Restore the previous Gmail", "relink.busy": "Please wait…",

    "menu.prefs": "⚙️ Preferences — Theme", "menu.settings": "⚙️ Settings (Language & Theme)", "menu.back": "← Menu", "menu.aichatSub": "Symptom check & health guidance", "menu.familyTitle": "Family", "menu.familySub": "Members & access", "menu.dataTitle": "Data Backup", "menu.dataSub": "Back up and restore", "menu.settingsTitle": "Settings", "menu.settingsSub": "Language", "menu.themeShort": "Theme", "menu.lockTitle": "App Lock", "menu.lockSub": "PIN & fingerprint", "menu.notifShort": "Notifications", "menu.copy": "Copy", "menu.copied": "Copied ✓", "menu.adminTools": "🛠 Admin Tools (Invite & New Member)", "menu.emergencyShort": "📞 Emergency", "menu.doctorShort": "Doctor's Info", "menu.language": "🌐 Language", "menu.family": "👨‍👩‍👧‍👦 Family",
    "menu.nav": "🧭 Navigation", "menu.doctor": "🩺 Doctor Details & Visiting Cards",
    "menu.care": "📞 Emergency Care — Verified Directory", "menu.data": "💾 Data — Backup/Restore",
    "theme.light": "☀️ Light", "theme.sepia": "📜 Sepia", "theme.dark": "🌙 Dark", "theme.herbal": "🌿 Herbal Green", "theme.nightPulse": "🌃 Night Pulse", "theme.calmPaper": "📄 Calm Paper", "theme.warmClay": "🧱 Warm Clay", "theme.oceanCalm": "🌊 Ocean Calm",
    "lang.bn": "বাংলা", "lang.en": "English",

    "h.records": "Health Records", "h.timeline": "Health Timeline", "h.calendar": "📅 Family Health Calendar",
    "h.docs": "Documents / Reports", "h.triage": "Symptom Check",

    "f.new": "Add a new health record", "f.edit": "Edit health record",
    "f.type": "Type", "f.typeFixed": "(cannot be changed while editing)",
    "type.condition": "Condition", "type.observation": "Measurement (sugar, weight, etc.)",
    "type.medicationStatement": "Medicine", "type.allergy": "Allergy",
    "f.name": "Name", "f.category": "Category", "f.status": "Status", "f.onset": "Start date (optional)",
    "f.date": "Date (optional)", "f.startDate": "Start date (optional)",
    "f.notes": "Short note (optional, 1–2 lines)", "f.chronic": "Is this a long-term problem? (e.g. diabetes, high blood pressure, thyroid, kidney disease)",
    "f.physician": "Treating physician contact (optional)",
    "f.obsType": "What is measured", "f.value": "Value", "f.unit": "Unit",
    "f.medName": "Medicine name", "f.freq": "Times per day / how to take", "f.days": "For how many days",
    "f.tier": "Medicine type", "f.substance": "Allergic to", "f.reaction": "Reaction", "f.severity": "Severity",
    "st.active": "Active", "st.resolved": "Resolved", "st.chronic": "Chronic", "st.stopped": "Stopped",
    "tier.otc-self-care": "Common (self-care)", "tier.requires-consult": "Needs a doctor's advice",
    "sev.mild": "Mild", "sev.moderate": "Moderate", "sev.severe": "Severe",
    "btn.save": "Save", "btn.update": "Update", "btn.cancel": "Cancel",
    "err.condition": "Please enter the condition name.", "err.observation": "Please enter what is measured and the value.",
    "err.medicine": "Please enter the medicine name.", "err.allergy": "Please enter what you are allergic to.",
    "err.denied": "You do not have permission to change this member's health records.",
  },
};

export function t(key) {
  const d = DICT[current] || DICT.bn;
  return d[key] !== undefined ? d[key] : (DICT.bn[key] !== undefined ? DICT.bn[key] : key);
}
