// ট্র্যাকার ধাপ B-২ — "বদলান" শিট (শুধু UI; সংরক্ষণের কাজ বাবা-কম্পোনেন্ট TrackerPageSection-এ)।
// তিনটি শিট: MealEditSheet (বেলা), ExerciseEditSheet (দিনের রুটিন), ExerciseLogSheet ("আজ আসলে")।
// দুই মোড: "প্রতিদিনের জন্য" = goal-ডকের planPrefs (স্থায়ী); "আজ শুধু" = daily-ডকের extraFoods (শুধু মিল)।
// খসড়া-হিসাব ও যাচাই planPrefs.js-এর pure ফাংশনে — এখানে শুধু দেখানো ও ট্যাপ।

import { createPortal } from "react-dom";
import { TabPills } from "../../shared/ui.js";
import { useBackClose } from "../../shared/navHistory.js";
import { bnNum } from "../../shared/dates.js";
import { FOODS, itemText, qtyText, foodK, foodNote, hasFoodOverride, MAX_FOOD_KCAL, MAX_FOOD_NOTE } from "./mealPlanData.js";
import { medFoodNotes } from "./medFoodNotes.js";
import { foodEnglish } from "../../shared/searchAliases.js";
import { FOOD_GROUPS, TAGS, POS_TAGS, searchFoods, posTagsOf } from "./foodCatalog.js";
import { foodStatus, relevantTagsOf, STATUS_COLORS } from "./foodStatus.js";
import { per100Of, fmtMacro } from "./foodCalc.js";
import {
  EXERCISE_TYPES, MAX_QTY, MAX_EX_MIN, MIN_EX_MIN, MAX_KCAL, exerciseOptions, searchExercises, mealWarnings, exerciseWarnings,
  draftFromSlotItems, addDraftFood, changeDraftQty, removeDraftAt, draftKcal,
  draftFromDayItems, addDraftExercise, changeDraftMin, draftDayMinutes,
  checkExtraFood,
} from "./planPrefs.js";

const { useState, useEffect, useRef } = React;

export const EX_ICON = { walk: "🚶", run: "🏃", cycling: "🚴", gym: "🏋️", sports: "⚽", swim: "🏊", yoga: "🧘", other: "➕", stretch: "🧘",
  squat: "🦵", pushup: "💪", lunges: "🦵", mountain: "🧗", glute: "🍑", plank: "🧍", situp: "🤸", crunch: "🤸", bicycle: "🚴", legraise: "🦵",
  jacks: "🤸", burpee: "🔥", highknee: "🏃", skipping: "🪢", tricepdip: "💪", wallsit: "🧱", stepup: "🪜", superman: "🦸", birddog: "🐕",
  chairstand: "🪑", stairs: "🪜", dance: "💃", hiit: "⚡", pilates: "🧘" };

const GREEN = "var(--hs-primary, #0E4B43)";
const MUTED = "#5F716C";
export const BTN = { minHeight: "44px", minWidth: "44px", borderRadius: "12px", cursor: "pointer", fontFamily: "inherit", fontSize: "14px", fontWeight: 700 };
const TAG_CHIP = { marginLeft: "6px", padding: "1px 7px", borderRadius: "999px", background: "#FFF0D6", border: "1px solid #EBD9B4", color: "#7A5200", fontSize: "12px", fontWeight: 700 };
const ALLERGY_CHIP = { marginLeft: "6px", padding: "1px 7px", borderRadius: "999px", background: "#B3261E", border: "1px solid #B3261E", color: "#fff", fontSize: "12px", fontWeight: 700 };
const POS_CHIP = { marginLeft: "6px", padding: "1px 7px", borderRadius: "999px", background: "#E4F0E9", border: "1px solid #9CC5B4", color: "var(--hs-primary, #0E4B43)", fontSize: "12px", fontWeight: 700 };
export const INPUT = { width: "100%", boxSizing: "border-box", minHeight: "44px", padding: "10px 12px", border: "1.5px solid #C3D2CA", borderRadius: "12px", fontSize: "14px", fontFamily: "inherit" };

export function Sheet({ title, subtitle, onClose, children, soft }) { // soft = প্রিমিয়াম-ধাঁচ: হালকা-সবুজাভ ক্যানভাস + হ্যান্ডেল (সাদা কার্ড উঠে দেখায়)
  const ref = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useBackClose(onClose); // ফোনের Back = শিট বন্ধ
  useEffect(() => {
    const prev = document.activeElement;
    if (ref.current) ref.current.focus();
    const onKey = (e) => { if (e.key === "Escape") closeRef.current(); };
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("keydown", onKey); if (prev && prev.focus) prev.focus(); };
  }, []);
  // document.body-তে portal: ট্র্যাকার-পেজের stacking-context (z=40) নিচের নেভ-বারের (z=45) নিচে চাপা পড়ত।
  const overlay = React.createElement("div", {
    onClick: (e) => { if (e.target === e.currentTarget) onClose(); },
    style: { position: "fixed", inset: 0, zIndex: 200, background: "rgba(20,28,26,0.5)", display: "flex", alignItems: "flex-end", justifyContent: "center" },
  },
    React.createElement("div", {
      ref, role: "dialog", "aria-modal": "true", "aria-label": title, tabIndex: -1,
      style: { width: "100%", maxWidth: "520px", maxHeight: "88vh", overflowY: "auto", overflowX: "hidden", boxSizing: "border-box", background: soft ? "#F3F7F4" : "#fff", borderRadius: soft ? "28px 28px 0 0" : "20px 20px 0 0", padding: "16px 16px calc(20px + env(safe-area-inset-bottom, 0px))", outline: "none", fontFamily: "'Hind Siliguri', sans-serif" },
    },
      soft && React.createElement("div", { "aria-hidden": "true", style: { width: "44px", height: "5px", borderRadius: "3px", background: "#D3DFD8", margin: "-6px auto 10px" } }),
      React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "8px", marginBottom: "10px" } },
        React.createElement("div", null,
          React.createElement("div", { style: soft ? { fontSize: "21px", fontWeight: 800, color: "var(--hs-primary, #0E4B43)" } : { fontSize: "17px", fontWeight: 700, color: "#1F2D2A" } }, title),
          subtitle && React.createElement("div", { style: { fontSize: "13px", color: MUTED, marginTop: "2px" } }, subtitle)),
        React.createElement("button", { onClick: onClose, "aria-label": "বন্ধ করুন", style: { ...BTN, border: "none", background: "#EEF3F0", color: "#1F2D2A", fontSize: "18px" } }, "✕")),
      children));
  return createPortal(overlay, document.body);
}

export const Msg = (txt, tone) => React.createElement("div", {
  role: tone === "err" ? "alert" : undefined,
  style: { marginTop: "10px", padding: "10px 12px", borderRadius: "12px", fontSize: "13px", lineHeight: 1.5,
    background: tone === "err" ? "#FDECEA" : "#FFF6DD", border: "1px solid " + (tone === "err" ? "#E5A29A" : "#E8D08A"), color: tone === "err" ? "#7A1F14" : "#7A5B00" },
}, txt);

function Stepper(text, onDec, onInc, decDisabled, incDisabled, what) {
  return React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "6px" } },
    React.createElement("button", { onClick: onDec, disabled: decDisabled, "aria-label": what + " কমান", style: { ...BTN, border: "none", background: "#E4ECE7", color: GREEN, opacity: decDisabled ? 0.4 : 1 } }, "−"),
    React.createElement("span", { style: { minWidth: "52px", textAlign: "center", fontSize: "14px", fontWeight: 700, color: "#1F2D2A" } }, text),
    React.createElement("button", { onClick: onInc, disabled: incDisabled, "aria-label": what + " বাড়ান", style: { ...BTN, border: "none", background: "#E4ECE7", color: GREEN, opacity: incDisabled ? 0.4 : 1 } }, "+"));
}

export const primaryBtn = (label, onClick, busy, disabled) => React.createElement("button", {
  onClick, disabled: busy || disabled,
  style: { ...BTN, flex: 1, border: "none", background: busy || disabled ? "#8FAFA9" : GREEN, color: "#fff", cursor: busy || disabled ? "default" : "pointer" },
}, busy ? "অপেক্ষা করুন..." : label);
const ghostBtn = (label, onClick, busy, disabled) => React.createElement("button", {
  onClick, disabled: busy || disabled,
  style: { ...BTN, flex: 1, border: "1.5px solid " + GREEN, background: "#fff", color: GREEN, opacity: busy || disabled ? 0.5 : 1 },
}, label);

// খাবার খোঁজা: নাম-সার্চ + গ্রুপ-পিল; এলার্জির খাবারও আসে, লাল কার্ড+⚠ সতর্কতা (ব্লক নয়)। শুধু দেখানো ও ট্যাপ — হিসাব foodCatalog/planPrefs-এ।
// props: allergyTags, onPick(key), blockedNote (ঐচ্ছিক)
// খাবার-পেজের স্কোপড CSS: পিল-সারির স্ক্রলবার-রেখা লুকানো + সার্চ-ঘরে আইকনের জায়গা (index.html-এর !important padding ছাপিয়ে)
export const FOOD_CSS = ".hs-fp-pills>div{scrollbar-width:none;-ms-overflow-style:none}.hs-fp-pills>div::-webkit-scrollbar{display:none}input.hs-fp-search{padding-left:46px!important;border-radius:18px!important;min-height:52px;border:1px solid rgba(127,150,140,.30)!important;box-shadow:0 4px 14px rgba(14,75,67,.08)}input.hs-fp-search:focus{border-color:var(--hs-primary,#0E4B43)!important;box-shadow:0 0 0 3px rgba(14,75,67,.14)}";
export function FoodPicker({ allergyTags, avoidCtx, onPick, onEdit, layout, between }) {
  const [q, setQ] = useState("");
  const [grp, setGrp] = useState("");
  const LV = { green: 0, yellow: 1, red: 2 }; // সবুজ → হলুদ → লাল (স্টেবল সর্ট; দলের ভেতরে আগের ক্রম)
  const found = searchFoods(FOODS, { query: q, group: grp, allergyTags, limit: 200 })
    .map((x) => ({ x, l: LV[foodStatus(x.key, x.f, { allergyTags, ctx: avoidCtx }).level] }))
    .sort((a, b) => a.l - b.l).slice(0, 40).map((o) => o.x);
  return React.createElement("div", { className: "hs-fp-pills" },
    React.createElement("style", null, FOOD_CSS),
    React.createElement("div", { style: { position: "sticky", top: 0, zIndex: 2, background: "#F3F7F4", padding: "2px 0 6px" } },
      React.createElement("div", { style: { position: "relative" } },
        React.createElement("span", { "aria-hidden": "true", style: { position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", fontSize: "18px", pointerEvents: "none" } }, "🔍"),
        React.createElement("input", { type: "search", value: q, onChange: (e) => setQ(e.target.value), placeholder: "খাবার খুঁজুন — ভাত, Rice, ইলিশ", "aria-label": "খাবার খুঁজুন", className: "hs-fp-search", style: { ...INPUT, minHeight: "52px", paddingLeft: "46px", borderRadius: "16px", border: "1.5px solid #9CC5B4", background: "#fff", fontSize: "15px", boxShadow: "0 3px 10px rgba(14,75,67,0.10)" } }))),
    between || null,
    React.createElement("div", { style: { fontSize: "12px", fontWeight: 700, color: MUTED, margin: "16px 2px 6px", letterSpacing: "0.3px" } }, "ধরন অনুযায়ী"),
    // ধরন-ট্যাগ: ছোট-কোণ আয়তাকার, হালকা-বেগুনি ভরাট + বেগুনি বর্ডার
    React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px", margin: "0 0 10px", padding: "8px", borderRadius: "16px", background: "var(--hs-pill-tray, #EFE4D2)", boxShadow: "inset 0 1px 3px rgba(90,60,10,0.12)" } },
      [["", "সব"], ...FOOD_GROUPS].map(([id, label]) => React.createElement("button", { key: id || "all", type: "button", onClick: () => setGrp(id), "aria-pressed": grp === id,
        style: { fontSize: "13px", fontWeight: 700, padding: "4px 12px", minHeight: "40px", flex: "1 1 auto", whiteSpace: "nowrap", textAlign: "center", borderRadius: "10px", cursor: "pointer", fontFamily: "inherit",
          border: grp === id ? "1.5px solid var(--hs-pill, #8B5A2B)" : "1px solid var(--hs-pill-border, #D6C3A5)", boxShadow: grp === id ? "0 4px 10px rgba(90,60,10,0.34), inset 0 -3px 0 rgba(255,255,255,0.30)" : "0 2px 5px rgba(90,60,10,0.16), inset 0 -2px 0 rgba(90,60,10,0.06)",
          background: grp === id ? "linear-gradient(135deg, var(--hs-pill, #8B5A2B), var(--hs-pill-2, #A5703A))" : "linear-gradient(180deg, var(--hs-pill-top, #FFFFFF), var(--hs-pill-tint, #F6EEE0))", color: grp === id ? "var(--hs-pill-text, #fff)" : "var(--hs-pill-ink, #4F3414)" } }, React.createElement("span", { "aria-hidden": "true", style: { display: "inline-block", width: "14px", textAlign: "left", visibility: grp === id ? "visible" : "hidden" } }, "✓"), label, React.createElement("span", { "aria-hidden": "true", style: { display: "inline-block", width: "14px", visibility: "hidden" } }, "✓")))),
    found.length === 0 && React.createElement("div", { style: { fontSize: "13px", color: MUTED, padding: "6px 0" } }, "কিছু পাওয়া যায়নি। নিজের খাবার ‘আজ শুধু’-তে নাম ও কিলোক্যালরি দিয়ে যোগ করা যায়।"),
    layout === "list" ? React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: "6px" } },
      found.map(({ key, f, allergy }) => {
        const st = foodStatus(key, f, { allergyTags, ctx: avoidCtx }); const sc = STATUS_COLORS[st.level];
        const n = hasFoodOverride(key) ? null : per100Of(key);
        const ok = st.level === "green"; // ঠিক খাবার: সাদা কার্ড + খালি হালকা বৃত্ত ("বেছে নিন" ভাব); হলুদ/লাল সতর্কতা আগের মতো স্পষ্ট
        return React.createElement("button", { key, onClick: () => onPick(key), title: st.label + (st.reasons.length ? " — " + st.reasons.join("; ") : ""),
          style: { display: "flex", alignItems: "center", gap: "10px", width: "100%", minHeight: "60px", padding: "8px 12px", boxSizing: "border-box", textAlign: "left", cursor: "pointer", fontFamily: "inherit", borderRadius: "18px", border: "1px solid " + (ok ? "rgba(127,150,140,0.16)" : sc.border), background: ok ? "#fff" : sc.bg, color: "#1F2D2A", boxShadow: "0 1px 2px rgba(14,75,67,0.05), 0 6px 16px rgba(14,75,67,0.07)" } },
          React.createElement("span", { "aria-hidden": "true", style: { width: "26px", height: "26px", flexShrink: 0, boxSizing: "border-box", borderRadius: "50%", border: ok ? "2px solid #D3DFD8" : "none", background: ok ? "#fff" : sc.border, color: sc.text, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: 800 } }, ok ? "" : st.icon),
          React.createElement("span", { style: { flex: 1, minWidth: 0 } },
            React.createElement("span", { style: { display: "block", fontSize: "15px", fontWeight: 700 } }, f.n, React.createElement("span", { style: { fontWeight: 500, fontSize: "12.5px", color: MUTED } }, " · " + foodEnglish(key, f)),
              hasFoodOverride(key) && React.createElement("span", { style: POS_CHIP }, "আমার"), allergy && React.createElement("span", { style: ALLERGY_CHIP }, "⚠ অ্যালার্জি"),
              relevantTagsOf(f, avoidCtx).map((t) => React.createElement("span", { key: t, style: TAG_CHIP }, TAGS[t][0]))),
            React.createElement("span", { style: { display: "block", fontSize: "12px", color: MUTED, marginTop: "2px" } },
              n ? "প্রতি ১০০ গ্রামে · প্রোটিন " + fmtMacro(n.p) + " · কার্ব " + fmtMacro(n.c) + " · ফ্যাট " + fmtMacro(n.f) : "১ " + f.u + "-এ")),
          React.createElement("span", { style: { textAlign: "right", flexShrink: 0 } },
            React.createElement("b", { style: { display: "block", fontSize: "20px", lineHeight: 1.1, color: "var(--hs-primary, #0E4B43)" } }, bnNum(n ? n.kcal : foodK(key))),
            React.createElement("span", { style: { fontSize: "11.5px", color: "#8A9B95" } }, "কিলোক্যালরি")));
      })) :
    React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px" } },
      found.map(({ key, f, allergy }) => { const st = foodStatus(key, f, { allergyTags, ctx: avoidCtx }); const sc = STATUS_COLORS[st.level]; return React.createElement("span", { key, style: { display: "inline-flex", alignItems: "center" } }, React.createElement("button", {
        onClick: () => onPick(key),
        title: st.label + (st.reasons.length ? " — " + st.reasons.join("; ") : ""),
        style: { ...BTN, fontWeight: 600, padding: "6px 12px", border: "1px solid " + sc.border, background: sc.bg, color: st.level === "green" ? "#1F2D2A" : sc.text },
      }, st.icon + " " + foodEnglish(key, f) + " · " + bnNum(foodK(key)), hasFoodOverride(key) && React.createElement("span", { style: POS_CHIP }, "আমার"), allergy && React.createElement("span", { style: ALLERGY_CHIP }, "⚠ অ্যালার্জি"), posTagsOf(key).map((t) => React.createElement("span", { key: t, style: POS_CHIP }, POS_TAGS[t][0])), relevantTagsOf(f, avoidCtx).map((t) => React.createElement("span", { key: t, style: TAG_CHIP }, TAGS[t][0]))), onEdit && React.createElement("button", { onClick: () => onEdit(key), "aria-label": foodEnglish(key, f) + " এডিট করুন", style: { ...BTN, border: "none", background: "transparent", color: GREEN, padding: "0 8px" } }, "✎")); })),
    React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "✓ সবুজ = ঠিক · ! হলুদ = সীমিত রাখুন · ✕ লাল = এড়িয়ে চলুন (যেমন অ্যালার্জি মিলতে পারে)। শুধু সতর্কতা, বাছতে বাধা নেই; ডাক্তারের পরামর্শ প্রাধান্য পায়।"),
    found.some(({ key }) => posTagsOf(key).length > 0) && React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "সবুজ চিপ = প্রোটিন/আঁশের সাধারণ উৎস (শুধু তথ্য)।"),
    found.length >= 40 && React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "আরও দেখতে নাম লিখে খুঁজুন বা গ্রুপ বেছে নিন।"),
    React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "সংখ্যা = এক ইউনিটের আনুমানিক কিলোক্যালরি; রান্না ও পরিমাণে বদলায়।"));
}

// ---------- খাবার এডিট (ধাপ ৩): ক্যালরি + নিজের গুণাগুণ-নোট; শুধু এই সদস্যের জন্য, মূল তালিকা অপরিবর্তিত ----------
// props: foodKey, busy, err, onSave({k, note} | null = মূল মানে ফেরা), onClose
function FoodEditSheet({ foodKey, busy, err, onSave, onClose }) {
  const f = FOODS[foodKey];
  const [k, setK] = useState(String(foodK(foodKey)));
  const [note, setNote] = useState(foodNote(foodKey));
  const [formErr, setFormErr] = useState(null);
  const done = (p) => { Promise.resolve(p).then(onClose); };
  const submit = () => {
    const n = Number(k);
    if (k.trim() === "" || !Number.isFinite(n) || n < 0 || n > MAX_FOOD_KCAL) { setFormErr("কিলোক্যালরি ০–" + bnNum(MAX_FOOD_KCAL) + "-এর মধ্যে সংখ্যা দিন।"); return; }
    setFormErr(null);
    done(onSave({ k: Math.round(n), note: note.replace(/\s+/g, " ").trim().slice(0, MAX_FOOD_NOTE) }));
  };
  return React.createElement(Sheet, { title: foodEnglish(foodKey, f) + " — " + f.n, subtitle: "১ " + f.u + " ধরে · মূল মান " + bnNum(f.k) + " কিলোক্যালরি", onClose },
    React.createElement("label", { style: { display: "block", fontSize: "13px", fontWeight: 600, color: "#1F2D2A", margin: "4px 0" } }, "কিলোক্যালরি (১ " + f.u + "-এ, ০–" + bnNum(MAX_FOOD_KCAL) + ")"),
    React.createElement("input", { type: "number", inputMode: "numeric", min: 0, max: MAX_FOOD_KCAL, value: k, onChange: (e) => setK(e.target.value), style: INPUT }),
    React.createElement("label", { style: { display: "block", fontSize: "13px", fontWeight: 600, color: "#1F2D2A", margin: "12px 0 4px" } }, "গুণাগুণ/নোট (নিজের লেখা, ঐচ্ছিক)"),
    React.createElement("textarea", { value: note, maxLength: MAX_FOOD_NOTE, rows: 3, onChange: (e) => setNote(e.target.value), placeholder: "যেমন: কম তেলে রান্না, প্রোটিন বেশি", style: { ...INPUT, resize: "vertical" } }),
    React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "6px" } }, "শুধু এই সদস্যের প্ল্যানে বসবে; মূল খাবার-তালিকা বদলায় না। ক্যালরি আনুমানিক; নিজের লেখা নোট চিকিৎসা-পরামর্শ নয়।"),
    formErr && Msg(formErr, "err"),
    err && Msg(err, "err"),
    React.createElement("div", { style: { display: "flex", gap: "8px", marginTop: "14px" } },
      hasFoodOverride(foodKey) && ghostBtn("মূল মানে ফেরান", () => done(onSave(null)), busy),
      primaryBtn("সংরক্ষণ করুন", submit, busy)));
}

const MODES = [["perm", "প্রতিদিনের জন্য"], ["today", "আজ শুধু"]];

// ---------- মিল: একটি বেলা ----------
// props: slot (কার্যকর প্ল্যানের বেলা), planTotal, target, sex, allergyTags, isCustom, extras [{name,kcal,idx}] (এই বেলার আজকের নিজের খাবার),
// extraCount (আজকের মোট নিজের-খাবার), recentFoods [{name,kcal,count}] (গত ৭ দিনের সেরা, ঐচ্ছিক), activeMeds [নাম] (সক্রিয় ওষুধ, ঐচ্ছিক), busy, err, onSavePerm(draft), onReset(), onAddExtra(name,kcal), onRemoveExtra(idx), onClose
export function MealEditSheet({ slot, planTotal, target, sex, allergyTags, avoidCtx, isCustom, extras, extraCount, recentFoods, activeMeds, busy, err, onFoodSave, onSavePerm, onReset, onAddExtra, onRemoveExtra, onClose }) {
  const [mode, setMode] = useState("perm");
  const [editKey, setEditKey] = useState(null); // ✎ এডিটের খাবার
  const [draft, setDraft] = useState(() => draftFromSlotItems(slot.items));
  const [name, setName] = useState("");
  const [kcal, setKcal] = useState("");
  const [formErr, setFormErr] = useState(null);
  const [pickQty, setPickQty] = useState(1);
  const [pickedKey, setPickedKey] = useState(null); // "আজ শুধু"-তে তালিকা থেকে বাছা খাবার (ওষুধ-নোটের জন্য)
  const newSlot = draftKcal(draft);
  const newTotal = planTotal - slot.kcal + newSlot;
  const warnings = mealWarnings(newTotal, { sex, target });

  const submitExtra = () => {
    const e = checkExtraFood(name, kcal, extraCount);
    setFormErr(e);
    if (e) return;
    onAddExtra(name.replace(/\s+/g, " ").trim(), Number(kcal));
    setName(""); setKcal(""); setPickedKey(null);
  };

  const addRecent = (r) => {
    const e = checkExtraFood(r.name, r.kcal, extraCount);
    setFormErr(e);
    if (e) return;
    onAddExtra(r.name, r.kcal);
  };

  return React.createElement(Sheet, { title: slot.label + " বদলান", subtitle: "ক্যালরি আনুমানিক", onClose },
    TabPills(MODES, mode, setMode),
    mode === "perm" && React.createElement("div", null,
      draft.length === 0 && React.createElement("div", { style: { fontSize: "13px", color: MUTED, padding: "6px 0" } }, "এই বেলায় কোনো খাবার নেই (বেলা বাদ)। নিচ থেকে খাবার যোগ করুন।"),
      draft.map((r, i) => React.createElement("div", { key: r.food, style: { display: "flex", alignItems: "center", gap: "8px", padding: "6px 0", borderBottom: "1px solid #EEF3F0" } },
        React.createElement("div", { style: { flex: 1, fontSize: "14px", color: "#1F2D2A" } }, foodStatus(r.food, FOODS[r.food], { allergyTags, ctx: avoidCtx }).icon + " " + itemText(r.food, r.qty),
          React.createElement("div", { style: { fontSize: "12px", color: MUTED } }, bnNum(Math.round(foodK(r.food) * r.qty)) + " কিলোক্যালরি"),
          foodNote(r.food) && React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "2px" } }, "📝 " + foodNote(r.food)),
          FOODS[r.food].al && (allergyTags || []).includes(FOODS[r.food].al) && React.createElement("div", { style: { fontSize: "12px", color: "#B3261E", marginTop: "2px", fontWeight: 600 } }, "⚠ প্রোফাইলের অ্যালার্জির সাথে মিলতে পারে — সতর্ক থাকুন"),
          relevantTagsOf(FOODS[r.food], avoidCtx).map((t) => React.createElement("div", { key: t, style: { fontSize: "12px", color: "#7A5200", marginTop: "2px" } }, "⚠ " + TAGS[t][1])),
          medFoodNotes(activeMeds, r.food).map((n) => React.createElement("div", { key: n.rule + n.med, style: { fontSize: "12px", color: "#7A5200", marginTop: "2px", fontWeight: 600 } }, "💊 " + n.text))),
        Stepper(qtyText(r.qty), () => setDraft(changeDraftQty(draft, i, -0.5)), () => setDraft(changeDraftQty(draft, i, 0.5)), r.qty <= 0.5, r.qty >= MAX_QTY, FOODS[r.food].n),
        onFoodSave && React.createElement("button", { onClick: () => setEditKey(r.food), "aria-label": FOODS[r.food].n + " এডিট করুন", style: { ...BTN, border: "none", background: "#EEF3F0", color: GREEN } }, "✎"),
        React.createElement("button", { onClick: () => setDraft(removeDraftAt(draft, i)), "aria-label": FOODS[r.food].n + " বাদ দিন", style: { ...BTN, border: "none", background: "#FDECEA", color: "#7A1F14" } }, "✕"))),
      React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", margin: "12px 0 6px" } }, "খাবার যোগ করুন"),
      React.createElement(FoodPicker, { allergyTags, avoidCtx, onEdit: onFoodSave ? setEditKey : null, onPick: (key) => setDraft(addDraftFood(draft, key)) }),
      React.createElement("div", { style: { marginTop: "12px", padding: "10px 12px", borderRadius: "12px", background: "#E4F0E9", fontSize: "14px", color: GREEN, display: "flex", justifyContent: "space-between", gap: "8px" } },
        React.createElement("span", null, "নতুন মোট (" + slot.label + ")"),
        React.createElement("b", null, bnNum(slot.kcal) + " → " + bnNum(newSlot) + " কিলোক্যালরি")),
      React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "4px" } }, "সারাদিনের প্ল্যান: " + bnNum(newTotal) + (target ? " / টার্গেট " + bnNum(target) : "") + " কিলোক্যালরি"),
      warnings.map((w, i) => React.createElement("div", { key: i }, Msg(w, "warn"))),
      err && Msg(err, "err"),
      React.createElement("div", { style: { display: "flex", gap: "10px", marginTop: "14px" } },
        ghostBtn("ডিফল্টে ফিরুন", onReset, busy, !isCustom),
        primaryBtn("সংরক্ষণ করুন", () => onSavePerm(draft), busy)),
      React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "8px", textAlign: "center" } }, "এই বদল প্রতিদিনের প্ল্যানে থাকবে।")),
    mode === "today" && React.createElement("div", null,
      React.createElement("div", { style: { fontSize: "13px", color: MUTED, marginBottom: "8px", lineHeight: 1.5 } }, "প্ল্যানের বাইরে আজ যা খেয়েছেন তা যোগ করুন — শুধু আজকের হিসাবে যাবে, প্ল্যান বদলাবে না।"),
      extras.length === 0 && React.createElement("div", { style: { fontSize: "13px", color: MUTED, padding: "4px 0" } }, "এই বেলায় আজ নিজের কোনো খাবার যোগ করা হয়নি।"),
      extras.map((x) => React.createElement("div", { key: x.idx, style: { display: "flex", alignItems: "center", gap: "8px", padding: "6px 0", borderBottom: "1px solid #EEF3F0" } },
        React.createElement("div", { style: { flex: 1, fontSize: "14px", color: "#1F2D2A" } }, x.name + " · " + bnNum(x.kcal) + " কিলোক্যালরি"),
        React.createElement("button", { onClick: () => onRemoveExtra(x.idx), disabled: busy, "aria-label": x.name + " মুছুন", style: { ...BTN, border: "none", background: "#FDECEA", color: "#7A1F14" } }, "✕"))),
      Array.isArray(recentFoods) && recentFoods.length > 0 && React.createElement("div", null,
        React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", margin: "10px 0 6px" } }, "সাম্প্রতিক খাবার (গত ৭ দিন) — ট্যাপে যোগ"),
        React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px" } },
          recentFoods.map((r) => React.createElement("button", {
            key: r.name, onClick: () => addRecent(r), disabled: busy, "aria-label": r.name + " আজকের জন্য যোগ করুন",
            style: { ...BTN, fontWeight: 600, padding: "6px 12px", border: "1px solid #C3D2CA", background: "#F1F6F2", color: "#1F2D2A", opacity: busy ? 0.5 : 1 },
          }, "+ " + r.name + " · " + bnNum(r.kcal))))),
      React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", margin: "10px 0 6px" } }, "তালিকা থেকে বেছে নিন (ঐচ্ছিক)"),
      React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" } },
        React.createElement("span", { style: { fontSize: "13px", color: MUTED } }, "পরিমাণ"),
        Stepper(qtyText(pickQty), () => setPickQty(Math.max(0.5, pickQty - 0.5)), () => setPickQty(Math.min(MAX_QTY, pickQty + 0.5)), pickQty <= 0.5, pickQty >= MAX_QTY, "পরিমাণ")),
      React.createElement(FoodPicker, { allergyTags, avoidCtx, onEdit: onFoodSave ? setEditKey : null, onPick: (key) => { setName(itemText(key, pickQty)); setKcal(String(Math.round(foodK(key) * pickQty))); setFormErr(null); setPickedKey(key); } }),
      pickedKey && medFoodNotes(activeMeds, pickedKey).map((n) => React.createElement("div", { key: n.rule + n.med, style: { fontSize: "12px", color: "#7A5200", marginTop: "6px", fontWeight: 600 } }, "💊 " + n.text)),
      React.createElement("label", { style: { display: "block", fontSize: "13px", fontWeight: 600, color: "#1F2D2A", margin: "12px 0 4px" } }, "খাবারের নাম"),
      React.createElement("input", { type: "text", maxLength: 40, value: name, onChange: (e) => { setName(e.target.value); setPickedKey(null); }, style: INPUT }),
      React.createElement("label", { style: { display: "block", fontSize: "13px", fontWeight: 600, color: "#1F2D2A", margin: "10px 0 4px" } }, "কিলোক্যালরি (আনুমানিক, ০–" + bnNum(MAX_KCAL) + ")"),
      React.createElement("input", { type: "number", inputMode: "numeric", min: 0, max: MAX_KCAL, value: kcal, onChange: (e) => setKcal(e.target.value), style: INPUT }),
      formErr && Msg(formErr, "err"),
      err && Msg(err, "err"),
      React.createElement("div", { style: { display: "flex", marginTop: "14px" } }, primaryBtn("আজকের জন্য যোগ করুন", submitExtra, busy))),
    editKey && React.createElement(FoodEditSheet, { key: editKey, foodKey: editKey, busy, err, onSave: (e) => onFoodSave(editKey, e), onClose: () => setEditKey(null) }));
}

// ---------- ব্যায়াম: একটি দিনের রুটিন ----------
// props: dayLabel, items (কার্যকর রুটিনের ওই দিনের আইটেম), isCustom, busy, err, onSave(draft), onReset(), onClose
export function ExerciseEditSheet({ dayLabel, items, isCustom, busy, err, onSave, onReset, onClose }) {
  const [draft, setDraft] = useState(() => draftFromDayItems(items));
  const warnings = exerciseWarnings({ routine: [draft], band: "x" }, 0);
  return React.createElement(Sheet, { title: dayLabel + " — ব্যায়াম বদলান", subtitle: "প্রতি সপ্তাহের এই দিনের রুটিন", onClose },
    draft.length === 0 && React.createElement("div", { style: { fontSize: "13px", color: MUTED, padding: "6px 0" } }, "এই দিন বিশ্রাম। নিচ থেকে ব্যায়াম যোগ করুন।"),
    draft.map((r, i) => React.createElement("div", { key: i, style: { display: "flex", alignItems: "center", gap: "8px", padding: "6px 0", borderBottom: "1px solid #EEF3F0" } },
      React.createElement("div", { style: { flex: 1, fontSize: "14px", color: "#1F2D2A" } }, (EX_ICON[r.type] || "") + " " + EXERCISE_TYPES[r.type].label,
        !EXERCISE_TYPES[r.type].counted && React.createElement("div", { style: { fontSize: "12px", color: MUTED } }, "সাপ্তাহিক গণনায় নয়")),
      Stepper(bnNum(r.min) + " মি.", () => setDraft(changeDraftMin(draft, i, -5)), () => setDraft(changeDraftMin(draft, i, 5)), r.min <= MIN_EX_MIN, r.min >= MAX_EX_MIN, EXERCISE_TYPES[r.type].label + " মিনিট"),
      React.createElement("button", { onClick: () => setDraft(removeDraftAt(draft, i)), "aria-label": EXERCISE_TYPES[r.type].label + " বাদ দিন", style: { ...BTN, border: "none", background: "#FDECEA", color: "#7A1F14" } }, "✕"))),
    React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", margin: "12px 0 6px" } }, "ব্যায়াম যোগ করুন"),
    React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px" } },
      exerciseOptions().map((o) => React.createElement("button", {
        key: o.type, onClick: () => setDraft(addDraftExercise(draft, o.type)),
        style: { ...BTN, fontWeight: 600, padding: "6px 12px", border: "1px solid #C3D2CA", background: "#F1F6F2", color: "#1F2D2A" },
      }, "+ " + (EX_ICON[o.type] || "") + " " + o.label))),
    React.createElement("div", { style: { fontSize: "12px", color: MUTED, marginTop: "8px" } }, "এই দিনের মোট: " + bnNum(draftDayMinutes(draft)) + " মিনিট"),
    warnings.map((w, i) => React.createElement("div", { key: i }, Msg(w, "warn"))),
    err && Msg(err, "err"),
    React.createElement("div", { style: { display: "flex", gap: "10px", marginTop: "14px" } },
      ghostBtn("ডিফল্টে ফিরুন", onReset, busy, !isCustom),
      primaryBtn("সংরক্ষণ করুন", () => onSave(draft), busy)));
}

// ---------- ব্যায়াম: "আজ আসলে কী করলেন?" ----------
// props: initialType, entries (আজকের exerciseLog), busy, err, onAdd(type, min), onRemove(i), onClose
export function ExerciseLogSheet({ dateText, initialType, entries, recent, busy, err, onAdd, onRemove, onClose }) {
  const [type, setType] = useState(initialType || "other");
  const [min, setMin] = useState(30);
  const [q, setQ] = useState("");
  const list = searchExercises(q);
  return React.createElement(Sheet, { title: "আজ আসলে কী করলেন?", subtitle: dateText ? "শুধু " + dateText + "-এর হিসাবে যোগ হবে" : "শুধু আজকের হিসাবে যোগ হবে", onClose },
    entries.length > 0 && React.createElement("div", { style: { marginBottom: "8px" } },
      entries.map((x, i) => React.createElement("div", { key: i, style: { display: "flex", alignItems: "center", gap: "8px", padding: "6px 0", borderBottom: "1px solid #EEF3F0" } },
        React.createElement("div", { style: { flex: 1, fontSize: "14px", color: "#1F2D2A" } }, (EX_ICON[x.type] || "") + " " + EXERCISE_TYPES[x.type].label + " · " + bnNum(x.min) + " মিনিট"),
        React.createElement("button", { onClick: () => onRemove(i), disabled: busy, "aria-label": EXERCISE_TYPES[x.type].label + " মুছুন", style: { ...BTN, border: "none", background: "#FDECEA", color: "#7A1F14" } }, "✕")))),
    Array.isArray(recent) && recent.length > 0 && React.createElement("div", { style: { marginBottom: "10px" } },
      React.createElement("div", { style: { fontSize: "13px", fontWeight: 700, color: "#1F2D2A", marginBottom: "6px" } }, "সাম্প্রতিক · ১ ট্যাপে যোগ"),
      React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px" } },
        recent.filter((r) => EXERCISE_TYPES[r.type]).map((r) => React.createElement("button", { key: r.type, onClick: () => onAdd(r.type, r.min), disabled: busy, "aria-label": EXERCISE_TYPES[r.type].label + " " + r.min + " মিনিট যোগ করুন",
          style: { ...BTN, fontWeight: 600, padding: "6px 12px", border: "1.5px solid #9CC5B4", background: "#E4F0E9", color: GREEN, opacity: busy ? 0.5 : 1 } }, "＋ " + (EX_ICON[r.type] || "") + " " + EXERCISE_TYPES[r.type].label + " · " + bnNum(r.min) + " মি.")))),
    React.createElement("input", { type: "search", value: q, onChange: (e) => setQ(e.target.value), placeholder: "🔍 ব্যায়াম খুঁজুন — বাংলা/English (Squat, পুশ-আপ)", "aria-label": "ব্যায়াম খুঁজুন", style: { ...INPUT, marginBottom: "8px" } }),
    React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: "6px", maxHeight: "34vh", overflowY: "auto" } },
      list.length === 0 && React.createElement("div", { style: { fontSize: "13px", color: MUTED } }, "মেলেনি — নিচে ‘অন্য’ বেছে নিন।"),
      list.map((o) => React.createElement("button", {
        key: o.type, onClick: () => setType(o.type), "aria-pressed": type === o.type,
        style: { ...BTN, fontWeight: 600, padding: "6px 12px", border: "1.5px solid " + (type === o.type ? GREEN : "#C3D2CA"), background: type === o.type ? GREEN : "#F1F6F2", color: type === o.type ? "#fff" : "#1F2D2A" },
      }, (EX_ICON[o.type] || "") + " " + o.label))),
    React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "14px" } },
      React.createElement("span", { style: { fontSize: "14px", fontWeight: 700, color: "#1F2D2A" } }, (EX_ICON[type] || "") + " " + EXERCISE_TYPES[type].label + " — কতক্ষণ"),
      Stepper(bnNum(min) + " মি.", () => setMin(Math.max(MIN_EX_MIN, min - 5)), () => setMin(Math.min(MAX_EX_MIN, min + 5)), min <= MIN_EX_MIN, min >= MAX_EX_MIN, "মিনিট")),
    err && Msg(err, "err"),
    React.createElement("div", { style: { display: "flex", marginTop: "14px" } }, primaryBtn("যোগ করুন", () => onAdd(type, min), busy)));
}
