import { t } from "../../shared/i18n.js";
// হেলথ রেকর্ড (হোম) — Full-page wrapper, P11 mockup §৩ অনুযায়ী ৫টা sub-tab
// pill দিয়ে reorganized (ধাপ ২)। প্রতিটা sub-tab-এর ভেতরের existing
// component অপরিবর্তিত (HealthRecordsSection-এ শুধু নতুন `section` prop
// যোগ হয়েছে profile/records ভাগ করতে) — কোনো নতুন schema/data-logic নেই।
//
// আপডেট (owner-request, member-selector unification): আগে ৫টা sub-tab-এর
// ৩টাতে (প্রোফাইল/স্বাস্থ্য-তথ্য একই HealthRecordsSection, খাদ্য নির্দেশিকা,
// টাইমলাইন) আলাদা আলাদা "সদস্য বাছাই করুন" dropdown ছিল — ট্যাব পাল্টালেই
// আবার নতুন করে সদস্য বাছতে হতো। এখন `selectedMemberId` এই পেজ-wrapper-level-এ
// lift করা হয়েছে — একবার বাছলে এই পুরো হোম-পেজের সব sub-tab-এই persist থাকে।
// নিচের component-গুলোর ভেতরের নিজস্ব member-fetch/dropdown সরিয়ে
// `selectedMemberId` প্রপ নেওয়া হচ্ছে (HealthRecordsSection, DietGuidanceSection,
// HealthTimeline) — কোনো schema/permission পরিবর্তন নেই, presentation-layer-only।
// আপডেট (owner-request, ২০২৬-০৯-১৬): VaccinationScheduler-এও এখন
// `selectedMemberId` thread করা হয়েছে (আগে family-wide ভাবা হয়েছিল, কিন্তু
// আসলে per-child, নিজস্ব দ্বিতীয় dropdown ছিল — সেটা সরিয়ে এই পেজ-লেভেল
// selector-ই reuse হচ্ছে) এবং শুধু শিশুদের জন্য (৬ বছরের নিচে) দেখানো হয়,
// CollapsibleSection-এ। FamilyHealthCalendar সত্যিকারের family-wide (তার
// নিজস্ব "event কার জন্য" dropdown ভিন্ন purpose — event tagging, member-view-
// selector না) — Vaccination-এর উপরে আনা হলো (owner-request, দ্রুত-ব্যবহৃত
// জিনিস আগে)। MedicationReminders অপরিবর্তিত (সব সদস্যের aggregate list)।
//
// Care-Escalation Directory ও Backup/Restore এখনো main Dashboard-এই আছে
// (Menu full-page তৈরি না হওয়া পর্যন্ত, আলাদা থ্রেড)।

// আপডেট (owner-request, item ১, ২০২৬-০৯-১৬, app-wide member-switcher):
// `selectedMemberId` এখন এই wrapper-এও নিজে fetch/state করে না — Dashboard
// (app.js)-এর একক app-wide switcher থেকে prop হিসেবে আসে (Home/AI-চ্যাট/
// Documents ৩ ট্যাব-ই এখন এই একই সদস্য শেয়ার করে, ট্যাব পাল্টালেও persist
// থাকে)। `topOffsetPx`-ও Dashboard থেকে আসে (member-switcher-bar থাকলে ৭৮px,
// না থাকলে ৪৪px) — hardcoded "44px" সরানো হয়েছে।
//
// Care-Escalation Directory ও Backup/Restore এখনো main Dashboard-এই আছে
// (Menu full-page তৈরি না হওয়া পর্যন্ত, আলাদা থ্রেড)।

import { HealthRecordsSection } from "./HealthRecordsSection.js";
import { MedicationReminders } from "./MedicationReminders.js";
import { VaccinationScheduler } from "../calendar/VaccinationScheduler.js";
import { FamilyHealthCalendar } from "../calendar/FamilyHealthCalendar.js";
import { HealthTimeline } from "../timeline/HealthTimeline.js";
import { DietGuidanceSection } from "../nutrition-fitness/DietGuidanceSection.js";

const { useState } = React;

const TABS = [
  { id: "profile", label: "tab.profile" },
  { id: "records", label: "tab.records" },
  { id: "diet", label: "tab.diet" },
  { id: "medication", label: "tab.medication" },
  { id: "timeline", label: "tab.timeline" },
];

export function HealthRecordsPageSection({ familyId, callerMemberId, selectedMemberId, topOffsetPx, onExit }) {
  const [activeTab, setActiveTab] = useState("profile");
  const topPx = (topOffsetPx || 44) + "px";

  return React.createElement(
    "div", { style: { position: "fixed", top: topPx, left: 0, right: 0, bottom: "56px", zIndex: 40, display: "flex", flexDirection: "column", background: "#F5F5F0", fontFamily: "'Hind Siliguri', sans-serif" } },
    React.createElement(
      "div", { style: { display: "flex", overflowX: "auto", gap: "6px", padding: "8px 10px", background: "#fff", borderBottom: "1px solid #ddd", flexShrink: 0 } },
      TABS.map((tb) => React.createElement(
        "button", {
          key: tb.id,
          onClick: () => setActiveTab(tb.id),
          style: {
            flexShrink: 0, padding: "7px 12px", borderRadius: "16px", fontSize: "14px", fontWeight: 600, cursor: "pointer",
            border: activeTab === tb.id ? "1px solid #0E4B43" : "1px solid #ccc",
            background: activeTab === tb.id ? "#0E4B43" : "#fff",
            color: activeTab === tb.id ? "#fff" : "#333",
          },
        }, t(tb.label))
      )),
    !selectedMemberId
      ? React.createElement("p", { style: { color: "#888", fontSize: "14px", padding: "12px" } }, "সদস্য-তালিকা লোড হচ্ছে...")
      : React.createElement(
      "div", { style: { flex: 1, overflowY: "auto", padding: "12px" } },
      activeTab === "profile" && React.createElement(HealthRecordsSection, { familyId, callerMemberId, selectedMemberId, section: "profile" }),
      activeTab === "records" && React.createElement(HealthRecordsSection, { familyId, callerMemberId, selectedMemberId, section: "records" }),
      activeTab === "diet" && React.createElement(DietGuidanceSection, { familyId, callerMemberId, selectedMemberId }),
      activeTab === "medication" && React.createElement(MedicationReminders, { familyId, callerMemberId }),
      activeTab === "timeline" && React.createElement(
        React.Fragment, null,
        React.createElement(FamilyHealthCalendar, { familyId, callerMemberId }),
        React.createElement(VaccinationScheduler, { familyId, callerMemberId, selectedMemberId }),
        React.createElement(HealthTimeline, { familyId, callerMemberId, selectedMemberId })
      )
    )
  );
}
